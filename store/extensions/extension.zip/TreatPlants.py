import time
from g_python.gextension import Extension
from g_python.hmessage import Direction
from g_python.hparsers import HEntity, HPacket, HEntityType
import threading


extension_info = {
    "title": "Treat Plants",
    "description": "Type :treat to treat all plants in the room",
    "version": "1.0",
    "author": "diavo"
}

ext = Extension(extension_info, ["-p", "9092"])
ext.start()

def start(msg):
  command = msg.packet.read_string()
  if(command == ':treat'):
    msg.is_blocked = True
    thr = threading.Thread(target=treating)
    thr.start()


ids = []

def add_plants(message):
    global ids
    users = HEntity.parse(message.packet)
    for user in users:
        if user.entity_type == HEntityType.PET:
            ids.append(user.id)
        
def clear_plants(_):
    ids.clear()

def treating():
    global ids
    ext.send_to_client('{in:Whisper}{i:-1}{s:"Treating started!"}{i:0}{i:30}{i:0}{i:-1}')
    for id in ids:
        ext.send_to_server(HPacket("RespectPet", id))
        time.sleep(1) 
    ext.send_to_client('{in:Whisper}{i:-1}{s:"Treating ended!"}{i:0}{i:30}{i:0}{i:-1}')


ext.intercept(Direction.TO_SERVER, start, "Chat") 
ext.intercept(Direction.TO_CLIENT, add_plants, 'Users')
ext.intercept(Direction.TO_CLIENT, clear_plants, 'RoomReady')

