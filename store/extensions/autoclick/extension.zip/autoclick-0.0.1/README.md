# autoclick

Automatic clicks in any position in the room. Run the command `:autoclick` to activate

## Steps

- Run the command `:autoclick`
- Select any box from the room and the avatar will start to move
- Run the command `:autoclick` to deactivate

## Getting started

First, install packages

```bash
npm install
```

Run the extension

```bash
npm run test
```