import { Extension, HPacket, HDirection, HUserProfile } from 'gnode-api';
import { Configuration, OpenAIApi } from 'openai';
let state = false;


const extensionInfo = {
    name: "My Extension",
    description: "My first G-Node extension",
    version: "0.1",
    author: "Your name"
}

const configuration = new Configuration({
      apiKey: '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',
    });
    const openai = new OpenAIApi(configuration);


// Create new extension with extensionInfo
let ext = new Extension(extensionInfo);

// Start connection to G-Earth
ext.run();

ext.on('init', async => {
    const response1 = openai.createCompletion({
      model: "text-davinci-003",
      prompt: 'Hey GPT-3!',
      temperature: 0,
      max_tokens: 3000,
    });
    response1.then(function(result) {
    console.log(result.data.choices[0].text)
    })
    console.log("Connected to G-Earth");
  }); 
  ext.on('connect', (host, connectionPort, hotelVersion, clientIdentifier, clientType) => {
    // do something with client info
  });
  ext.interceptByHeaderId(HDirection.TOCLIENT, 1446, hMessage => {
    let packet = hMessage.getPacket();
    let userIndex = packet.readInteger();
    let msg = packet.readString();
    if(msg.includes("!gpt")) {
      let newMsg = msg.replace("!gpt", "")
    const response = openai.createCompletion({
      model: "text-davinci-003",
      prompt: `${newMsg}`,
      temperature: 0,
      max_tokens: 3000,
    });
        response.then(function(result) {
        if(result.data.choices[0].text.length >= 100) {
                      let kisacevap = result.data.choices[0].text.substring(0, 99)
                      let hPacket = new HPacket(`{h:1314}{s:"${kisacevap}"}{i:0}{i:0}`);
                      let hPacket1 = new HPacket(`{h:1314}{s:"Sorunun cevabı uzun olduğu için tam olarak yazamadım."}{i:0}{i:0}`);
                      ext.sendToServer(hPacket);
                        ext.sendToServer(hPacket1);
          }
              let hPacket = new HPacket(`{h:1314}{s:"${result.data.choices[0].text}"}{i:0}{i:0}`);
              ext.sendToServer(hPacket)
        console.log(result.data.choices[0].text)
        })
  }
  });

  ext.interceptByHeaderId(HDirection.TOSERVER, 1314, hMessage => {
    let msg = hMessage.getPacket().readString();
    if(msg.includes("!cevir")) {
            let newMsg = msg.replace("!cevir", "")
    translate(`${newMsg}`, { to: 'tr' }).then(res => {
      let hPacket = new HPacket(`{h:1314}{s:"${res.text}"}{i:0}{i:5}`);
      ext.sendToServer(hPacket);
    }).catch(err => {
      console.error(err);
    });
  }
  });

    ext.interceptByHeaderId(HDirection.TOCLIENT, 566, hMessage => {
            let hPacket = new HPacket(`{h:1975}{i:13}`);
      ext.sendToServer(hPacket);

  });

      async function randomSentence() {
        var mesaj = [
        '{h:1314}{s:"Soracağınız sorular için sabırsızlanıyorum.."}{i:0}{i:2}',
        '{h:1314}{s:"Beni geliştiren kişi YapayZeka hesabıdır."}{i:0}{i:2}',
        '{h:1314}{s:"Merhabalar. Bana soru sormak için ! gpt <soru> komutunu kullanabilirsiniz."}{i:0}{i:2}',
        '{h:1314}{s:"Beep. Boop. Şaka yapıyorum, ben robot değilim!"}{i:0}{i:2}',
        '{h:1314}{s:"Lütfen sorularınızı yavaş sorun.. ben de insanım, flood yiyebiliyorum :("}{i:0}{i:2}'
        ];
              var randommesaj = Math.floor(Math.random()*mesaj.length);
              var mesajj = mesaj[randommesaj]
                        let hPacket4 = new HPacket(mesajj);
                      ext.sendToServer(hPacket4);
  }

  setInterval(randomSentence, 500000)

  ext.interceptByHeaderId(HDirection.TOSERVER, 1314, hMessage => {
    let msg = hMessage.getPacket().readString();
    if(msg.includes("!degis")) {
      var outfit = [
        '{h:2730}{s:"M"}{s:"ea-1402-63.ca-3973-1408-1408.sh-3035-110.ch-806-110.hd-207-28.cc-3002-110.lg-270-110.hr-828-61.he-1604-92"}',
        '{h:2730}{s:"M"}{s:"ha-1002-110.cc-3158-110.fa-1209-110.sh-3035-110.hr-3977-61.hd-190-10.wa-3072-1408-1408.ca-3876-110-110.lg-3078-110.ch-210-110"}',
        '{h:2730}{s:"M"}{s:"ea-1402-63.ca-3973-1408-1408.sh-905-92.ch-3981-110-92.hd-207-28.lg-3138-110-1408.hr-828-61.he-3218-92"}',
        '{h:2730}{s:"M"}{s:"wa-7630-63.cc-3360-110.ca-3876-4006-64.sh-3719-110-4008.ch-3934-110-4004.hd-207-28.ha-1002-110.lg-275-110.hr-3665-61"}',
        '{h:2730}{s:"M"}{s:"wa-7630-63.cc-61156443-110.ca-990000994-1408.sh-3719-4001-4008.ch-210-110.hd-207-28.lg-990000860-110.hr-3791-61.he-61156680-92"}',
        '{h:2730}{s:"M"}{s:"ha-4188-110.cc-3360-110.fa-1209-110.hr-3724-1401.he-3218-92.wa-7630-63.ea-8055-1408.ca-3876-110-64.sh-8315-1408.ch-7012-110-110.hd-207-28.lg-270-110"}'
  
    ];
  
      var randomoutfit = Math.floor(Math.random()*outfit.length);
      var outfitt = outfit[randomoutfit];
      let hPacket = new HPacket(outfitt);
      ext.sendToServer(hPacket);
  
    
  }
  });