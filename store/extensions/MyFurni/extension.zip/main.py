                      
   
                                                                                  

                                                                                  
                                                                                  
                                                                

                                                                             
                                                                                  

                                                               
   
from __future__ import annotations

import json
import math
import os
import queue
import sys
import threading
import time
import urllib.request
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Optional

BASE_DIR = Path(__file__).resolve().parent
CONFIG_PATH = BASE_DIR / "config.json"
FURNIDATA_CACHE = BASE_DIR / "furnidata_cache.json"
STARTUP_LOG = BASE_DIR / "startup.log"
_STARTUP_LOG_LOCK = threading.Lock()


def startup_log(message: str, *, exc_info: bool = False) -> None:
                                                                                       
    try:
        stamp = time.strftime("%Y-%m-%d %H:%M:%S")
        detail = f"[{stamp}] [pid={os.getpid()}] {message}"
        if exc_info:
            import traceback
            detail += "\n" + traceback.format_exc()
        with _STARTUP_LOG_LOCK:
            with STARTUP_LOG.open("a", encoding="utf-8") as fh:
                fh.write(detail.rstrip() + "\n")
                fh.flush()
    except Exception:
                                                                     
        pass


                                                                                  
_ORIGINAL_EXCEPTHOOK = sys.excepthook

def _startup_excepthook(exc_type, exc_value, exc_tb):
    try:
        import traceback
        startup_log("UNCAUGHT PYTHON EXCEPTION\n" + "".join(
            traceback.format_exception(exc_type, exc_value, exc_tb)))
    finally:
        _ORIGINAL_EXCEPTHOOK(exc_type, exc_value, exc_tb)

sys.excepthook = _startup_excepthook
if hasattr(threading, "excepthook"):
    _ORIGINAL_THREAD_EXCEPTHOOK = threading.excepthook
    def _startup_thread_excepthook(args):
        try:
            import traceback
            startup_log(f"UNCAUGHT THREAD EXCEPTION ({args.thread.name})\n" + "".join(
                traceback.format_exception(args.exc_type, args.exc_value, args.exc_traceback)))
        finally:
            _ORIGINAL_THREAD_EXCEPTHOOK(args)
    threading.excepthook = _startup_thread_excepthook

try:
    from g_python.gextension import Extension
    try:                                                 
        from g_python.gextension import ConsoleColour
    except ImportError:                                                         
        class ConsoleColour:
            BLACK, BLUE, GREEN, ORANGE, RED = "black", "blue", "green", "orange", "red"
    from g_python.hmessage import Direction, HMessage
    from g_python.hpacket import HPacket
    from g_python.hparsers import HInventoryItem, read_stuff
    from g_python.htools import Inventory, RoomFurni
except BaseException:
    startup_log("G-Python import/dependency failure", exc_info=True)
    raise

                                                                                        
                                                                                    
                                                                                  
                                  
                                                                                        
CHAT_OUT = "Chat"                                                                                   
MP_SEARCH_OUT = "GetMarketplaceOffers"                                                                        
MP_OFFERS_IN = "MarketPlaceOffers"                                                                          
MP_MAKEOFFER_OUT = "MakeOffer"                                                                                                    
MP_MAKEOFFER_RESULT = "marketplacemakeofferresult"
RECYCLE_OUT = "RecycleItems"
RECYCLE_BATCH = 8
MP_OWN_OFFERS_OUT = "GetMarketplaceOwnOffers"
MP_OWN_OFFERS_IN = "MarketPlaceOwnOffers"                                                              
INVENTORY_REQUEST_OUT = "RequestFurniInventory"                                                
INVENTORY_LIST_IN = "FurniList"                                                                

EXTENSION_INFO = {
    "title": "MyFurni",
    "description": "Habbo inventory and Marketplace listings with market insights",
    "version": "1.5.1",
    "author": "floppidity",
}

PRICE_MODES = {"avg": "MP AVG", "current": "Current", "both": "Both"}


                                                                                        
                                                       
                                                                                        
DEFAULT_SETTINGS = {
    "price_mode": "avg",                                                                   
    "request_interval": 1.5,                                                                
    "request_timeout": 8.0,                                                         
    "request_retries": 1,                                                 
    "sort_type": 1,                                                                  
    "search_header_id": 0,
    "own_listings_header_id": 0,                                                                                   
    "offers_header_id": 0,
    "makeoffer_header_id": 0,                                                                     
    "list_interval": 2.0,                                                        
    "list_timeout": 10.0,                                                                    
    "list_success_code": 1,                                                                            
    "ui_font": "",                                                                                       
    "custom_frame": True,                                                                       
    "list_skip_estimated": True,                                                                                                                                                            
    "furnidata_url": "https://www.habbo.com/gamedata/furnidata_json/1",
    "furnidata_path": "",
    "furnimatic_max_avg": 3,
    "furnimatic_interval": 1.5,
    "furnimatic_timeout": 2.5,
    "recycle_header_id": 0,
    "buy_header_id": 0,
    "buy_timeout": 8.0,
    "furnimatic_negate_ids": True,
    "market_hotel": "com",                                                                  
}


class Settings:
    def __init__(self, path: Path = CONFIG_PATH):
        self.path = path
        self._lock = threading.Lock()
        self.data = dict(DEFAULT_SETTINGS)
        self.load()

    def load(self) -> None:
        try:
            with open(self.path, "r", encoding="utf-8") as fh:
                stored = json.load(fh)
            if isinstance(stored, dict):
                self.data.update({k: v for k, v in stored.items() if k in DEFAULT_SETTINGS})
        except FileNotFoundError:
            self.save()
        except (OSError, ValueError) as exc:
            print(f"[settings] could not read {self.path}: {exc} - using defaults", file=sys.stderr)
        if self.data["price_mode"] not in PRICE_MODES:
            self.data["price_mode"] = "avg"

    def save(self) -> None:
        with self._lock:
            tmp = self.path.with_suffix(".tmp")
            try:
                with open(tmp, "w", encoding="utf-8") as fh:
                    json.dump(self.data, fh, indent=2)
                os.replace(tmp, self.path)
            except OSError as exc:
                print(f"[settings] could not save {self.path}: {exc}", file=sys.stderr)

    def __getitem__(self, key: str):
        return self.data[key]

    def set(self, key: str, value) -> None:
        self.data[key] = value
        self.save()


                                                                                        
                              
                                                                                        
class MarketplaceParseError(Exception):
    pass


@dataclass
class OfferRow:
    offer_id: int
    kind: int                                 
    type_id: int                                                  
    price: int                                                    
    time_left: int
    average: int                                                                  
    count: int
    classname: str = ""                                       # only set for collectible (kind 5) offers
    extra: str = ""                                           # trophy/stuff text: owner<TAB>date<TAB>message

    @property
    def is_floor(self) -> bool:
        return self.kind == 1


def parse_offers(packet: HPacket) -> list[OfferRow]:
       
                                                                    

                                                                
                            
                                                                             
                                                                                 
                                                                                       
                                                                                   
                                              
       
    packet.reset()
    try:
        count = packet.read_int()
        if not 0 <= count <= 5000:
            raise MarketplaceParseError(f"implausible row count {count}")
        rows: list[OfferRow] = []
        for _ in range(count):
            offer_id, _status, kind = packet.read("iii")
            classname = ""
            extra = ""
            if kind in (1, 4):
                type_id = packet.read_int()
                category = packet.read_int()
                if category == 0:
                    # Legacy stuff data is a single string; for trophies it is
                    # "owner<TAB>date<TAB>message".
                    extra = packet.read_string()
                else:
                    read_stuff(packet, category)
                if kind == 4:
                    packet.read("B")
                kind = 1
            elif kind == 2:
                type_id = packet.read_int()
                packet.read_string()
            elif kind == 5:
                # Collectibles Marketplace (NFT-style items). Layout, taken from a
                # captured packet: STRING classname, INT furni type id, INT (always 1
                # so far), then the usual price/time/average/count.
                classname = packet.read_string()
                type_id = packet.read_int()
                packet.read_int()
            elif kind == 3:
                type_id = packet.read_int()
                packet.read("ii")
                kind = 1
            else:
                raise MarketplaceParseError(f"unsupported offer kind {kind}")
            price, time_left, average, offers = packet.read("iiii")
            if price < 0 or average < 0 or offers < 0:
                raise MarketplaceParseError("negative price/average/count")
            rows.append(OfferRow(offer_id, kind, type_id, price, time_left, average, offers, classname, extra))
                                                       
        remaining = len(packet.bytearray) - packet.read_index
        if remaining == 4:
            packet.read_int()
        elif remaining != 0:
            raise MarketplaceParseError(f"{remaining} unread bytes after parsing")
        return rows
    except MarketplaceParseError:
        raise
    except Exception as exc:                                         
        raise MarketplaceParseError(f"malformed packet: {exc}") from exc
    finally:
        packet.reset()


                                                                                        
            
                                                                                        
Key = tuple[bool, int]                              


@dataclass
class PriceInfo:
    state: str = "pending"                                                             
    average: Optional[int] = None                                       
    current: Optional[int] = None                              
    listings: int = 0
    message: str = ""
    avg_real: bool = False                                                                  


@dataclass
class FurniGroup:
    key: Key
    name: str
    classname: str
    quantity: int = 0
    marketable: int = 0                                                                 
    listable_ids: list[int] = field(default_factory=list)                                          
    price: PriceInfo = field(default_factory=PriceInfo)

    def unit(self, metric: str) -> Optional[int]:
        if self.price.state != "ok":
            return None
        return self.price.average if metric == "avg" else self.price.current

    def total(self, metric: str) -> Optional[int]:
        unit = self.unit(metric)
        return None if unit is None else unit * self.quantity


def fmt_c(value: Optional[int]) -> str:
    return "-" if value is None else f"{value:,}c"


                                                                                        
                                                            
                                                                                        
def load_furnidata(settings: Settings, log: Callable[[str], None]) -> dict[Key, tuple[str, str]]:
    raw = None
    local = settings["furnidata_path"] or str(BASE_DIR / "furnidata.json")
    try:
        if local and Path(local).is_file():
            raw = json.loads(Path(local).read_text(encoding="utf-8"))
        elif FURNIDATA_CACHE.is_file() and time.time() - FURNIDATA_CACHE.stat().st_mtime < 7 * 86400:
            raw = json.loads(FURNIDATA_CACHE.read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        log(f"furnidata cache unreadable: {exc}")
    if raw is None:
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                          "(KHTML, like Gecko) Chrome/124.0 Safari/537.36",
            "Accept": "application/json,text/plain,*/*", "Accept-Language": "en-US,en;q=0.9",
            "Referer": "https://www.habbo.com/", "Origin": "https://www.habbo.com"}
        try:
            req = urllib.request.Request(settings["furnidata_url"], headers=headers)
            with urllib.request.urlopen(req, timeout=30) as resp:
                body = resp.read()
        except Exception as exc:
            raise RuntimeError(
                f"{exc}. Habbo blocked the download. Open {settings['furnidata_url']} in your browser, "
                f"save the page as furnidata.json next to the extension and restart it.") from exc
        raw = json.loads(body.decode("utf-8"))
        try:
            FURNIDATA_CACHE.write_bytes(body)
        except OSError:
            pass
    names: dict[Key, tuple[str, str]] = {}
    for section, is_floor in (("roomitemtypes", True), ("wallitemtypes", False)):
        for entry in raw.get(section, {}).get("furnitype", []):
            try:
                names[(is_floor, int(entry["id"]))] = (str(entry.get("classname", "")),
                                                       str(entry.get("name") or entry.get("classname", "")))
            except (KeyError, ValueError, TypeError):
                continue
    if not names:
        raise ValueError("furnidata contained no furniture entries")
    return names


                                                                                        
                                                        
                                                                                        
class MarketplaceService:
       
                                      
                                                                                    
                                                                                          
                                                                                        
                                                                                         
                                                 
       

    def __init__(self, ext: Extension, settings: Settings, on_update: Callable[[], None],
                 log: Callable[[str], None]):
        self.ext, self.settings, self.on_update, self.log = ext, settings, on_update, log
        self.cache: dict[Key, PriceInfo] = {}
        self._queue: "queue.Queue[str]" = queue.Queue()
        self._pending: dict[str, set[Key]] = {}
        self._lock = threading.Lock()
        self._inflight: Optional[str] = None
        self._answer = threading.Event()
        self._result: Optional[list[OfferRow] | Exception] = None
        self.last_raw: Optional[bytes] = None
        self._last_sent = 0.0
        self._search_lock = threading.Lock()
        self.outstanding = 0
        self._buy_lock = threading.Lock()
        self._buy_awaiting = False
        self._buy_event = threading.Event()
        self._buy_values: list[int] = []
        self._buy_raw = b""
        self._buy_offer_id = 0
        ext.intercept(Direction.TO_CLIENT, self._on_buy_incoming)
        ext.intercept(Direction.TO_CLIENT, self._on_offers, MP_OFFERS_IN)
        override = int(settings["offers_header_id"] or 0)
        if override:
            ext.intercept(Direction.TO_CLIENT, self._on_offers, override)
        ext.on_event("connection_start", self.report_headers)
        threading.Thread(target=self._worker, name="mp-worker", daemon=True).start()

                                 
    def resolve_header(self, name: str, direction: Direction, override_key: str) -> tuple[Optional[int], str]:
        override = int(self.settings[override_key] or 0)
        if override:
            return override, f"config {override_key}"
        if getattr(self.ext, "connection_info", None) is None:
            return None, "G-Earth is not connected to a Habbo client (reconnect to the hotel through G-Earth)"
        infos = getattr(self.ext, "packet_infos", None)
        if not infos:
            return None, "G-Earth sent no packet names (reconnect to the hotel while the extension is running)"
        table = infos.get(direction, {})
        entries = table.get(name)
        if not entries:
            for key, val in table.items():
                if isinstance(key, str) and key.lower() == name.lower() and val:
                    entries = val
                    break
        if not entries:
            return None, (f"G-Earth does not know a packet named '{name}' for this client version; "
                          f"find its header ID in the G-Earth packet log and set '{override_key}' in config.json")
        return int(entries[0]["Id"]), "G-Earth/Harble name"

    def report_headers(self) -> None:
        startup_log("Habbo connection_start event received; resolving Marketplace packet headers")
        out_id, out_src = self.resolve_header(MP_SEARCH_OUT, Direction.TO_SERVER, "search_header_id")
        in_id, in_src = self.resolve_header(MP_OFFERS_IN, Direction.TO_CLIENT, "offers_header_id")
        own_id, own_src = self.resolve_header(MP_OWN_OFFERS_OUT, Direction.TO_SERVER, "own_listings_header_id")
        ok = out_id is not None and in_id is not None
        self.ext.write_to_console(
            f"{MP_SEARCH_OUT} -> {out_id if out_id is not None else 'UNRESOLVED: ' + out_src}; "
            f"{MP_OFFERS_IN} -> {in_id if in_id is not None else 'UNRESOLVED: ' + in_src}; "
            f"{MP_OWN_OFFERS_OUT} -> {own_id if own_id is not None else 'UNRESOLVED: ' + own_src}",
            ConsoleColour.GREEN if ok else ConsoleColour.RED)

                      
    def request(self, group: FurniGroup) -> None:
        key = group.key
        with self._lock:
            cached = self.cache.get(key)
            if cached is not None and cached.state in ("ok", "none"):
                group.price = cached
                return
            if group.marketable <= 0:
                group.price = PriceInfo("blocked", message="Not tradeable on Marketplace")
                return
            if not group.name:
                group.price = PriceInfo("error", message="Unknown furniture name")
                return
            group.price = self.cache.setdefault(key, PriceInfo("pending"))
            if group.price.state == "loading":
                return
            group.price.state = "loading"
            query = group.name
            first = query not in self._pending
            self._pending.setdefault(query, set()).add(key)
            self.outstanding += 1
        if first:
            self._queue.put(query)

                             
    def _on_offers(self, message: HMessage) -> None:
        with self._lock:
            if self._inflight is None:
                return                                                                             
        message.is_blocked = True                                                                    
        self.last_raw = bytes(message.packet.bytearray)
        try:
            self._result = parse_offers(message.packet)
        except MarketplaceParseError as exc:
            self._result = exc
        self._answer.set()

                             
    def _worker(self) -> None:
        while True:
            query = self._queue.get()
            with self._lock:
                keys = self._pending.pop(query, set())
            if not keys:
                continue
            with self._search_lock:
                rows, error = self._search(query)
            with self._lock:
                for key in keys:
                                                                                            
                    self.cache[key].__dict__.update(self._resolve(key, rows, error).__dict__)
                    self.outstanding -= 1
            self.on_update()

    def search_marketplace(self, query: str, callback: Callable[[Optional[list[OfferRow]], str], None]) -> None:
        """Run an interactive search without racing the background inventory price worker."""
        query = str(query).strip()
        if not query:
            callback([], "Enter a furniture name to search.")
            return

        def run():
            with self._search_lock:
                rows, error = self._search(query)
            callback(rows, error)

        threading.Thread(target=run, name="myfurni-market-search", daemon=True).start()

    def _search(self, query: str) -> tuple[Optional[list[OfferRow]], str]:
        error = "no response"
        for _attempt in range(1 + int(self.settings["request_retries"])):
            wait = self.settings["request_interval"] - (time.monotonic() - self._last_sent)
            if wait > 0:
                time.sleep(wait)
            self._answer.clear()
            self._result = None
            with self._lock:
                self._inflight = query
            header, why = self.resolve_header(MP_SEARCH_OUT, Direction.TO_SERVER, "search_header_id")
            if header is None:
                with self._lock:
                    self._inflight = None
                return None, why                                                                
            packet = HPacket(header, -1, -1, query, int(self.settings["sort_type"]), True)
            sent = self.ext.send_to_server(packet)
            self._last_sent = time.monotonic()
                                                                                                      
            if sent is False:
                with self._lock:
                    self._inflight = None
                return None, (f"G-Earth refused packet id {header} ({why}); is the client connected "
                              f"through G-Earth? Try reconnecting, see the G-Earth console")
            got = self._answer.wait(self.settings["request_timeout"])
            with self._lock:
                self._inflight = None
            if not got:
                error = f"timed out after {self.settings['request_timeout']}s"
                continue
            if isinstance(self._result, Exception):
                return None, str(self._result)                                           
            return self._result, ""
        return None, error

    @staticmethod
    def _resolve(key: Key, rows: Optional[list[OfferRow]], error: str) -> PriceInfo:
        if rows is None:
            return PriceInfo("error", message=error)
        match = [r for r in rows if r.kind != 5 and (r.type_id, r.is_floor) == (key[1], key[0])]
        if not match:
            return PriceInfo("none", message="No active listings")
        current = min(r.price for r in match)
        weight = sum(r.count for r in match)
        if any(r.average > 0 for r in match) and weight > 0:
            average = round(sum(r.average * r.count for r in match) / weight)
            note = ""
        else:
            average = round(sum(r.price * max(r.count, 1) for r in match) / max(weight, len(match)))
            note = "No sales average reported by the Marketplace - MP AVG falls back to the listing price"
        return PriceInfo("ok", average=average, current=current, listings=weight, message=note,
                         avg_real=(note == ""))

    # ---- buying an offer ----
    BUY_NAMES = ("BuyMarketplaceOffer", "BuyOffer")

    def _is_buy_result(self, header_id: int) -> bool:
        infos = (getattr(self.ext, "packet_infos", None) or {}).get(Direction.TO_CLIENT, {})
        for elem in infos.get(header_id, []):
            name = (elem.get("Name") or "").replace("_", "").lower()
            if "buy" in name and "result" in name and "offer" in name:
                return True
        return False

    def _on_buy_incoming(self, message: HMessage) -> None:
        if not self._buy_awaiting:
            return
        packet = message.packet
        if not self._is_buy_result(packet.header_id()):
            return
        self._buy_raw = bytes(packet.bytearray)
        values = []
        try:
            packet.reset()
            for _ in range(4):
                values.append(packet.read_int())
        except Exception:
            pass
        finally:
            try:
                packet.reset()
            except Exception:
                pass
        # Result layout (confirmed from a capture): code, next offer id, next price, requested offer id.
        # Ignore results that belong to a different offer than the one being bought.
        if len(values) == 4 and values[3] != self._buy_offer_id:
            return
        self._buy_values = values
        self._buy_event.set()

    def buy_offer(self, offer_id: int, callback: Callable[[bool, str, bool], None]) -> None:
        """Buy one Marketplace offer. callback(success, message, should_refresh) runs on a worker thread."""
        def run():
            with self._buy_lock:
                header, why = None, ""
                for name in self.BUY_NAMES:
                    header, why = self.resolve_header(name, Direction.TO_SERVER, "buy_header_id")
                    if header is not None:
                        break
                if header is None:
                    callback(False, f"{why}. Find the buy packet's header ID in the G-Earth log and set "
                                    f"'buy_header_id' in config.json.", False)
                    return
                self._buy_event.clear()
                self._buy_values = []
                self._buy_offer_id = int(offer_id)
                self._buy_awaiting = True
                try:
                    sent = self.ext.send_to_server(HPacket(header, int(offer_id)))
                except Exception as exc:
                    self._buy_awaiting = False
                    callback(False, f"Could not send the buy request: {exc}", False)
                    return
                if sent is False:
                    self._buy_awaiting = False
                    callback(False, "G-Earth refused the buy packet; reconnect through G-Earth and try again.", False)
                    return
                got = self._buy_event.wait(float(self.settings["buy_timeout"]))
                self._buy_awaiting = False
            if not got:
                callback(False, "No confirmation from Habbo. The purchase may or may not have gone through - "
                                "check your inventory/credits before retrying.", True)
                return
            code = self._buy_values[0] if self._buy_values else None
            if code == 1:
                callback(True, "Purchase successful.", True)
            elif code == 2:
                new_price = self._buy_values[2] if len(self._buy_values) > 2 else None
                extra = f" New price: {new_price:,}c." if new_price and new_price > 0 else ""
                callback(False, f"The offer changed before you bought it (refreshed).{extra} Nothing was bought.", True)
            elif code == 3:
                callback(False, "That offer is no longer available (already sold or expired).", True)
            elif code == 4:
                callback(False, "You can't afford that offer.", False)
            else:
                callback(False, f"Unexpected response (code {code}, raw: {self._buy_raw.hex(' ')}).", True)

        threading.Thread(target=run, name="myfurni-buy", daemon=True).start()

    def debug_dump(self) -> None:
        self.report_headers()
        info = (self.ext.packet_infos or {}).get(Direction.TO_CLIENT, {}).get(MP_OFFERS_IN)
        self.ext.write_to_console(f"{MP_OFFERS_IN} G-Earth info: {info}", ConsoleColour.BLUE)
        if self.last_raw is None:
            self.ext.write_to_console("No Marketplace response captured yet - open :inv first.",
                                      ConsoleColour.ORANGE)
            return
        self.ext.write_to_console(f"raw ({len(self.last_raw)} bytes): {self.last_raw[:240].hex(' ')}",
                                  ConsoleColour.BLUE)
        try:
            rows = parse_offers(HPacket.from_bytes(self.last_raw))
            self.ext.write_to_console(f"parsed {len(rows)} rows; first: {rows[:3]}", ConsoleColour.GREEN)
        except MarketplaceParseError as exc:
            self.ext.write_to_console(f"parse failed: {exc}", ConsoleColour.RED)


                                                                                        
                                                                            
                                                                                        
@dataclass
class OwnListing:
    offer_id: int
    kind: int
    type_id: int
    price: int
    time_left: int
    average: int
    name: str = "Unknown furniture"
    classname: str = ""
    status: int = 1
    sold_timestamp: int = 0
    ltd_unit: int = 0
    ltd_max: int = 0

    @property
    def key(self) -> Key:
        return (self.kind == 1, self.type_id)


def parse_own_offers(packet: HPacket) -> tuple[int, list[OwnListing]]:
    packet.reset()
    try:
        credits_waiting = packet.read_int()
        count = packet.read_int()
        if not 0 <= count <= 5000:
            raise MarketplaceParseError(f"implausible own-listing count {count}")
        rows = []
        for _ in range(count):
            offer_id = packet.read_int()
            status = packet.read_int()
            kind = packet.read_int()
            type_id = 0
            ltd_unit = 0
            ltd_max = 0

            if kind in (1, 4):
                type_id = packet.read_int()
                category = packet.read_int()
                read_stuff(packet, category)
                if kind == 4:
                    packet.read("B")
                kind = 1
            elif kind == 2:
                type_id = packet.read_int()
                packet.read_string()
            elif kind == 5:
                # Collectible listing: STRING classname, INT type id, INT (always 1).
                packet.read_string()
                type_id = packet.read_int()
                packet.read_int()
                kind = 1
            elif kind == 3:
                type_id = packet.read_int()
                ltd_unit, ltd_max = packet.read("ii")
                kind = 1
            else:
                raise MarketplaceParseError(f"unsupported offer kind {kind} on offer {offer_id}")

            price, time_left, average = packet.read("iii")
            sold_timestamp = packet.read("q")[0] if status in (2, 3) else 0
            if price < 0 or average < 0:
                raise MarketplaceParseError(f"negative price/average on offer {offer_id}")
            rows.append(OwnListing(
                offer_id, kind, type_id, price, time_left, average,
                status=status, sold_timestamp=sold_timestamp,
                ltd_unit=ltd_unit, ltd_max=ltd_max
            ))

        remaining = len(packet.bytearray) - packet.read_index
        if remaining not in (0, 4):
            raise MarketplaceParseError(f"{remaining} unread bytes after parsing own listings")
        if remaining == 4:
            packet.read_int()
        return credits_waiting, rows
    except MarketplaceParseError:
        raise
    except Exception as exc:
        raise MarketplaceParseError(f"malformed own-listings packet: {exc}") from exc
    finally:
        packet.reset()


@dataclass
class ListingJob:
    name: str
    kind: int
    item_ids: list[int]
    price: int

    @property
    def quantity(self) -> int:
        return len(self.item_ids)


class ListingService:
       
                                                                                                     
                                                                                                
                                                                                                  
                                                                               
                                                                                                      
                                                       
       

    def __init__(self, ext: Extension, settings: Settings, market: MarketplaceService,
                 on_update: Callable[[], None], log: Callable[[str], None]):
        self.ext, self.settings, self.market, self.on_update, self.log = ext, settings, market, on_update, log
        self.running = False
        self.total = self.done = 0
        self.credits = 0
        self.status = ""
        self._stop = threading.Event()
        self._awaiting = False
        self._event = threading.Event()
        self._code: Optional[int] = None
        self._raw = b""
        ext.intercept(Direction.TO_CLIENT, self._on_incoming)                                         

    def _is_result(self, header_id: int) -> bool:
        infos = (getattr(self.ext, "packet_infos", None) or {}).get(Direction.TO_CLIENT, {})
        for elem in infos.get(header_id, []):
            if (elem.get("Name") or "").replace("_", "").lower() == MP_MAKEOFFER_RESULT:
                return True
        return False

    def _on_incoming(self, message: HMessage) -> None:
        if not self._awaiting:
            return
        packet = message.packet
        if not self._is_result(packet.header_id()):
            return
        message.is_blocked = True                                                                  
        self._raw = bytes(packet.bytearray)
        try:
            self._code = packet.read_int()
        except Exception:
            self._code = None
        packet.reset()
        self._event.set()

    def start(self, jobs: list[ListingJob]) -> bool:
        if self.running or not jobs:
            return False
        self.running = True
        self.total = sum(job.quantity for job in jobs)
        self.done = 0
        self.credits = 0
        self.status = f"Listing 0/{self.total} items..."
        self._stop.clear()
        threading.Thread(target=self._run, args=(jobs,), name="mp-lister", daemon=True).start()
        self.on_update()
        return True

    def stop(self) -> None:
        self._stop.set()

    def _finish(self, text: str, colour=ConsoleColour.BLACK) -> None:
        self.running = False
        self._awaiting = False
        self.status = text
        self.log(text, colour)
        self.on_update()

    def _run(self, jobs: list[ListingJob]) -> None:
        for job in jobs:
            if self._stop.is_set():
                return self._finish(f"Stopped. Listed {self.done}/{self.total} items.", ConsoleColour.ORANGE)
            header, why = self.market.resolve_header(MP_MAKEOFFER_OUT, Direction.TO_SERVER, "makeoffer_header_id")
            if header is None:
                return self._finish(f"Stopped after {self.done}: {why}", ConsoleColour.RED)
            self._event.clear()
            self._code = None
            self._awaiting = True
            sent = self.ext.send_to_server(HPacket(header, job.price, job.kind, job.quantity, *job.item_ids))
            if sent is False:
                return self._finish(f"Stopped after {self.done}: G-Earth refused the MakeOffer packet", ConsoleColour.RED)
            got = self._event.wait(float(self.settings["list_timeout"]))
            self._awaiting = False
            if not got:
                return self._finish(f"Stopped after {self.done}: no confirmation for '{job.name}' "
                                    f"(it may or may not have been listed - check your Marketplace offers)",
                                    ConsoleColour.RED)
            if self._code != int(self.settings["list_success_code"]):
                return self._finish(f"Stopped after {self.done}: server answered code {self._code} for "
                                    f"'{job.name}' (raw: {self._raw.hex(' ')})", ConsoleColour.RED)
            self.done += job.quantity
            self.credits += job.price * job.quantity
            self.status = (f"Listing {self.done}/{self.total} items... "
                           f"({job.quantity}x {job.name} at {job.price}c each)")
            self.on_update()
            if self._stop.wait(float(self.settings["list_interval"])):
                return self._finish(f"Stopped. Listed {self.done}/{self.total} items.", ConsoleColour.ORANGE)
        self._finish(f"Done: listed {self.done} items in {len(jobs)} Marketplace batches, "
                     f"asking {self.credits:,}c in total.", ConsoleColour.GREEN)


                                                                                        
                                                          
                                                                                        
class MyFurniManager:
    def __init__(self, ext: Extension, settings: Settings, ui_post: Callable[[Callable], None]):
        self.ext, self.settings, self.ui_post = ext, settings, ui_post
        self.groups: dict[Key, FurniGroup] = {}
        self.names: Optional[dict[Key, tuple[str, str]]] = None
        self.furni_dimensions: dict[int, tuple[int, int]] = {}
        self.names_error = ""
        self.inventory_loading = False
        self.ui = None
        self.own_listings: list[OwnListing] = []
        self.credits_waiting = 0
        self.listings_loading = False
        self.listings_error = ""
        self._own_listings_event = threading.Event()
        self._own_listings_result = None
        self.last_own_listings_raw = None
        ext.intercept(Direction.TO_CLIENT, self._on_own_offers, MP_OWN_OFFERS_IN)
        own_override = int(settings["own_listings_header_id"] or 0)
        if own_override:
            ext.intercept(Direction.TO_CLIENT, self._on_own_offers, own_override)
        self.market = MarketplaceService(ext, settings, self._notify, self.log)
        self.lister = ListingService(ext, settings, self.market, self._on_listing_update, self.log)
        self.furnimatic_running = False
        self.furnimatic_status = ""
        self.furnimatic_done = 0
        self.furnimatic_total = 0
        self._furnimatic_stop = threading.Event()
        self._furnimatic_event = threading.Event()
        self._furnimatic_wait: set[int] = set()
        self._furnimatic_lock = threading.Lock()
        self._furnimatic_seen: list[str] = []
        self._furnimatic_sniffing = False
        ext.intercept(Direction.TO_CLIENT, self._furnimatic_sniff)
        self.inventory = Inventory(ext)
        self.inventory.on_inventory_load(self._on_inventory)
        self.room_groups: dict[Key, FurniGroup] = {}
        self.room_floor_items = []
        self.room_object_positions = []
        self.room_tiles: set[tuple[int, int]] = set()
        self.room_heightmap_ready = False
        self.room_dump_running = False
        self.room_dump_stop = threading.Event()
        self.room_dump_event = threading.Event()
        self.room_dump_waiting_id = None
        self.room_dump_result = None
        self.room_dump_status = ""
        self.room_dump_sent = 0
        self.room_dump_total = 0
        self.room_dump_last_removed = None
        self.room_dump_inventory_ids = set()
        self._inventory_refresh_event = threading.Event()
        self._inventory_refresh_error = ""
        self.room_objects_received = False
        self.room_dump_furni_data = {}
        self._last_items = []
        self.room_loading = False
        self.room_loaded = False
        self.room_error = ""
        ext.intercept(Direction.TO_CLIENT, self._on_floor_heightmap, "FloorHeightMap")
        ext.intercept(Direction.TO_CLIENT, self._on_objects, "Objects")
        ext.intercept(Direction.TO_CLIENT, self._on_furni_list_remove, "FurniListRemove")
        ext.intercept(Direction.TO_CLIENT, self._on_object_add, "ObjectAdd")
        self.room_furni = RoomFurni(ext)
        self.room_furni.on_floor_furni_load(self._on_room_floor)
        self.room_furni.on_wall_furni_load(self._on_room_wall)
        self._room_floor_seen = False
        self._room_wall_seen = False
        self._room_id = None
        self._room_generation = 0
        try:
            ext.intercept(Direction.TO_CLIENT, self._on_room_ready, "RoomReady")
        except Exception as exc:
            startup_log(f"Could not register RoomReady interceptor: {exc}")
        ext.intercept(Direction.TO_SERVER, self._on_chat, CHAT_OUT)
        ext.on_event("double_click", self.open)
        threading.Thread(target=self._load_names, daemon=True).start()

    def log(self, text: str, colour: ConsoleColour = ConsoleColour.BLACK) -> None:
        try:
            self.ext.write_to_console(text, colour)
        except Exception:
            print(text, file=sys.stderr)

    def _on_listing_update(self) -> None:
        self.ui_post(lambda: self.ui and self.ui.update_listing())

    def _on_own_offers(self, message: HMessage) -> None:
        if not self.listings_loading:
            return
        message.is_blocked = True
        self.last_own_listings_raw = bytes(message.packet.bytearray)
        try:
            self._own_listings_result = parse_own_offers(message.packet)
        except Exception as exc:
            self._own_listings_result = exc
            startup_log(f"Own Marketplace listings parse failed; raw packet: {self.last_own_listings_raw.hex(' ')}")
        self._own_listings_event.set()

    def request_own_listings(self) -> None:
        if self.listings_loading:
            return
        self.listings_loading = True
        self.listings_error = ""
        self._own_listings_event.clear()
        self._own_listings_result = None
        self.ui_post(lambda: self.ui and self.ui.update_listings())
        threading.Thread(target=self._load_own_listings, name="myfurni-own-listings", daemon=True).start()

    def _load_own_listings(self) -> None:
        header, why = self.market.resolve_header(MP_OWN_OFFERS_OUT, Direction.TO_SERVER, "own_listings_header_id")
        if header is None:
            self.listings_error = why
            self.listings_loading = False
            self.ui_post(lambda: self.ui and self.ui.update_listings())
            return
        sent = self.ext.send_to_server(HPacket(header, 1))
        if sent is False:
            self.listings_error = "G-Earth refused the own-listings request. Reconnect to Habbo through G-Earth."
        elif not self._own_listings_event.wait(float(self.settings["request_timeout"])):
            self.listings_error = "Habbo did not respond to the own-listings request. Open Marketplace > My Sales in Habbo, then refresh."
        elif isinstance(self._own_listings_result, Exception):
            self.listings_error = str(self._own_listings_result)
        else:
            self.credits_waiting, rows = self._own_listings_result
            names = self.names or {}
            for row in rows:
                row.classname, row.name = names.get(row.key, ("", f"Furniture #{row.type_id}"))
            self.own_listings = rows
        self.listings_loading = False
        self.ui_post(lambda: self.ui and self.ui.update_listings())

    def _clear_room_furniture(self, room_id=None) -> None:
        self._room_generation += 1
        self._room_id = room_id if room_id is not None else self._room_id
        self.room_groups = {}
        self.room_floor_items = []
        self.room_object_positions = []
        self.room_objects_received = False
        self.room_tiles = set()
        self.room_heightmap_ready = False
        self.room_dump_stop.set()
        self.room_dump_running = False
        self.room_dump_status = ""
        self.room_loading = False
        self.room_loaded = False
        self.room_error = ""
        self._room_floor_seen = False
        self._room_wall_seen = False
        self.ui_post(lambda: self.ui and self.ui.update_room())

    def _on_room_ready(self, message: HMessage) -> None:
        room_id = None
        try:
            packet = message.packet
            packet.reset()
            packet.read_string()
            room_id = packet.read_int()
        except Exception:
            pass
        finally:
            try:
                message.packet.reset()
            except Exception:
                pass
        if room_id is None or room_id != self._room_id:
            self._clear_room_furniture(room_id)
            startup_log(f"Room changed; cleared Room tab furniture (room_id={room_id})")

    def request_room(self) -> None:
        if self.room_loading:
            return
        self._clear_room_furniture(self._room_id)
        self.room_loading = True
        self.ui_post(lambda: self.ui and self.ui.update_room())
        try:
            self.room_furni.request()
        except Exception as exc:
            self.room_loading = False
            self.room_error = f"Could not refresh room furniture: {exc}"
            self.ui_post(lambda: self.ui and self.ui.update_room())

    @staticmethod
    def _room_item_type_id(item):
        for attr in ("type_id", "furni_id", "item_type_id", "definition_id"):
            value = getattr(item, attr, None)
            if value is not None:
                try:
                    return int(value)
                except (TypeError, ValueError):
                    pass
        return None

    def _on_room_floor(self, items) -> None:
        self._merge_room_items(items or [], True)

    def _on_room_wall(self, items) -> None:
        self._merge_room_items(items or [], False)

    def _merge_room_items(self, items, is_floor: bool) -> None:
        if self.names is None:
            self.room_error = "Furniture names are still loading. Refresh the Room tab in a moment."
        names = self.names or {}
        for item in items:
            if is_floor:
                self.room_floor_items.append(item)
            type_id = self._room_item_type_id(item)
            if type_id is None:
                continue
            key = (is_floor, type_id)
            classname, name = names.get(key, ("", f"Furniture #{type_id}"))
            group = self.room_groups.setdefault(key, FurniGroup(key, name, classname))
            group.quantity += 1
            if bool(getattr(item, "market_place_allowed", True)):
                group.marketable += 1
        if is_floor:
            self._room_floor_seen = True
        else:
            self._room_wall_seen = True
        if self.names is not None:
            for group in self.room_groups.values():
                if group.price.state == "pending":
                    self.market.request(group)
        self.room_loading = not (self._room_floor_seen and self._room_wall_seen)
        self.room_loaded = not self.room_loading
        self.ui_post(lambda: self.ui and self.ui.update_room())

    def _on_floor_heightmap(self, message: HMessage) -> None:
        packet = message.packet
        try:
            packet.reset()
            packet.read("B")
            packet.read_int()
            heightmap = packet.read_string()
            rows = [row.strip() for row in heightmap.replace("\r", "\n").split("\n") if row.strip()]
            tiles = set()
            for y, row in enumerate(rows):
                for x, cell in enumerate(row):
                    if cell.lower() != "x":
                        tiles.add((x, y))
            if tiles:
                self.room_tiles = tiles
                self.room_heightmap_ready = True
                self.ui_post(lambda: self.ui and self.ui.update_room())
        except Exception as exc:
            startup_log(f"Could not parse FloorHeightMap for Dump furni: {exc}")
        finally:
            try:
                packet.reset()
            except Exception:
                pass

    def _on_objects(self, message: HMessage) -> None:
        packet = message.packet
        positions = []
        try:
            packet.reset()
            user_count = packet.read_int()
            if not 0 <= user_count <= 100:
                raise ValueError(f"invalid Objects user count: {user_count}")
            for _ in range(user_count):
                packet.read_int()
                packet.read_string()
                furni_count = packet.read_int()
                if not 0 <= furni_count <= 10000:
                    raise ValueError(f"invalid Objects furniture count: {furni_count}")
                for _ in range(furni_count):
                    object_id, type_id, x, y, direction = packet.read("iiiii")
                    packet.read_string()
                    packet.read_string()
                    category = packet.read_int()
                    read_stuff(packet, category)
                    packet.read("iii")
                    positions.append({"id": object_id, "type_id": type_id,
                                      "x": x, "y": y, "direction": direction})
            self.room_object_positions = positions
            self.room_objects_received = True
            self.ui_post(lambda: self.ui and self.ui.update_room())
        except Exception as exc:
            startup_log(f"Could not parse Objects for Dump furni: {exc}")
        finally:
            try:
                packet.reset()
            except Exception:
                pass

    def _on_object_add(self, message: HMessage) -> None:
        try:
            packet = message.packet
            packet.reset()
            object_id, type_id, x, y, direction = packet.read("iiiii")
            object_id = abs(int(object_id))
            if self.room_dump_waiting_id is not None and object_id == abs(int(self.room_dump_waiting_id)):
                self.room_dump_result = True
                self.room_dump_event.set()
            if not any(int(item.get("id", 0)) == object_id for item in self.room_object_positions):
                self.room_object_positions.append({"id": object_id, "type_id": int(type_id),
                                                   "x": int(x), "y": int(y),
                                                   "direction": int(direction)})
                self.room_objects_received = True
        except Exception:
            pass
        finally:
            try:
                message.packet.reset()
            except Exception:
                pass

    def _on_furni_list_remove(self, message: HMessage) -> None:
        try:
            packet = message.packet
            packet.reset()
            item_id = abs(int(packet.read_int()))
            if self.room_dump_waiting_id is not None and item_id == abs(int(self.room_dump_waiting_id)):
                self.room_dump_result = True
                self.room_dump_event.set()
            with self._furnimatic_lock:
                if item_id in self._furnimatic_wait:
                    self._furnimatic_wait.discard(item_id)
                    if not self._furnimatic_wait:
                        self._furnimatic_event.set()
        except Exception:
            pass
        finally:
            try:
                message.packet.reset()
            except Exception:
                pass

    def _furnimatic_sniff(self, message: HMessage) -> None:
        if not self._furnimatic_sniffing:
            return
        try:
            header_id = message.packet.header_id()
            infos = (getattr(self.ext, "packet_infos", None) or {}).get(Direction.TO_CLIENT, {})
            names = [e.get("Name") or "?" for e in infos.get(header_id, [])] or ["?"]
            name = "/".join(names)
            if len(self._furnimatic_seen) < 60:
                self._furnimatic_seen.append(f"{name}({header_id})")
            if "recycl" in name.lower():
                self._furnimatic_event.set()
        except Exception:
            pass

    # ---- FurniMatic: recycle every inventory item whose MP AVG is below a threshold ----
    def furnimatic_plan(self, max_avg: int) -> tuple[list[list[int]], dict]:
        """Return (batches of 8 item ids, stats). Only items with a known MP AVG strictly below max_avg."""
        stats = {"matching": 0, "leftover": 0, "no_price": 0, "types": 0}
        candidates: list[tuple[int, list[int]]] = []
        for g in self.groups.values():
            if not g.listable_ids:
                continue
            if g.price.state != "ok" or g.price.average is None:
                stats["no_price"] += len(g.listable_ids)
                continue
            if g.price.average < max_avg:
                candidates.append((int(g.price.average), list(g.listable_ids)))
                stats["types"] += 1
        candidates.sort(key=lambda c: c[0])
        ids = [i for _avg, group_ids in candidates for i in group_ids]
        stats["matching"] = len(ids)
        full = len(ids) - len(ids) % RECYCLE_BATCH
        stats["leftover"] = len(ids) - full
        batches = [ids[i:i + RECYCLE_BATCH] for i in range(0, full, RECYCLE_BATCH)]
        return batches, stats

    def start_furnimatic(self, batches: list[list[int]]) -> bool:
        if self.furnimatic_running or not batches:
            return False
        self.furnimatic_running = True
        self.furnimatic_done = 0
        self.furnimatic_total = sum(len(b) for b in batches)
        self.furnimatic_status = f"FurniMatic: 0/{self.furnimatic_total} items recycled..."
        self._furnimatic_stop.clear()
        threading.Thread(target=self._run_furnimatic, args=(batches,), name="myfurni-furnimatic",
                         daemon=True).start()
        self._on_furnimatic_update()
        return True

    def stop_furnimatic(self) -> None:
        self._furnimatic_stop.set()
        self.furnimatic_status = "FurniMatic: stopping after the current batch..."
        self._on_furnimatic_update()

    def _on_furnimatic_update(self) -> None:
        self.ui_post(lambda: self.ui and self.ui.update_furnimatic())

    def _finish_furnimatic(self, text: str, colour=ConsoleColour.BLACK) -> None:
        self.furnimatic_running = False
        with self._furnimatic_lock:
            self._furnimatic_wait = set()
        self.furnimatic_status = text
        self.log(text, colour)
        self._on_furnimatic_update()
        if self.furnimatic_done:
            self.request_inventory()

    def _run_furnimatic(self, batches: list[list[int]]) -> None:
        negate = bool(self.settings["furnimatic_negate_ids"])
        total = self.furnimatic_total
        for batch in batches:
            if self._furnimatic_stop.is_set():
                return self._finish_furnimatic(
                    f"FurniMatic stopped. Recycled {self.furnimatic_done}/{total} items.", ConsoleColour.ORANGE)
            header, why = self.market.resolve_header(RECYCLE_OUT, Direction.TO_SERVER, "recycle_header_id")
            if header is None:
                return self._finish_furnimatic(
                    f"FurniMatic stopped after {self.furnimatic_done}: {why}", ConsoleColour.RED)
            wire_ids = [-abs(int(i)) if negate else int(i) for i in batch]
            with self._furnimatic_lock:
                self._furnimatic_wait = {abs(int(i)) for i in batch}
                self._furnimatic_event.clear()
            try:
                sent = self.ext.send_to_server(HPacket(header, len(wire_ids), *wire_ids))
            except Exception as exc:
                return self._finish_furnimatic(
                    f"FurniMatic stopped after {self.furnimatic_done}: could not send ({exc})", ConsoleColour.RED)
            if sent is False:
                return self._finish_furnimatic(
                    f"FurniMatic stopped after {self.furnimatic_done}: G-Earth refused the RecycleItems packet",
                    ConsoleColour.RED)
            self._furnimatic_seen = []
            self._furnimatic_sniffing = True
            got = self._furnimatic_event.wait(min(float(self.settings["furnimatic_timeout"]), 2.5))
            self._furnimatic_sniffing = False
            with self._furnimatic_lock:
                still_waiting = len(self._furnimatic_wait)
            self.log(f"FurniMatic batch sent ({len(batch)} items). Confirmed={got}, "
                     f"items still in inventory per server={still_waiting}. "
                     f"Packets seen: {', '.join(self._furnimatic_seen) or 'none'}",
                     ConsoleColour.BLUE if got else ConsoleColour.ORANGE)
            self.furnimatic_done += len(batch)
            self.furnimatic_status = f"FurniMatic: {self.furnimatic_done}/{total} items recycled..."
            self._on_furnimatic_update()
            if self._furnimatic_stop.wait(float(self.settings["furnimatic_interval"])):
                return self._finish_furnimatic(
                    f"FurniMatic stopped. Recycled {self.furnimatic_done}/{total} items.", ConsoleColour.ORANGE)
        self._finish_furnimatic(f"FurniMatic done: recycled {self.furnimatic_done} items.", ConsoleColour.GREEN)

    @staticmethod
    def _item_int(item, names):
        for name in names:
            value = getattr(item, name, None)
            if value is not None:
                try:
                    return int(value)
                except (TypeError, ValueError):
                    pass
        return None

    def _room_occupied_tiles(self):
        if not self.room_objects_received:
            raise RuntimeError("Room furniture positions have not loaded yet. Wait for the room objects to finish loading, then try again.")
        occupied = set()
        for item in self.room_object_positions:
            x = int(item["x"])
            y = int(item["y"])
            type_id = int(item["type_id"])
            width, depth = self.furni_dimensions.get(type_id, (1, 1))
            direction = int(item["direction"])
            if direction in (2, 6):
                width, depth = depth, width
            for dx in range(max(1, width)):
                for dy in range(max(1, depth)):
                    occupied.add((x + dx, y + dy))
        return occupied

    def _dump_plan(self, sellable_only=False, minimum_price=0):
        if not self.room_loaded:
            raise RuntimeError("Wait until the Room tab has finished loading.")
        if not self.room_heightmap_ready or not self.room_tiles:
            raise RuntimeError("The room floor map has not loaded. Re-enter the room and try again.")
        if not self._last_items:
            raise RuntimeError("Your inventory has not loaded yet. Open Inventory and refresh it first.")

        inventory = [item for item in self._last_items
                     if bool(getattr(item, "is_floor_furni", False))]
        if not inventory:
            raise RuntimeError("There is no floor furniture in your inventory.")

        if sellable_only:
            eligible = []
            waiting = []
            no_market_access = 0
            no_price = 0
            below_minimum = 0
            for item in inventory:
                if not bool(getattr(item, "market_place_allowed", False)):
                    no_market_access += 1
                    continue
                group = self.groups.get((True, int(item.type_id)))
                if group is None:
                    waiting.append(int(item.type_id))
                    continue
                if group.price.state in ("pending", "loading"):
                    waiting.append(int(item.type_id))
                    continue
                if group.price.state != "ok" or group.price.average is None:
                    no_price += 1
                    continue
                if int(group.price.average) < minimum_price:
                    below_minimum += 1
                    continue
                eligible.append(item)

            if waiting:
                raise RuntimeError(
                    "Marketplace prices are not ready for all inventory furniture yet. "
                    "Wait until the Inventory tab shows its prices, then try again."
                )
            if not eligible:
                raise RuntimeError(
                    f"No sellable floor furniture meets the {minimum_price:,}c MP average minimum. "
                    f"Skipped: {no_market_access} not Marketplace-enabled, "
                    f"{no_price} without a usable Marketplace price, "
                    f"{below_minimum} below the minimum."
                )
            inventory = eligible

        occupied = self._room_occupied_tiles()
        plan = []
        for item in inventory:
            type_id = int(item.type_id)
            width, depth = self.furni_dimensions.get(type_id, (1, 1))
            plan.append((int(item.id), max(1, int(width)), max(1, int(depth))))
        if not plan:
            raise RuntimeError("No eligible floor furniture was found in your inventory.")
        return plan, len(inventory), occupied

    def start_room_dump(self, sellable_only=False, minimum_price=0):
        if self.room_dump_running:
            self.room_dump_stop.set()
            self.room_dump_status = "Stopping after the current placement..."
            self.ui_post(lambda: self.ui and self.ui.update_room())
            return
        try:
            minimum_price = int(minimum_price or 0)
            if minimum_price < 0:
                raise ValueError("Minimum price cannot be negative.")
            if not self.room_loaded:
                raise RuntimeError("Wait until the Room tab has finished loading.")
            if not self.room_heightmap_ready or not self.room_tiles:
                raise RuntimeError("The room floor map has not loaded. Re-enter the room and try again.")
            if not self.room_objects_received:
                raise RuntimeError("Room furniture positions have not loaded yet. Wait for the room objects to finish loading, then try again.")
        except Exception as exc:
            self.room_dump_status = str(exc)
            self.log(f"Dump furni: {exc}", ConsoleColour.ORANGE)
            self.ui_post(lambda: self.ui and self.ui.update_room())
            return
        self.room_dump_stop.clear()
        self.room_dump_running = True
        self.room_dump_sent = 0
        self.room_dump_total = 0
        self.room_dump_status = "Refreshing inventory before dumping..."
        self._inventory_refresh_event.clear()
        self._inventory_refresh_error = ""
        self.inventory_loading = True
        self.ui_post(lambda: self.ui and self.ui.update_room())
        threading.Thread(target=self._prepare_room_dump,
                         args=(bool(sellable_only), minimum_price),
                         name="myfurni-dump-refresh", daemon=True).start()

    def _prepare_room_dump(self, sellable_only, minimum_price):
        try:
            self.request_inventory()
            timeout = max(12.0, float(self.settings["request_timeout"] or 8.0) * 2.0)
            if not self._inventory_refresh_event.wait(timeout):
                raise RuntimeError("Habbo did not return your refreshed inventory. Open Inventory and try Dump furni again.")
            if self._inventory_refresh_error:
                raise RuntimeError(self._inventory_refresh_error)
            if sellable_only:
                price_deadline = time.time() + 45.0
                while time.time() < price_deadline and not self.room_dump_stop.is_set():
                    pending_prices = [group for group in self.groups.values()
                                      if group.key[0] and group.price.state in ("pending", "loading")]
                    if not pending_prices:
                        break
                    self.room_dump_status = f"Inventory refreshed. Checking Marketplace prices ({len(pending_prices)} remaining)..."
                    self.ui_post(lambda: self.ui and self.ui.update_room())
                    time.sleep(0.25)
                if pending_prices:
                    raise RuntimeError("Marketplace prices did not finish loading. Refresh the Inventory tab and try again.")
            plan, inventory_count, occupied = self._dump_plan(sellable_only, minimum_price)
            if self.room_dump_stop.is_set():
                raise RuntimeError("Dump cancelled.")
            self.room_dump_total = len(plan)
            self.room_dump_status = f"Inventory refreshed: {inventory_count} floor items found. Placing 0/{len(plan)}..."
            self.ui_post(lambda: self.ui and self.ui.update_room())
            self._run_room_dump(plan, inventory_count, occupied)
            return
        except Exception as exc:
            self.room_dump_status = str(exc)
            self.log(f"Dump furni: {exc}", ConsoleColour.ORANGE)
        finally:
            if self.room_dump_running:
                self.room_dump_running = False
                self.room_dump_waiting_id = None
                self.ui_post(lambda: self.ui and self.ui.update_room())

    def _run_room_dump(self, plan, inventory_count, initially_occupied):
        used = set(initially_occupied)
        room_tiles = set(self.room_tiles)
        placed = 0
        failed_items = 0

        for item_id, width, depth in plan:
            failed_anchors = set()
            if self.room_dump_stop.is_set():
                break
            placed_this_item = False
            for y, x in sorted(room_tiles, key=lambda point: (point[1], point[0])):
                if self.room_dump_stop.is_set():
                    break
                anchor = (x, y)
                if anchor in failed_anchors:
                    continue
                footprint = {(x + dx, y + dy) for dx in range(width) for dy in range(depth)}
                if not footprint.issubset(room_tiles) or footprint.intersection(used):
                    continue

                self.room_dump_event.clear()
                self.room_dump_result = None
                self.room_dump_waiting_id = item_id
                try:
                    sent = self.ext.send_to_server(
                        HPacket("PlaceObject", f"{-abs(int(item_id))} {x} {y} 0"))
                except Exception as exc:
                    self.room_dump_status = f"Stopped: could not send placement ({exc})"
                    self.room_dump_waiting_id = None
                    break
                if sent is False:
                    self.room_dump_status = "Stopped: G-Earth refused a PlaceObject packet."
                    self.room_dump_waiting_id = None
                    break

                if not self.room_dump_event.wait(4.0):
                    failed_anchors.add(anchor)
                    self.room_dump_waiting_id = None
                    self.room_dump_status = (
                        f"Trying another tile for item {placed + 1}/{self.room_dump_total}... "
                        f"({len(failed_anchors)} unavailable tile positions skipped)")
                    self.ui_post(lambda: self.ui and self.ui.update_room())
                    continue

                if self.room_dump_result is True:
                    used.update(footprint)
                    placed += 1
                    placed_this_item = True
                    self.room_dump_sent = placed
                    self.room_dump_status = f"Placing {placed}/{self.room_dump_total} floor items..."
                    self.ui_post(lambda: self.ui and self.ui.update_room())
                    time.sleep(0.25)
                    break

                failed_anchors.add(anchor)

            if self.room_dump_status.startswith("Stopped:"):
                break
            if not placed_this_item:
                failed_items += 1
                self.log(f"Dump furni: skipped inventory item {item_id}; no available tile accepted it.",
                         ConsoleColour.ORANGE)
                self.room_dump_status = (
                    f"Skipped {failed_items} item(s) that could not be placed; "
                    f"placed {placed}/{self.room_dump_total}. Continuing...")
                self.ui_post(lambda: self.ui and self.ui.update_room())

        if self.room_dump_stop.is_set():
            self.room_dump_status = f"Stopped: placed {placed} of {self.room_dump_total} floor items."
        elif self.room_dump_status.startswith("Stopped:"):
            pass
        else:
            self.room_dump_status = (
                f"Done: placed {placed} of {self.room_dump_total} floor items."
                + (f" Skipped {failed_items} that had no accepted tile." if failed_items else ""))
        self.room_dump_waiting_id = None
        self.room_dump_running = False
        self.request_inventory()
        self.ui_post(lambda: self.ui and self.ui.update_room())

    def refresh_room_prices(self) -> None:
        for group in self.room_groups.values():
            group.price = PriceInfo("pending")
            self.market.request(group)
        self.ui_post(lambda: self.ui and self.ui.update_room())

    def load_room_insights(self, group: FurniGroup) -> None:
        listing = OwnListing(0, 1 if group.key[0] else 2, group.key[1],
                             group.price.current or 0, 0, group.price.average or 0,
                             name=group.name, classname=group.classname)
        self.load_item_insights(listing)

    def load_item_insights(self, listing: OwnListing) -> None:
        self.ui_post(lambda: self.ui and self.ui.show_item_insights(listing, loading=True))
        threading.Thread(target=self._fetch_item_insights, args=(listing,),
                         name="myfurni-item-insights", daemon=True).start()

    def _fetch_item_insights(self, listing: OwnListing) -> None:
        import urllib.parse
        results = {}
        error = ""
        if listing.classname:
            params = urllib.parse.urlencode({
                "classname": listing.classname,
                "hotel": str(self.settings["market_hotel"] or "com").strip().lower(),
                "days": "30"
            })
            url = "https://habboapi.site/api/market/history?" + params
            try:
                req = urllib.request.Request(url, headers={
                    "Accept": "application/json",
                    "User-Agent": "MyFurni/1.2"
                })
                with urllib.request.urlopen(req, timeout=15) as response:
                    results["history"] = json.loads(response.read().decode("utf-8"))
            except Exception as exc:
                error = f"Public market history is currently unavailable: {exc}"
        else:
            error = "No furniture classname is available for this item."
        self.ui_post(lambda: self.ui and self.ui.show_item_insights(
            listing, data=results, error=error))

    def listing_plan(self) -> tuple[list[ListingJob], dict]:
                                                                                                  
        jobs: list[ListingJob] = []
        skipped = {"no_price": 0, "estimated": 0, "not_tradeable": 0, "zero": 0}
        skip_est = bool(self.settings["list_skip_estimated"])
        for g in self.groups.values():
            if not g.listable_ids:
                skipped["not_tradeable"] += g.quantity
                continue
            skipped["not_tradeable"] += g.quantity - len(g.listable_ids)
            if g.price.state != "ok" or g.price.average is None:
                skipped["no_price"] += len(g.listable_ids)
            elif skip_est and not g.price.avg_real:
                skipped["estimated"] += len(g.listable_ids)
            elif g.price.average < 1:
                skipped["zero"] += len(g.listable_ids)
            else:
                kind = 1 if g.key[0] else 2
                jobs.append(ListingJob(g.name, kind, list(g.listable_ids), int(g.price.average)))
        return jobs, skipped

    def _notify(self) -> None:
        self.ui_post(lambda: self.ui and self.ui.refresh_values())

                            
    def _on_chat(self, message: HMessage) -> None:
        try:
            text = message.packet.read_string().strip().lower()
        except Exception:
            return
        if text == ":inv":
            message.is_blocked = True
            self.open()
        elif text == ":inv debug":
            message.is_blocked = True
            threading.Thread(target=self.market.debug_dump, daemon=True).start()

    def open(self) -> None:
        self.ui_post(lambda: self.ui and self.ui.show())
        self.request_inventory()

    def request_inventory(self) -> None:
        self.inventory_loading = True
        self._notify()
        self.inventory.request()

                         
    def _load_names(self) -> None:
        try:
            self.names = load_furnidata(self.settings, self.log)
            data_path = self.settings["furnidata_path"] or str(BASE_DIR / "furnidata.json")
            raw_data = None
            try:
                if Path(data_path).is_file():
                    raw_data = json.loads(Path(data_path).read_text(encoding="utf-8"))
                elif FURNIDATA_CACHE.is_file():
                    raw_data = json.loads(FURNIDATA_CACHE.read_text(encoding="utf-8"))
            except Exception:
                raw_data = None
            if raw_data:
                self.furni_dimensions = {
                    int(entry["id"]): (max(1, int(entry.get("xdim", 1))),
                                       max(1, int(entry.get("ydim", 1))))
                    for entry in raw_data.get("roomitemtypes", {}).get("furnitype", [])
                    if str(entry.get("id", "")).lstrip("-").isdigit()
                }
            self.log(f"Loaded {len(self.names)} furniture names", ConsoleColour.GREEN)
        except Exception as exc:
            self.names_error = f"{exc}"
            self.log(f"Could not load furniture names: {exc}", ConsoleColour.RED)
        if self.groups:
            self._on_inventory_items(None)
        if self.own_listings:
            for row in self.own_listings:
                row.classname, row.name = self.names.get(row.key, ("", f"Furniture #{row.type_id}"))
            self.ui_post(lambda: self.ui and self.ui.update_listings())
        if self.room_groups:
            for group in self.room_groups.values():
                group.classname, group.name = self.names.get(group.key, ("", f"Furniture #{group.key[1]}"))
                group.price = PriceInfo("pending")
                self.market.request(group)
            self.ui_post(lambda: self.ui and self.ui.update_room())

                         
    def _on_inventory(self, items: list[HInventoryItem]) -> None:
        self._on_inventory_items(items)

    def _on_inventory_items(self, items: Optional[list[HInventoryItem]]) -> None:
        if items is not None:
            self._last_items = list(items)
            self._inventory_refresh_event.set()
        groups: dict[Key, FurniGroup] = {}
        for item in self._last_items:
            key: Key = (bool(item.is_floor_furni), int(item.type_id))
            classname, name = (self.names or {}).get(key, ("", ""))
            group = groups.setdefault(key, FurniGroup(key, name, classname))
            group.quantity += 1
            if item.market_place_allowed:
                group.marketable += 1
                group.listable_ids.append(int(item.id))
        self.groups = groups
        self.inventory_loading = False
        for group in groups.values():
            if self.names is None:
                group.price = PriceInfo("error", message=f"Furniture names unavailable: {self.names_error or 'still loading'}")
            else:
                self.market.request(group)
        self.ui_post(lambda: self.ui and self.ui.rebuild())


                                                                                        
                                              
                                                                                        
def fmt_c(value):
    return "-" if value is None else f"{value:,}c"


                                                                                        
                                                                                              
                                                                                   
                                                                     
                                                               
                                                                                        
try:
    import tkinter as tk
    import tkinter.font as tkfont
    from tkinter import ttk
except BaseException:
    startup_log("Tkinter import failed", exc_info=True)
    raise

C = {
    "outline": "#000000", "frame": "#1c1c1c",
    "title": "#2f7fa3", "title_hi": "#4aa0c6", "title_lo": "#1f5f7d",
    "panel": "#cfcfcf", "panel_hi": "#ececec", "panel_lo": "#9a9a9a",
    "inset": "#ffffff", "row_a": "#ffffff", "row_b": "#ececec", "row_hover": "#d6ecf7",
    "head": "#b8b8b8", "text": "#1d1d1d", "muted": "#6b6b6b", "good": "#2b7d1f",
    "warn": "#b05a00", "bad": "#b3261e", "coin": "#f4c20d", "coin_lo": "#a67c00",
    "tip_bg": "#000000", "tip_fg": "#ffffff",
}
BUTTONS = {                                       
    "green": ("#9be05a", "#5fae2e", "#3b7a19"),
    "blue": ("#74c4ee", "#3b97cf", "#216896"),
    "red": ("#f2776c", "#cc3a2e", "#8d231a"),
    "grey": ("#f3f3f3", "#c4c4c4", "#8e8e8e"),
}
ROW_H = 42
HEAD_H = 28


def tile_colour(seed: str) -> str:
                                                                                          
    h = sum((i + 1) * ord(ch) for i, ch in enumerate(seed or "?")) % 360
    import colorsys
    r, g, b = colorsys.hsv_to_rgb(h / 360, 0.35, 0.92)
    return "#%02x%02x%02x" % (int(r * 255), int(g * 255), int(b * 255))


class PixelButton(tk.Canvas):
                                                                  

    def __init__(self, master, text, command, theme="grey", width=150, height=32, font=None, bg=None):
        super().__init__(master, width=width, height=height, highlightthickness=0, bd=0,
                         bg=bg or C["panel"], cursor="hand2")
        self.w, self.h, self.command, self.theme, self.font = width, height, command, theme, font
        self.text, self.state, self.enabled = text, "normal", True
        self.bind("<Enter>", lambda _e: self._set("hover"))
        self.bind("<Leave>", lambda _e: self._set("normal"))
        self.bind("<ButtonPress-1>", lambda _e: self._set("down"))
        self.bind("<ButtonRelease-1>", self._release)
        self.draw()

    def _set(self, state):
        if self.enabled:
            self.state = state
            self.draw()

    def _release(self, event):
        if not self.enabled:
            return
        inside = 0 <= event.x <= self.w and 0 <= event.y <= self.h
        self._set("hover" if inside else "normal")
        if inside and self.command:
            self.command()

    def configure_button(self, text=None, theme=None, enabled=None):
        if text is not None:
            self.text = text
        if theme is not None:
            self.theme = theme
        if enabled is not None:
            self.enabled = enabled
            self.configure(cursor="hand2" if enabled else "arrow")
        self.draw()

    def draw(self):
        self.delete("all")
        hi, face, lo = BUTTONS["grey"] if not self.enabled else BUTTONS[self.theme]
        if not self.enabled:
            hi, face, lo = "#dcdcdc", "#b4b4b4", "#9a9a9a"
        if self.state == "hover":
            face = hi if self.theme != "grey" else "#d8d8d8"
        down = self.state == "down" and self.enabled
        w, h = self.w, self.h
        self.create_rectangle(0, 0, w - 1, h - 1, outline=C["outline"], fill=C["outline"])
        self.create_rectangle(1, 1, w - 2, h - 2, outline=face, fill=face)
        top, bottom = (lo, hi) if down else (hi, lo)
        self.create_rectangle(1, 1, w - 2, 3, outline=top, fill=top)
        self.create_rectangle(1, h - 4, w - 2, h - 2, outline=bottom, fill=bottom)
        self.create_rectangle(0, 0, 1, 1, fill=C["panel"], outline=C["panel"])
        self.create_rectangle(w - 2, 0, w - 1, 1, fill=C["panel"], outline=C["panel"])
        colour = "#ffffff" if (self.enabled and self.theme != "grey") else ("#222222" if self.enabled else "#7a7a7a")
        y = h // 2 + (1 if down else 0)
        if self.enabled and self.theme != "grey":
            self.create_text(w // 2 + 1, y + 1, text=self.text, font=self.font, fill="#00000066" if False else lo)
        self.create_text(w // 2, y, text=self.text, font=self.font, fill=colour)


class ChoiceList(tk.Canvas):
                                                              

    def __init__(self, master, items, selected, on_change, font, small, multi=False, width=560):
        self.items, self.multi, self.on_change, self.font, self.small = items, multi, on_change, font, small
        self.selected = set(selected) if multi else selected
        super().__init__(master, width=width, height=len(items) * 54, highlightthickness=0, bd=0,
                         bg=C["panel"], cursor="hand2")
        self.bind("<Button-1>", self._click)
        self.draw()

    def _click(self, event):
        idx = event.y // 54
        if not 0 <= idx < len(self.items):
            return
        key = self.items[idx][0]
        if self.multi:
            self.selected ^= {key}
        else:
            self.selected = key
        self.draw()
        self.on_change(sorted(self.selected) if self.multi else key)

    def draw(self):
        self.delete("all")
        for i, (key, label, desc) in enumerate(self.items):
            y = i * 54
            on = key in self.selected if self.multi else key == self.selected
            self.create_rectangle(4, y + 8, 28, y + 32, fill=C["outline"], outline=C["outline"])
            self.create_rectangle(5, y + 9, 27, y + 31, fill=C["inset"], outline=C["inset"])
            if on:
                if self.multi:
                    self.create_line(9, y + 21, 15, y + 27, 26, y + 13, fill=C["good"], width=4)
                else:
                    self.create_rectangle(10, y + 14, 22, y + 26, fill=C["good"], outline=C["good"])
            self.create_text(40, y + 14, text=label, anchor="w", font=self.font, fill=C["text"])
            self.create_text(40, y + 34, text=desc, anchor="w", font=self.small, fill=C["muted"])


class HabboDialog:
                                                                                    

    def __init__(self, parent, title, text, buttons, fonts):
        self.top = tk.Toplevel(parent)
        top = self.top
        top.overrideredirect(True)
        top.configure(bg=C["outline"])
        top.attributes("-topmost", True)
        body_font, bold = fonts
        frame = tk.Frame(top, bg=C["panel"])
        frame.pack(padx=2, pady=2)
        bar = tk.Canvas(frame, height=28, width=500, highlightthickness=0, bg=C["title"])
        bar.pack(fill="x")
        bar.create_rectangle(0, 0, 500, 13, fill=C["title_hi"], outline=C["title_hi"])
        bar.create_text(12, 14, text=title, anchor="w", font=bold, fill="#ffffff")
        tk.Label(frame, text=text, justify="left", wraplength=460, bg=C["panel"], fg=C["text"], font=body_font
                 ).pack(padx=20, pady=(16, 10), anchor="w")
        row = tk.Frame(frame, bg=C["panel"])
        row.pack(pady=(4, 16))
        for label, theme, cb in buttons:
            PixelButton(row, label, lambda cb=cb: self._press(cb), theme, 170, 32, bold).pack(side="left", padx=6)
        parent.update_idletasks()
        top.update_idletasks()
        x = parent.winfo_rootx() + (parent.winfo_width() - top.winfo_width()) // 2
        y = parent.winfo_rooty() + (parent.winfo_height() - top.winfo_height()) // 3
        top.geometry(f"+{max(x, 0)}+{max(y, 0)}")
        top.lift()
        top.update()
        try:
            top.grab_set()
        except tk.TclError:
            pass

    def _press(self, cb):
        try:
            self.top.grab_release()
        except tk.TclError:
            pass
        self.top.destroy()
        if cb:
            cb()


def _flatten_market_payload(value, out=None):
    out = {} if out is None else out
    if isinstance(value, dict):
        for key, item in value.items():
            norm = str(key).replace("-", "_").replace(" ", "_").lower()
            out[norm] = item
            if isinstance(item, (dict, list)):
                _flatten_market_payload(item, out)
    elif isinstance(value, list):
        for item in value:
            _flatten_market_payload(item, out)
    return out


def _first_value(data, keys):
    for key in keys:
        value = data.get(key)
        if value is not None and not isinstance(value, (dict, list)):
            return value
    return None


def _display_market_value(value):
    if value is None:
        return "Not available"
    if isinstance(value, (int, float)):
        return f"{value:,.0f}"
    return str(value)


def _extract_history(payload):
    found = []
    def walk(value):
        if isinstance(value, dict):
            if any(k in value for k in ("trade_volume", "tradeVolume", "items_sold", "itemsSold")):
                day = value.get("date") or value.get("day") or value.get("timestamp") or value.get("day_offset") or value.get("dayOffset")
                volume = value.get("trade_volume", value.get("tradeVolume", value.get("items_sold", value.get("itemsSold", 0))))
                price = value.get("average_sale_price", value.get("averageSalePrice", value.get("average_price", value.get("averagePrice"))))
                try:
                    found.append((str(day if day is not None else len(found)), float(volume or 0), float(price) if price is not None else None))
                except (TypeError, ValueError):
                    pass
            for child in value.values():
                walk(child)
        elif isinstance(value, list):
            for child in value:
                walk(child)
    walk(payload)
    return found


def _draw_market_chart(canvas, history):
    canvas.delete("all")
    width = max(canvas.winfo_width(), 500)
    height = 220
    canvas.create_text(12, 12, anchor="nw", text="Sales volume (bars) and average sale price (line)", fill="#333333")
    if not history:
        canvas.create_text(width // 2, 110, text="No daily history returned for this item yet", fill="#777777")
        return
    history = history[-30:]
    volumes = [max(0, row[1]) for row in history]
    max_volume = max(volumes) or 1
    prices = [row[2] for row in history if row[2] is not None]
    min_price, max_price = (min(prices), max(prices)) if prices else (0, 1)
    if min_price == max_price:
        max_price += 1
    left, right, top, bottom = 42, width - 16, 34, height - 30
    step = (right - left) / max(len(history), 1)
    points = []
    for i, (day, volume, price) in enumerate(history):
        x = left + i * step + step * .15
        bar_h = (bottom - top) * volume / max_volume
        canvas.create_rectangle(x, bottom - bar_h, x + step * .7, bottom, fill="#9bc9e8", outline="")
        if price is not None:
            px = left + i * step + step * .5
            py = bottom - (price - min_price) / (max_price - min_price) * (bottom - top)
            points.extend((px, py))
    if len(points) >= 4:
        canvas.create_line(*points, fill="#d27b25", width=2, smooth=True)
    canvas.create_line(left, bottom, right, bottom, fill="#777777")
    canvas.create_text(8, top, anchor="nw", text=f"{max_volume:,.0f}", fill="#666666")
    canvas.create_text(8, bottom, anchor="sw", text="0", fill="#666666")


class InventoryWindow:
    W, H = 960, 700

    def __init__(self, root, manager):
        self.root, self.manager, self.settings = root, manager, manager.settings
        available = set(tkfont.families(root))
        family = next((f for f in (self.settings["ui_font"], "Verdana", "Tahoma", "DejaVu Sans", "Arial")
                       if f and f in available), tkfont.nametofont("TkDefaultFont").actual()["family"])
        self.f = tkfont.Font(root=root, family=family, size=10)
        self.fb = tkfont.Font(root=root, family=family, size=10, weight="bold")
        self.fs = tkfont.Font(root=root, family=family, size=8)
        self.fbig = tkfont.Font(root=root, family=family, size=18, weight="bold")
        self.sort_col, self.sort_desc = "total", True
        self.rows = []
        self.offset = 0
        self.hover_row = -1
        self.tip = None
        self.dots = 0
        self.custom_frame = bool(self.settings["custom_frame"])
        self.page = "inventory"

        root.title("MyFurni")
        root.configure(bg=C["outline"])
        if self.custom_frame:
            root.overrideredirect(True)
        root.geometry(f"{self.W}x{self.H}+120+60")
        root.protocol("WM_DELETE_WINDOW", root.withdraw)
        self._build()
        self.root.after(450, self._tick)

                                                                                     
    def _build(self):
        outer = tk.Frame(self.root, bg=C["frame"])
        outer.pack(fill="both", expand=True, padx=1, pady=1)
        self._build_title(outer)
        body = tk.Frame(outer, bg=C["panel"])
        body.pack(fill="both", expand=True, padx=3, pady=(0, 3))
        self._build_tabs(body)
        self.pages = tk.Frame(body, bg=C["panel"], highlightbackground=C["outline"], highlightthickness=1)
        self.pages.pack(fill="both", expand=True, padx=6, pady=(0, 6))
        self.inv_page = tk.Frame(self.pages, bg=C["panel"])
        self.market_page = tk.Frame(self.pages, bg=C["panel"])
        self.market_search_page = tk.Frame(self.pages, bg=C["panel"])
        self.room_page = tk.Frame(self.pages, bg=C["panel"])
        self.set_page = tk.Frame(self.pages, bg=C["panel"])
        self._build_inventory(self.inv_page)
        self._build_marketplace(self.market_page)
        self._build_market_search(self.market_search_page)
        self._build_room(self.room_page)
        self._build_settings(self.set_page)
        self.show_page("inventory")

    def _build_title(self, parent):
        bar = tk.Canvas(parent, height=34, highlightthickness=0, bg=C["title"])
        bar.pack(fill="x")
        self.title_bar = bar

        def paint(_e=None):
            w = bar.winfo_width()
            bar.delete("all")
            bar.create_rectangle(0, 0, w, 15, fill=C["title_hi"], outline=C["title_hi"])
            bar.create_rectangle(0, 30, w, 34, fill=C["title_lo"], outline=C["title_lo"])
                                     
            bar.create_rectangle(10, 8, 28, 26, fill=C["outline"], outline=C["outline"])
            bar.create_rectangle(11, 9, 27, 25, fill="#d99a4e", outline="#d99a4e")
            bar.create_rectangle(11, 15, 27, 19, fill="#a8672a", outline="#a8672a")
            bar.create_rectangle(17, 9, 21, 25, fill="#a8672a", outline="#a8672a")
            bar.create_text(37, 18, text="Inventory", anchor="w", font=self.fb, fill="#000000")
            bar.create_text(36, 17, text="Inventory", anchor="w", font=self.fb, fill="#ffffff")
            bar.create_rectangle(w - 34, 5, w - 8, 29, fill=C["outline"], outline=C["outline"])
            bar.create_rectangle(w - 33, 6, w - 9, 28, fill="#d9503f", outline="#d9503f")
            bar.create_rectangle(w - 33, 6, w - 9, 11, fill="#f08a7c", outline="#f08a7c")
            bar.create_line(w - 27, 12, w - 15, 23, fill="#ffffff", width=3)
            bar.create_line(w - 27, 23, w - 15, 12, fill="#ffffff", width=3)

        bar.bind("<Configure>", paint)

        def press(e):
            if e.x >= bar.winfo_width() - 36:
                self.root.withdraw()
            else:
                self._drag = (e.x_root - self.root.winfo_x(), e.y_root - self.root.winfo_y())

        def drag(e):
            if getattr(self, "_drag", None) and self.custom_frame:
                self.root.geometry(f"+{e.x_root - self._drag[0]}+{e.y_root - self._drag[1]}")

        bar.bind("<ButtonPress-1>", press)
        bar.bind("<B1-Motion>", drag)

    def _build_tabs(self, parent):
        tabs = tk.Canvas(parent, height=34, highlightthickness=0, bg=C["panel"])
        tabs.pack(fill="x", padx=6, pady=(8, 0))
        self.tabs = tabs
        self.tab_defs = [("inventory", "Inventory", 8), ("marketsearch", "Marketplace", 150),
                         ("marketplace", "My Listings", 292), ("room", "Room", 434),
                         ("settings", "Settings", 576)]
        tabs.bind("<Button-1>", self._tab_click)
        tabs.bind("<Configure>", lambda _e: self._paint_tabs())

    def _paint_tabs(self):
        t = self.tabs
        t.delete("all")
        for key, label, x in self.tab_defs:
            active = key == self.page
            y0 = 4 if active else 9
            fill = C["panel_hi"] if active else C["head"]
            t.create_rectangle(x, y0, x + 132, 34, fill=C["outline"], outline=C["outline"])
            t.create_rectangle(x + 1, y0 + 1, x + 131, 34, fill=fill, outline=fill)
            t.create_text(x + 66, (y0 + 34) // 2 + 1, text=label, font=self.fb, fill=C["text"])

    def _tab_click(self, e):
        for key, _label, x in self.tab_defs:
            if x <= e.x <= x + 132:
                self.show_page(key)

    def show_page(self, key):
        self.page = key
        self.inv_page.pack_forget()
        self.market_page.pack_forget()
        self.market_search_page.pack_forget()
        self.set_page.pack_forget()
        self.room_page.pack_forget()
        page = {"inventory": self.inv_page, "marketplace": self.market_page,
                "marketsearch": self.market_search_page, "room": self.room_page,
                "settings": self.set_page}.get(key, self.inv_page)
        page.pack(fill="both", expand=True, padx=8, pady=8)
        if key == "marketplace" and not self.manager.own_listings and not self.manager.listings_loading:
            self.manager.request_own_listings()
        if key == "room" and not self.manager.room_loaded and not self.manager.room_loading:
            self.manager.request_room()
        self._paint_tabs()

    def _build_inventory(self, p):
                    
        card = tk.Canvas(p, height=84, highlightthickness=0, bg=C["panel"])
        card.pack(fill="x")
        self.card = card
        card.bind("<Configure>", lambda _e: self._paint_card())

                              
        bar = tk.Frame(p, bg=C["panel"])
        bar.pack(fill="x", pady=(8, 6))
        box = tk.Frame(bar, bg=C["outline"])
        box.pack(side="left", fill="x", expand=True, ipady=0)
        inner = tk.Frame(box, bg=C["inset"])
        inner.pack(fill="x", padx=1, pady=1)
        self.filter_var = tk.StringVar()
        self.entry = tk.Entry(inner, textvariable=self.filter_var, relief="flat", bd=0, bg=C["inset"], fg=C["text"],
                              insertbackground=C["text"], font=self.f, highlightthickness=0)
        self.entry.pack(fill="x", padx=8, pady=7)
        self.placeholder = True
        self._set_placeholder()
        self.entry.bind("<FocusIn>", self._focus_in)
        self.entry.bind("<FocusOut>", lambda _e: self._set_placeholder())
        self.filter_var.trace_add("write", lambda *_: self._filter_changed())
        PixelButton(bar, "Refresh", self.manager.request_inventory, "blue", 110, 34, self.fb).pack(side="left", padx=(8, 0))

              
        wrap = tk.Frame(p, bg=C["outline"])
        wrap.pack(fill="both", expand=True)
        inner = tk.Frame(wrap, bg=C["inset"])
        inner.pack(fill="both", expand=True, padx=1, pady=1)
        self.head = tk.Canvas(inner, height=HEAD_H, highlightthickness=0, bg=C["head"])
        self.head.pack(fill="x")
        mid = tk.Frame(inner, bg=C["inset"])
        mid.pack(fill="both", expand=True)
        self.list = tk.Canvas(mid, highlightthickness=0, bg=C["row_a"])
        self.list.pack(side="left", fill="both", expand=True)
        self.sbar = tk.Canvas(mid, width=16, highlightthickness=0, bg=C["panel_lo"])
        self.sbar.pack(side="right", fill="y")
        self.list.bind("<Configure>", lambda _e: self._redraw())
        self.list.bind("<Motion>", self._hover)
        self.list.bind("<Leave>", lambda _e: self._leave())
        self.list.bind("<Button-3>", self._inventory_context_menu)
        self.head.bind("<Button-1>", self._head_click)
        for widget in (self.list, self.sbar):
            widget.bind("<MouseWheel>", self._wheel)
            widget.bind("<Button-4>", lambda _e: self._scroll(-ROW_H * 2))
            widget.bind("<Button-5>", lambda _e: self._scroll(ROW_H * 2))
        self.sbar.bind("<ButtonPress-1>", self._sb_press)
        self.sbar.bind("<B1-Motion>", self._sb_drag)

                
        fm = tk.Frame(p, bg=C["panel"])
        fm.pack(fill="x", pady=(8, 0))
        self.furnimatic_btn = PixelButton(fm, "Start FurniMatic", self.furnimatic_toggle, "green", 200, 34, self.fb)
        self.furnimatic_btn.pack(side="right")
        fm_box = tk.Frame(fm, bg=C["outline"])
        fm_box.pack(side="right", padx=(0, 8))
        self.furnimatic_max_var = tk.StringVar(value=str(self.settings["furnimatic_max_avg"]))
        self.furnimatic_entry = tk.Entry(fm_box, textvariable=self.furnimatic_max_var, width=8, justify="right",
                                         relief="flat", bd=0, bg=C["inset"], fg=C["text"],
                                         insertbackground=C["text"], font=self.f, highlightthickness=0)
        self.furnimatic_entry.pack(padx=1, pady=1, ipady=6, ipadx=4)
        tk.Label(fm, text="c", bg=C["panel"], fg=C["muted"], font=self.f).pack(side="right", padx=(0, 6))
        tk.Label(fm, text="FurniMatic: recycle all items with MP AVG below", bg=C["panel"], fg=C["text"],
                 font=self.f).pack(side="right", padx=(0, 8))

        foot = tk.Frame(p, bg=C["panel"])
        foot.pack(fill="x", pady=(8, 0))
        self.list_btn =PixelButton(foot, "List all at MP AVG", self.list_all, "green", 200, 34, self.fb)
        self.list_btn.pack(side="right")
        self.status_var = tk.StringVar(value="Type :inv in a room to load your inventory.")
        tk.Label(foot, textvariable=self.status_var, bg=C["panel"], fg=C["muted"], font=self.f, anchor="w"
                 ).pack(side="left", fill="x", expand=True)
        self.progress = tk.Canvas(foot, width=220, height=18, highlightthickness=0, bg=C["panel"])
        self.progress.pack(side="right", padx=12)
        self.prog = (0, 1)

    def _build_market_search(self, p):
        bar = tk.Frame(p, bg=C["panel"])
        bar.pack(fill="x", pady=(0, 8))
        tk.Label(bar, text="Search furniture offers", bg=C["panel"], fg=C["text"],
                 font=self.fb).pack(side="left", padx=(0, 12))
        self.market_search_var = tk.StringVar()
        self.market_search_entry = tk.Entry(bar, textvariable=self.market_search_var, relief="flat", bd=0,
                                            bg=C["inset"], fg=C["text"], insertbackground=C["text"],
                                            font=self.f, highlightthickness=1,
                                            highlightbackground=C["outline"])
        self.market_search_entry.pack(side="left", fill="x", expand=True, ipady=7, padx=(0, 8))
        self.market_search_entry.bind("<Return>", lambda _e: self.run_market_search())
        PixelButton(bar, "Search", self.run_market_search, "blue", 100, 32, self.fb).pack(side="right")
        self.market_search_status = tk.StringVar(
            value="Search by furniture name to see live Marketplace offers and price signals.")
        tk.Label(p, textvariable=self.market_search_status, bg=C["panel"], fg=C["muted"],
                 font=self.f, anchor="w").pack(fill="x", pady=(0, 6))
        wrap = tk.Frame(p, bg=C["outline"])
        wrap.pack(fill="both", expand=True)
        self.market_search_tree = ttk.Treeview(
            wrap, columns=("offer", "price", "average", "quantity", "time", "edge", "signal"),
            show="tree headings", selectmode="browse")
        headings = {"#0": "Furniture", "offer": "Offer", "price": "Price", "average": "7-day MP AVG",
                    "quantity": "Offers", "time": "Time left", "edge": "vs AVG", "signal": "Signal"}
        self.market_search_headings = headings
        self.market_search_sort_col, self.market_search_sort_desc = "price", False
        self.market_search_entries = []
        self.market_search_query = ""
        for col, label in headings.items():
            self.market_search_tree.heading(col, text=label,
                                            command=lambda c=col: self._sort_market_search(c))
        self.market_search_tree.column("#0", width=260, anchor="w")
        self.market_search_tree.column("offer", width=75, anchor="center")
        self.market_search_tree.column("price", width=85, anchor="e")
        self.market_search_tree.column("average", width=110, anchor="e")
        self.market_search_tree.column("quantity", width=55, anchor="center")
        self.market_search_tree.column("time", width=85, anchor="e")
        self.market_search_tree.column("edge", width=85, anchor="e")
        self.market_search_tree.column("signal", width=90, anchor="center")
        self.market_search_tree.pack(fill="both", expand=True, padx=1, pady=1)
        self.market_search_tree.tag_configure("strong_profit", background="#e4f2df", foreground="#245b20")
        self.market_search_tree.tag_configure("profit", background="#f0f7e9", foreground="#365f2c")
        self.market_search_tree.tag_configure("overpriced", background="#fff0e8", foreground="#8a4b28")
        self.market_search_hint = tk.Label(
            p, text="Green rows are listed below their 7-day average. Larger discounts and more offers are stronger signals. "
                   "The game response does not provide historical trade frequency or seller names.",
            bg=C["panel"], fg=C["muted"], font=self.fs, anchor="w", justify="left", wraplength=900)
        self.market_search_hint.pack(fill="x", pady=(6, 0))
        self.market_search_rows = {}
        self.market_search_token = 0
        self.market_search_tree.bind("<Double-1>", self._open_market_search_item)
        self.market_search_tip = None
        self.market_search_tip_iid = None
        self.market_search_tree.bind("<Motion>", self._market_search_hover)
        self.market_search_tree.bind("<Button-3>", self._market_search_context_menu)
        self._buying = False
        self.market_search_tree.bind("<Leave>", lambda _e: self._hide_market_tip())

    def run_market_search(self, query=None):
        query = (query if query is not None else self.market_search_var.get()).strip()
        if not query:
            self.market_search_status.set("Enter a furniture name to search.")
            return
        self.market_search_var.set(query)
        self.market_search_token += 1
        token = self.market_search_token
        self.market_search_status.set(f"Searching Marketplace for ‘{query}’...")
        for iid in self.market_search_tree.get_children():
            self.market_search_tree.delete(iid)
        self.market_search_rows = {}
        self._hide_market_tip()

        def finished(rows, error):
            self.manager.ui_post(lambda: self._show_market_search(token, query, rows, error))

        self.manager.market.search_marketplace(query, finished)

    def _show_market_search(self, token, query, rows, error):
        if token != self.market_search_token:
            return
        if rows is None:
            self.market_search_status.set(f"Search failed: {error}")
            return
        names = self.manager.names or {}
        entries = []
        for row in rows:
            if row.kind == 5:
                # Collectibles: furnidata id may not match, so fall back to the packet's classname.
                fallback = row.classname or f"Collectible #{row.type_id}"
                classname, name = names.get((True, row.type_id), (row.classname, fallback))
                if row.classname and row.classname != classname:
                    name = f"{fallback} (collectible)"
                else:
                    name = f"{name} (collectible)"
            else:
                key = (row.is_floor, row.type_id)
                classname, name = names.get(key, ("", f"Furniture #{row.type_id}"))
            average = row.average if row.average > 0 else None
            edge = ((average - row.price) / average * 100.0) if average else None
            if edge is not None and edge >= 15 and row.count >= 2:
                tag, signal, rank = "strong_profit", "Strong deal", 3
            elif edge is not None and edge > 0:
                tag, signal, rank = "profit", "Below AVG", 2
            elif edge is not None and edge < -5:
                tag, signal, rank = "overpriced", "Above AVG", 0
            else:
                tag, signal, rank = "", ("Near AVG" if average else "No AVG"), (1 if average else -1)
            entries.append({"row": row, "name": name, "average": average, "edge": edge,
                            "tag": tag, "signal": signal, "rank": rank})
        self.market_search_entries = entries
        self.market_search_query = query
        self._render_market_search()

    def _sort_market_search(self, column):
        if self.market_search_sort_col == column:
            self.market_search_sort_desc = not self.market_search_sort_desc
        else:
            self.market_search_sort_col = column
            # Best-first by default for "more is better" columns, A-Z / lowest-first for the rest.
            self.market_search_sort_desc = column in ("average", "quantity", "edge", "signal")
        self._render_market_search()

    def _render_market_search(self):
        col, desc = self.market_search_sort_col, self.market_search_sort_desc

        def sort_key(e):
            r = e["row"]
            if col == "#0":
                return (e["name"].lower(), r.price)
            if col == "offer":
                return (r.offer_id,)
            if col == "price":
                return (r.price, e["name"].lower())
            if col == "average":
                return (e["average"] if e["average"] is not None else -1, r.price)
            if col == "quantity":
                return (r.count, -r.price)
            if col == "time":
                return (r.time_left, r.price)
            if col == "edge":
                return (e["edge"] if e["edge"] is not None else float("-inf"), -r.price)
            return (e["rank"], e["edge"] if e["edge"] is not None else float("-inf"), -r.price)

        entries = sorted(self.market_search_entries, key=sort_key, reverse=desc)
        self._hide_market_tip()
        for iid in self.market_search_tree.get_children():
            self.market_search_tree.delete(iid)
        self.market_search_rows = {}
        for index, e in enumerate(entries):
            row = e["row"]
            minutes = max(0, row.time_left)
            iid = f"offer_{index}"
            self.market_search_tree.insert(
                "", "end", iid=iid, text=e["name"],
                values=(f"#{row.offer_id}", fmt_c(row.price), fmt_c(e["average"]), row.count,
                        f"{minutes // 60}h {minutes % 60}m",
                        f"{e['edge']:+.1f}%" if e["edge"] is not None else "-", e["signal"]),
                tags=(e["tag"],) if e["tag"] else ())
            self.market_search_rows[iid] = row
        for c, label in self.market_search_headings.items():
            arrow = (" \u25bc" if desc else " \u25b2") if c == col else ""
            self.market_search_tree.heading(c, text=label + arrow)
        label = self.market_search_headings[col]
        self.market_search_status.set(
            f"{len(entries)} offer(s) for \u2018{self.market_search_query}\u2019 \u00b7 "
            f"Sorted by {label} ({'high to low' if desc else 'low to high'}) \u00b7 Click a heading to sort")

    def _market_search_context_menu(self, event):
        iid = self.market_search_tree.identify_row(event.y)
        row = self.market_search_rows.get(iid) if iid else None
        if not row:
            return
        self._hide_market_tip()
        self.market_search_tree.selection_set(iid)
        name = self.market_search_tree.item(iid, "text")
        menu = tk.Menu(self.root, tearoff=0)
        menu.add_command(label=f"Buy for {fmt_c(row.price)}", command=lambda: self._confirm_buy(row, name))
        menu.tk_popup(event.x_root, event.y_root)

    def _confirm_buy(self, row, name):
        if self._buying:
            self.market_search_status.set("A purchase is already in progress...")
            return
        lines = [f"Buy {name}?", "", f"Price: {fmt_c(row.price)}", f"Offer ID: #{row.offer_id}"]
        if row.average > 0:
            edge = (row.average - row.price) / row.average * 100.0
            lines.append(f"7-day MP AVG: {fmt_c(row.average)} ({edge:+.1f}% vs AVG)")
        details = self._trophy_details(row.extra)
        if details:
            lines.append(f"Trophy: {details[0] or '-'} \u00b7 {details[1] or '-'}")
        lines += ["", "The credits are taken immediately and this can't be undone."]
        self._dialog("Confirm purchase", "\n".join(lines),
                     [("Buy", "green", lambda: self._do_buy(row, name)), ("Cancel", "grey", None)])

    def _do_buy(self, row, name):
        self._buying = True
        self.market_search_status.set(f"Buying {name} for {fmt_c(row.price)}...")
        query = self.market_search_var.get()

        def done(success, message, refresh):
            def apply():
                self._buying = False
                self.market_search_status.set(f"{name}: {message}")
                if refresh:
                    self.root.after(600, lambda: self.run_market_search(query))
                    # keep the result message visible after the refresh begins
                    self.root.after(700, lambda: self.market_search_status.set(f"{name}: {message}"))
            self.manager.ui_post(apply)

        self.manager.market.buy_offer(row.offer_id, done)

    @staticmethod
    def _trophy_details(extra):
        """Split a trophy's stuff string into (owner, date, message), or None if it isn't one."""
        if not extra or "\t" not in extra:
            return None
        parts = extra.split("\t", 2)
        owner = parts[0].strip()
        date = parts[1].strip() if len(parts) > 1 else ""
        message = parts[2] if len(parts) > 2 else ""
        message = message.replace("\r", "\n").replace("\x0d", "\n").strip()
        return owner, date, message

    def _hide_market_tip(self):
        if self.market_search_tip is not None:
            self.market_search_tip.destroy()
            self.market_search_tip = None
        self.market_search_tip_iid = None

    def _market_search_hover(self, event):
        iid = self.market_search_tree.identify_row(event.y)
        row = self.market_search_rows.get(iid) if iid else None
        details = self._trophy_details(row.extra) if row else None
        if not details:
            self._hide_market_tip()
            return
        if iid != self.market_search_tip_iid:
            self._hide_market_tip()
            owner, date, message = details
            text = f"Owner: {owner or '-'}\nDate: {date or '-'}\n\n{message or '(no description)'}"
            tip = tk.Toplevel(self.root)
            tip.overrideredirect(True)
            tip.attributes("-topmost", True)
            tk.Label(tip, text=text, justify="left", anchor="w", bg=C["tip_bg"], fg=C["tip_fg"],
                     font=self.f, padx=12, pady=9, wraplength=420).pack(padx=1, pady=1)
            self.market_search_tip, self.market_search_tip_iid = tip, iid
        self.market_search_tip.geometry(f"+{event.x_root + 18}+{event.y_root + 14}")

    def _open_market_search_item(self, _event=None):
        selected = self.market_search_tree.selection()
        if selected:
            row = self.market_search_rows.get(selected[0])
            if row:
                name = (self.manager.names or {}).get((row.is_floor, row.type_id), ("", f"Furniture #{row.type_id}"))[1]
                self.open_marketplace_search(name)

    def open_marketplace_search(self, name):
        self.show_page("marketsearch")
        self.market_search_var.set(name)
        self.run_market_search(name)

    def _inventory_context_menu(self, event):
        index = int((event.y + self.offset) // ROW_H)
        if not 0 <= index < len(self.rows):
            return
        group = self.rows[index]
        menu = tk.Menu(self.root, tearoff=0)
        menu.add_command(label=f"Search Marketplace for {group.name}",
                         command=lambda: self.open_marketplace_search(group.name))
        menu.tk_popup(event.x_root, event.y_root)

    def _build_marketplace(self, p):
        self.market_header = tk.Frame(p, bg=C["panel"])
        self.market_header.pack(fill="x", pady=(0, 8))
        tk.Label(self.market_header, text="Your active Marketplace listings", bg=C["panel"], fg=C["text"],
                 font=self.fb).pack(side="left")
        PixelButton(self.market_header, "Refresh", self.manager.request_own_listings, "blue", 100, 30,
                    self.fb).pack(side="right")
        self.market_status = tk.StringVar(value="Open this tab to load your listings.")
        tk.Label(p, textvariable=self.market_status, bg=C["panel"], fg=C["muted"], font=self.f,
                 anchor="w").pack(fill="x", pady=(0, 6))
        self.market_content = tk.Frame(p, bg=C["panel"])
        self.market_content.pack(fill="both", expand=True)
        self.listing_tree = ttk.Treeview(self.market_content, columns=("quantity", "price", "average", "time"),
                                         show="tree headings", selectmode="browse")
        self.listing_tree.heading("#0", text="Furniture")
        self.listing_tree.heading("quantity", text="Qty")
        self.listing_tree.heading("price", text="Your price")
        self.listing_tree.heading("average", text="7-day average")
        self.listing_tree.heading("time", text="Time left")
        self.listing_tree.column("#0", width=430, anchor="w")
        self.listing_tree.column("quantity", width=65, anchor="center")
        self.listing_tree.column("price", width=120, anchor="e")
        self.listing_tree.column("average", width=140, anchor="e")
        self.listing_tree.column("time", width=110, anchor="e")
        self.listing_tree.pack(fill="both", expand=True)
        self.listing_tree.bind("<Double-1>", self._open_selected_listing)
        self.listing_tree.bind("<Return>", self._open_selected_listing)
        self.listing_tree.bind("<Button-3>", self._listing_context_menu)
        self.market_hint = tk.Label(p, text="Double-click a listing to open its market insights.",
                                    bg=C["panel"], fg=C["muted"], font=self.fs, anchor="w")
        self.market_hint.pack(fill="x", pady=(6, 0))
        self.insights_page = None
        self._listing_by_iid = {}

    def update_listings(self):
        self.market_status.set("Loading your Marketplace listings..." if self.manager.listings_loading else
                               self.manager.listings_error or
                               f"{len(self.manager.own_listings)} active listings · {self.manager.credits_waiting:,}c waiting to collect")
        for iid in self.listing_tree.get_children():
            self.listing_tree.delete(iid)
        self._listing_by_iid = {}
        grouped = {}
        for listing in self.manager.own_listings:
            group_key = (listing.kind, listing.type_id, listing.name)
            grouped.setdefault(group_key, []).append(listing)
        for group_index, (group_key, listings) in enumerate(sorted(
                grouped.items(), key=lambda item: item[1][0].name.lower())):
            listings.sort(key=lambda item: (item.price, item.time_left, item.offer_id))
            first = listings[0]
            prices = [item.price for item in listings]
            averages = [item.average for item in listings if item.average > 0]
            times = [item.time_left for item in listings]
            price_text = fmt_c(prices[0]) if min(prices) == max(prices) else f"{fmt_c(min(prices))}–{fmt_c(max(prices))}"
            avg_text = fmt_c(averages[0] if averages else None)
            mins = min(times) if times else 0
            group_iid = f"group_{group_index}"
            self.listing_tree.insert("", "end", iid=group_iid,
                                     text=first.name, values=(len(listings), price_text, avg_text,
                                     f"{mins // 60}h {mins % 60}m"))
            self._listing_by_iid[group_iid] = first
            for child_index, listing in enumerate(listings):
                child_iid = f"{group_iid}_{child_index}"
                minutes = max(0, listing.time_left)
                time_left = f"{minutes // 60}h {minutes % 60}m"
                self.listing_tree.insert(group_iid, "end", iid=child_iid,
                    text=f"Offer #{listing.offer_id}", values=(1, fmt_c(listing.price),
                    fmt_c(listing.average or None), time_left))
                self._listing_by_iid[child_iid] = listing

    def _build_room(self, p):
        header = tk.Frame(p, bg=C["panel"])
        header.pack(fill="x", pady=(0, 8))
        tk.Label(header, text="Furniture in this room", bg=C["panel"], fg=C["text"],
                 font=self.fb).pack(side="left")
        self.dump_btn = PixelButton(
            header, "Dump furni",
            lambda: self.manager.start_room_dump(
                self.sellable_only_var.get(), self.sellable_min_price_var.get()),
            "green", 120, 30, self.fb)
        self.dump_btn.pack(side="right")
        sellable_controls = tk.Frame(header, bg=C["panel"])
        sellable_controls.pack(side="right", padx=(0, 10))
        self.sellable_only_var = tk.BooleanVar(value=False)
        tk.Checkbutton(sellable_controls, text="Sellable only", variable=self.sellable_only_var,
                       bg=C["panel"], fg=C["text"], activebackground=C["panel"],
                       activeforeground=C["text"], selectcolor=C["panel"],
                       font=self.fs, padx=2, pady=0).pack(side="left")
        tk.Label(sellable_controls, text="MP avg ≥", bg=C["panel"], fg=C["muted"],
                 font=self.fs).pack(side="left", padx=(5, 3))
        self.sellable_min_price_var = tk.StringVar(value="0")
        self.sellable_min_price_entry = tk.Spinbox(
            sellable_controls, from_=0, to=999999999, increment=1,
            textvariable=self.sellable_min_price_var, width=6,
            font=self.fs, relief="solid", bd=1, justify="right")
        self.sellable_min_price_entry.pack(side="left")
        self.room_status = tk.StringVar(value="Open the Room tab to load room furniture.")
        tk.Label(p, textvariable=self.room_status, bg=C["panel"], fg=C["muted"],
                 font=self.f, anchor="w").pack(fill="x", pady=(0, 6))

        search_row = tk.Frame(p, bg=C["panel"])
        search_row.pack(fill="x", pady=(0, 6))
        tk.Label(search_row, text="Search", bg=C["panel"], fg=C["text"],
                 font=self.f).pack(side="left", padx=(0, 8))
        self.room_search_var = tk.StringVar()
        self.room_search_var.trace_add("write", lambda *_: self.update_room())
        self.room_search_entry = tk.Entry(search_row, textvariable=self.room_search_var,
                                          font=self.f, relief="solid", bd=1)
        self.room_search_entry.pack(side="left", fill="x", expand=True)
        self.room_search_entry.bind("<Escape>", lambda _e: self.room_search_var.set(""))
        self.room_sort_column = "name"
        self.room_sort_desc = False

        wrap = tk.Frame(p, bg=C["outline"])
        wrap.pack(fill="both", expand=True)
        self.room_tree = ttk.Treeview(wrap, columns=("quantity", "average", "current", "total"),
                                      show="tree headings", selectmode="browse")
        self.room_tree.heading("#0", text="Furniture", command=lambda: self._sort_room("name"))
        self.room_tree.heading("quantity", text="Qty", command=lambda: self._sort_room("quantity"))
        self.room_tree.heading("average", text="MP average", command=lambda: self._sort_room("average"))
        self.room_tree.heading("current", text="Current lowest", command=lambda: self._sort_room("current"))
        self.room_tree.heading("total", text="Total at average", command=lambda: self._sort_room("total"))
        self.room_tree.column("#0", width=390, anchor="w")
        self.room_tree.column("quantity", width=70, anchor="center")
        self.room_tree.column("average", width=130, anchor="e")
        self.room_tree.column("current", width=130, anchor="e")
        self.room_tree.column("total", width=140, anchor="e")
        self.room_tree.pack(fill="both", expand=True, padx=1, pady=1)
        self.room_tree.bind("<Double-1>", self._open_selected_room_item)
        self.room_tree.bind("<Button-3>", self._room_context_menu)
        self.room_hint = tk.Label(p, text="Click a column heading to sort. Double-click an item for details.",
                                  bg=C["panel"], fg=C["muted"], font=self.fs, anchor="w")
        self.room_hint.pack(fill="x", pady=(6, 0))
        self._room_by_iid = {}

    def _sort_room(self, column):
        if self.room_sort_column == column:
            self.room_sort_desc = not self.room_sort_desc
        else:
            self.room_sort_column = column
            self.room_sort_desc = column != "name"
        self.update_room()

    def update_room(self):
        if not hasattr(self, "room_status"):
            return
        manager = self.manager
        if manager.room_loading:
            status = "Loading room furniture..."
        elif manager.room_error:
            status = manager.room_error
        else:
            pieces = sum(g.quantity for g in manager.room_groups.values())
            status = f"{pieces} items · {len(manager.room_groups)} furniture types"
        if manager.room_dump_status:
            status = manager.room_dump_status
        elif not manager.room_heightmap_ready:
            status = status + " · Waiting for floor map"
        self.room_status.set(status)
        if hasattr(self, "dump_btn"):
            self.dump_btn.configure_button(
                text="Stop dump" if manager.room_dump_running else "Dump furni",
                theme="red" if manager.room_dump_running else "green",
                enabled=manager.room_dump_running or (not manager.room_loading))
        for iid in self.room_tree.get_children():
            self.room_tree.delete(iid)
        self._room_by_iid = {}
        needle = self.room_search_var.get().strip().lower() if hasattr(self, "room_search_var") else ""
        groups = list(manager.room_groups.values())
        if needle:
            groups = [g for g in groups if needle in g.name.lower() or needle in g.classname.lower()]

        def sort_value(group):
            average = group.price.average if group.price.state == "ok" else None
            current = group.price.current if group.price.state == "ok" else None
            total = average * group.quantity if average is not None else None
            values = {
                "name": group.name.lower(),
                "quantity": group.quantity,
                "average": average if average is not None else -1,
                "current": current if current is not None else -1,
                "total": total if total is not None else -1,
            }
            return values[self.room_sort_column]

        groups.sort(key=sort_value, reverse=self.room_sort_desc)
        for index, group in enumerate(groups):
            average = group.price.average if group.price.state == "ok" else None
            current = group.price.current if group.price.state == "ok" else None
            total = average * group.quantity if average is not None else None
            iid = f"room_{index}"
            self.room_tree.insert("", "end", iid=iid, text=group.name,
                                  values=(group.quantity, fmt_c(average), fmt_c(current), fmt_c(total)))
            self._room_by_iid[iid] = group

    def _room_context_menu(self, event):
        iid = self.room_tree.identify_row(event.y)
        if not iid:
            return
        self.room_tree.selection_set(iid)
        group = self._room_by_iid.get(iid)
        if group:
            menu = tk.Menu(self.root, tearoff=0)
            menu.add_command(label=f"Search Marketplace for {group.name}",
                             command=lambda: self.open_marketplace_search(group.name))
            menu.tk_popup(event.x_root, event.y_root)

    def _listing_context_menu(self, event):
        iid = self.listing_tree.identify_row(event.y)
        if not iid:
            return
        self.listing_tree.selection_set(iid)
        listing = self._listing_by_iid.get(iid)
        if listing:
            menu = tk.Menu(self.root, tearoff=0)
            menu.add_command(label=f"Search Marketplace for {listing.name}",
                             command=lambda: self.open_marketplace_search(listing.name))
            menu.tk_popup(event.x_root, event.y_root)

    def _open_selected_room_item(self, _event=None):
        selected = self.room_tree.selection()
        if selected:
            group = self._room_by_iid.get(selected[0])
            if group:
                self.manager.load_room_insights(group)

    def _open_selected_listing(self, _event=None):
        selected = self.listing_tree.selection()
        if selected:
            listing = self._listing_by_iid.get(selected[0])
            if listing:
                self.manager.load_item_insights(listing)

    def show_item_insights(self, listing, loading=False, data=None, error=""):
        if self.insights_page is not None:
            self.insights_page.destroy()
        page = tk.Toplevel(self.root)
        self.insights_page = page
        page.title(f"MyFurni - {listing.name}")
        page.configure(bg=C["panel"])
        page.geometry("620x390")
        page.transient(self.root)
        top = tk.Frame(page, bg=C["title"], height=38)
        top.pack(fill="x")
        tk.Label(top, text=listing.name, bg=C["title"], fg="#ffffff", font=self.fb).pack(side="left", padx=12, pady=9)

        tk.Label(page, text=f"Your listing: {fmt_c(listing.price)}",
                 bg=C["panel"], fg=C["text"], font=self.fb).pack(anchor="w", padx=14, pady=(16, 5))
        if listing.average > 0:
            delta = (listing.price - listing.average) / listing.average * 100
            relation = "above" if delta > 0 else "below" if delta < 0 else "at"
            tk.Label(page, text=f"Marketplace 7-day average: {fmt_c(listing.average)}  ·  "
                     f"Your price is {abs(delta):.1f}% {relation}.",
                     bg=C["panel"], fg=C["good"] if delta <= 0 else C["warn"],
                     font=self.f).pack(anchor="w", padx=14, pady=(0, 12))
        else:
            tk.Label(page, text="Marketplace 7-day average: Not available",
                     bg=C["panel"], fg=C["muted"], font=self.f).pack(anchor="w", padx=14, pady=(0, 12))

        calc_box = tk.LabelFrame(page, text="Credit furni profit calculator", bg=C["panel"],
                                 fg=C["text"], font=self.fb, padx=10, pady=8)
        calc_box.pack(fill="x", padx=14, pady=(4, 10))

        cost_row = tk.Frame(calc_box, bg=C["panel"])
        cost_row.pack(fill="x")
        tk.Label(cost_row, text="Price you pay (coin/bar face value):", bg=C["panel"],
                 fg=C["text"], font=self.f).pack(side="left")
        cost_var = tk.StringVar(value="0")
        tk.Entry(cost_row, textvariable=cost_var, width=10, relief="solid", bd=1,
                 font=self.f).pack(side="left", padx=8)
        tk.Label(cost_row, text="credits", bg=C["panel"], fg=C["muted"],
                 font=self.f).pack(side="left")

        calc_result = tk.StringVar()
        tk.Label(calc_box, text="Includes the 10% shop tax for credit furni (rounded up). "
                 "Profit is before any Marketplace selling fee.",
                 bg=C["panel"], fg=C["muted"], font=self.fs, wraplength=560,
                 justify="left").pack(anchor="w")

        def update_profit(*_args):
            try:
                face_value = max(0, int(cost_var.get().replace(",", "").strip() or "0"))
                effective_cost = math.ceil(face_value * 1.10) if face_value else 0
                current_profit = listing.price - effective_cost
                lines = [f"Your effective cost: {effective_cost:,}c "
                         f"(including {effective_cost - face_value:,}c tax)",
                         f"Profit at reference price ({listing.price:,}c): "
                         f"{current_profit:+,}c"]
                if listing.average > 0:
                    average_profit = listing.average - effective_cost
                    lines.append(f"Profit at MP average ({listing.average:,}c): "
                                 f"{average_profit:+,}c")
                calc_result.set("\\n".join(lines))
                calc_result_label.configure(fg=C["good"] if current_profit >= 0 else C["warn"])
            except ValueError:
                calc_result.set("Enter a valid whole-credit price.")
                calc_result_label.configure(fg=C["warn"])

        calc_result_label = tk.Label(calc_box, textvariable=calc_result, bg=C["panel"],
                                     fg=C["good"], font=self.fb, justify="left")
        calc_result_label.pack_forget()
        calc_result.trace_add("write", lambda *_: calc_result_label.configure(text=calc_result.get()))
        calc_result_label.pack(anchor="w", pady=(7, 2))
        cost_var.trace_add("write", update_profit)
        update_profit()

        tk.Label(page, text="Public market history (HabboAPI)", bg=C["panel"],
                 fg=C["text"], font=self.fb).pack(anchor="w", padx=14, pady=(12, 4))
        if loading:
            history_text = "Loading public market history..."
        else:
            history_data = (data or {}).get("history", [])
            if isinstance(history_data, dict):
                history_data = history_data.get("data", history_data.get("results", []))
            if history_data:
                item = history_data[0] if isinstance(history_data, list) else history_data
                market = item.get("marketData", {}) if isinstance(item, dict) else {}
                last_updated = market.get("lastUpdated", "Unknown")
                history_rows = market.get("history", []) or []
                history_text = f"{len(history_rows)} recorded market-history entries · Last updated: {last_updated}"
            else:
                history_text = error or "No public market history is available for this item."
        tk.Label(page, text=history_text, bg=C["panel"], fg=C["muted"], font=self.fs,
                 wraplength=580, justify="left").pack(anchor="w", padx=14, pady=4)

        tk.Label(page, text=f"Offer ID: {listing.offer_id}     Time remaining: {listing.time_left:,} minutes     "
                 f"Item: {listing.classname or listing.type_id}",
                 bg=C["panel"], fg=C["muted"], font=self.fs).pack(anchor="w", padx=14, pady=(18, 4))

    def _build_settings(self, p):
        tk.Label(p, text="Price information shown", bg=C["panel"], fg=C["text"], font=self.fb).pack(anchor="w")
        modes = [("avg", "MP AVG", "Average price reported by the Marketplace (default)"),
                 ("current", "Current", "Cheapest active Marketplace listing"),
                 ("both", "Both", "Show both columns and both totals")]
        ChoiceList(p, modes, self.settings["price_mode"], self._mode_changed, self.fb, self.fs).pack(anchor="w", pady=(6, 14))

        tk.Label(p, text="Speed", bg=C["panel"], fg=C["text"], font=self.fb).pack(anchor="w")
        self._speed_control(
            p, "Inventory indexing / MP refresh", 
            "Delay between Marketplace price lookups while inventory is being indexed. Lower is faster.",
            "request_interval", 0.5, 3.0)
        self._speed_control(
            p, "Marketplace listing", 
            "Delay between successful item listings. Lower is faster; server confirmations are still required.",
            "list_interval", 0.5, 5.0)

        tk.Label(p, text="Listing", bg=C["panel"], fg=C["text"], font=self.fb).pack(anchor="w", pady=(12, 0))
        opts = [("skip_est", "Skip items without a real sales average",
                 "When the Marketplace reports no sales average, MP AVG is only a listing price")]
        sel = ["skip_est"] if self.settings["list_skip_estimated"] else []
        ChoiceList(p, opts, sel, lambda v: self._skip_changed("skip_est" in v), self.fb, self.fs, multi=True
                   ).pack(anchor="w", pady=(6, 12))
        tk.Label(p, text="Settings are saved automatically to config.json", bg=C["panel"], fg=C["muted"],
                 font=self.fs).pack(anchor="w")

    def _speed_control(self, parent, title, description, key, minimum, maximum):
        wrap = tk.Frame(parent, bg=C["panel"])
        wrap.pack(fill="x", anchor="w", pady=(6, 3))
        head = tk.Frame(wrap, bg=C["panel"])
        head.pack(fill="x")
        tk.Label(head, text=title, bg=C["panel"], fg=C["text"], font=self.fb).pack(side="left")
        value_var = tk.StringVar(value=f"{float(self.settings[key]):.1f}s")
        tk.Label(head, textvariable=value_var, bg=C["panel"], fg=C["title_lo"], font=self.fb).pack(side="right", padx=(8, 18))
        tk.Label(wrap, text=description, bg=C["panel"], fg=C["muted"], font=self.fs).pack(anchor="w", pady=(2, 0))
        scale = tk.Scale(
            wrap, from_=minimum, to=maximum, resolution=0.1, orient="horizontal",
            showvalue=False, length=520, width=12, sliderlength=20,
            bg=C["panel"], fg=C["text"], troughcolor=C["panel_lo"],
            activebackground=C["title_hi"], highlightthickness=0, bd=0,
            command=lambda raw: value_var.set(f"{float(raw):.1f}s"))
        scale.set(max(minimum, min(maximum, float(self.settings[key]))))
        scale.pack(anchor="w", fill="x", padx=(0, 18), pady=(0, 4))

        def save_value(_event=None):
            self.settings.set(key, round(float(scale.get()), 1))

        scale.bind("<ButtonRelease-1>", save_value)
        scale.bind("<KeyRelease>", save_value)

    def _mode_changed(self, key):
        self.settings.set("price_mode", key)
        self.rebuild()

    def _skip_changed(self, on):
        self.settings.set("list_skip_estimated", bool(on))

                                                                                           
    def _set_placeholder(self):
        if not self.filter_var.get():
            self.placeholder = True
            self.entry.configure(fg=C["muted"])
            self.entry.delete(0, "end")
            self.entry.insert(0, "Search furni by name or classname...")

    def _focus_in(self, _e):
        if self.placeholder:
            self.entry.delete(0, "end")
            self.entry.configure(fg=C["text"])
            self.placeholder = False

    def _filter_changed(self):
        if not self.placeholder:
            self.offset = 0
            self.rebuild()

                                                                                
    @property
    def mode(self) -> str:
        return self.settings["price_mode"]

    def _metric(self) -> str:
        return "current" if self.mode == "current" else "avg"

    def show(self):
        self.root.deiconify()
        self.root.lift()
        self.root.attributes("-topmost", True)
        self.root.after(300, lambda: self.root.attributes("-topmost", False))

    def _cols(self, width):
                                                                                        
        right = width - 14
        cols = {}
        for key, w in (("total", 130), ("current", 100), ("avg", 100), ("qty", 70)):
            if key == "current" and self.mode == "avg":
                continue
            if key == "avg" and self.mode == "current":
                continue
            cols[key] = right
            right -= w
        return cols, right

    def _cells(self, g: FurniGroup):
        st = g.price.state
        if st in ("pending", "loading"):
            dots = "." * (self.dots % 3 + 1)
            return {"avg": dots, "current": dots, "total": "loading" + dots}, C["muted"]
        if st == "ok":
            return {"avg": fmt_c(g.price.average), "current": fmt_c(g.price.current),
                    "total": fmt_c(g.total(self._metric()))}, C["text"]
        label = {"none": "no listings", "blocked": "not tradeable", "error": "unavailable"}[st]
        return {"avg": "-", "current": "-", "total": label}, C["warn"]

    def _sort_value(self, g: FurniGroup):
        c = self.sort_col
        if c == "name":
            return (g.name or "~").lower()
        if c == "qty":
            return g.quantity
        if c == "avg":
            return g.price.average if g.price.state == "ok" else -1
        if c == "current":
            return g.price.current if g.price.state == "ok" else -1
        total = g.total(self._metric())
        return -1 if total is None else total

                                                                                 
    def _paint_card(self):
        c = self.card
        c.delete("all")
        w = max(c.winfo_width(), 300)
        c.create_rectangle(0, 0, w - 1, 83, fill=C["outline"], outline=C["outline"])
        c.create_rectangle(1, 1, w - 2, 82, fill="#2b2b2b", outline="#2b2b2b")
        c.create_rectangle(1, 1, w - 2, 3, fill="#444444", outline="#444444")
              
        c.create_oval(16, 20, 62, 66, fill=C["coin_lo"], outline=C["outline"], width=2)
        c.create_oval(19, 20, 59, 60, fill=C["coin"], outline="#ffe066", width=2)
        c.create_text(39, 40, text="c", font=self.fbig, fill=C["coin_lo"])
        groups = list(self.manager.groups.values())
        metrics = ("avg", "current") if self.mode == "both" else (self._metric(),)
        label = {"avg": "MP AVG", "current": "Current"}
        x = 80
        for m in metrics:
            total = sum(g.total(m) or 0 for g in groups)
            c.create_text(x, 24, text=f"Total value ({label[m]})", anchor="w", font=self.fs, fill="#bdbdbd")
            c.create_text(x, 50, text=fmt_c(total), anchor="w", font=self.fbig, fill="#ffffff")
            x += 300
        unvalued_types = unvalued_pieces = 0
        for g in groups:
            if g.unit(self._metric()) is None:
                unvalued_types += 1
                unvalued_pieces += g.quantity
        loading = any(g.price.state in ("pending", "loading") for g in groups)
        if not groups:
            note, colour = "", "#bdbdbd"
        elif unvalued_types:
            note = (f"{unvalued_types} furni type(s) / {unvalued_pieces} item(s) could not be valued "
                    f"and are excluded" + (" (still loading)" if loading else ""))
            colour = "#ffb347"
        else:
            note, colour = "All furniture valued", "#8be36b"
        c.create_text(80, 72, text=note, anchor="w", font=self.fs, fill=colour)
        pieces = sum(g.quantity for g in groups)
        c.create_text(w - 16, 24, text=f"{len(groups)} types", anchor="e", font=self.fb, fill="#ffffff")
        c.create_text(w - 16, 46, text=f"{pieces} items", anchor="e", font=self.fs, fill="#bdbdbd")

    def _paint_head(self):
        h = self.head
        h.delete("all")
        w = max(self.list.winfo_width(), 300)
        cols, name_right = self._cols(w)
        h.create_rectangle(0, 0, w, HEAD_H, fill=C["head"], outline=C["head"])
        h.create_rectangle(0, HEAD_H - 2, w, HEAD_H, fill=C["panel_lo"], outline=C["panel_lo"])
        titles = {"name": "Furniture", "qty": "Qty", "avg": "MP AVG", "current": "Current", "total": "Total value"}
        self._head_zones = []
        for key, text in titles.items():
            if key == "name":
                x0, x1, anchor, tx = 0, name_right, "w", 58
            elif key in cols:
                x1 = cols[key]
                x0 = x1 - (70 if key == "qty" else 130 if key == "total" else 100)
                anchor, tx = "e", x1
            else:
                continue
            arrow = (" ▼" if self.sort_desc else " ▲") if key == self.sort_col else ""
            h.create_text(tx, HEAD_H // 2, text=text + arrow, anchor=anchor, font=self.fb, fill=C["text"])
            self._head_zones.append((x0, x1, key))

    def _head_click(self, e):
        for x0, x1, key in getattr(self, "_head_zones", []):
            if x0 <= e.x <= x1:
                self.sort_desc = (not self.sort_desc) if key == self.sort_col else (key != "name")
                self.sort_col = key
                self.rebuild()
                return

    def _redraw(self):
        c = self.list
        c.delete("all")
        w, h = max(c.winfo_width(), 300), max(c.winfo_height(), 50)
        self._clamp(h)
        cols, name_right = self._cols(w)
        first = int(self.offset // ROW_H)
        last = min(len(self.rows), int((self.offset + h) // ROW_H) + 1)
        for i in range(first, last):
            g = self.rows[i]
            y = i * ROW_H - self.offset
            fill = C["row_hover"] if i == self.hover_row else (C["row_a"] if i % 2 == 0 else C["row_b"])
            c.create_rectangle(0, y, w, y + ROW_H, fill=fill, outline=fill)
            c.create_rectangle(0, y + ROW_H - 1, w, y + ROW_H, fill="#d4d4d4", outline="#d4d4d4")
            tile = tile_colour(g.classname or g.name)
            c.create_rectangle(10, y + 5, 46, y + 37, fill=C["outline"], outline=C["outline"])
            c.create_rectangle(11, y + 6, 45, y + 36, fill=tile, outline=tile)
            c.create_rectangle(11, y + 6, 45, y + 10, fill="#ffffff", outline="#ffffff", stipple="gray50")
            c.create_text(28, y + 21, text=(g.name or "?")[:1].upper(), font=self.fb, fill="#333333")
            cells, colour = self._cells(g)
            c.create_text(58, y + 15, text=self._clip(g.name or f"(unknown #{g.key[1]})", name_right - 66),
                          anchor="w", font=self.fb, fill=C["text"])
            c.create_text(58, y + 30, text=self._clip(g.classname or "-", name_right - 66), anchor="w",
                          font=self.fs, fill=C["muted"])
            c.create_text(cols["qty"], y + ROW_H // 2, text=f"x{g.quantity}", anchor="e", font=self.fb, fill=C["text"])
            for key in ("avg", "current"):
                if key in cols:
                    c.create_text(cols[key], y + ROW_H // 2, text=cells[key], anchor="e", font=self.f, fill=colour)
            total_colour = C["good"] if g.price.state == "ok" else colour
            c.create_text(cols["total"], y + ROW_H // 2, text=cells["total"], anchor="e", font=self.fb, fill=total_colour)
        if not self.rows:
            msg = ("Loading inventory..." if self.manager.inventory_loading
                   else "No furniture to show. Type :inv in a room to load your inventory.")
            c.create_text(w // 2, 60, text=msg, font=self.f, fill=C["muted"])
        self._paint_head()
        self._paint_sbar()

    def _clip(self, text, width):
        if self.f.measure(text) <= width:
            return text
        while text and self.f.measure(text + "...") > width:
            text = text[:-1]
        return text + "..."

    def _paint_sbar(self):
        s = self.sbar
        s.delete("all")
        h = max(s.winfo_height(), 20)
        total = len(self.rows) * ROW_H
        view = max(self.list.winfo_height(), 1)
        s.create_rectangle(0, 0, 16, h, fill="#b9b9b9", outline="#b9b9b9")
        if total <= view:
            return
        thumb = max(30, int(h * view / total))
        y = int((h - thumb) * (self.offset / (total - view)))
        s.create_rectangle(1, y, 15, y + thumb, fill=C["outline"], outline=C["outline"])
        s.create_rectangle(2, y + 1, 14, y + thumb - 1, fill="#5fae2e", outline="#5fae2e")
        s.create_rectangle(2, y + 1, 14, y + 4, fill="#9be05a", outline="#9be05a")
        s.create_rectangle(2, y + thumb - 4, 14, y + thumb - 1, fill="#3b7a19", outline="#3b7a19")
        self._thumb = (y, thumb)

    def _clamp(self, view=None):
        view = view or max(self.list.winfo_height(), 1)
        self.offset = max(0, min(self.offset, max(0, len(self.rows) * ROW_H - view)))

    def _scroll(self, delta):
        self.offset += delta
        self._redraw()

    def _wheel(self, e):
        self._scroll(-int(e.delta / 120 * ROW_H * 2) if abs(e.delta) >= 120 else -int(e.delta * ROW_H))

    def _sb_press(self, e):
        self._sb_start = (e.y, self.offset)
        y, th = getattr(self, "_thumb", (0, 0))
        if not (y <= e.y <= y + th):
            self._sb_drag(e, jump=True)

    def _sb_drag(self, e, jump=False):
        total = len(self.rows) * ROW_H
        view = max(self.list.winfo_height(), 1)
        h = max(self.sbar.winfo_height(), 1)
        if total <= view:
            return
        thumb = max(30, int(h * view / total))
        if jump:
            frac = (e.y - thumb / 2) / max(h - thumb, 1)
            self.offset = frac * (total - view)
        else:
            start_y, start_off = self._sb_start
            self.offset = start_off + (e.y - start_y) * (total - view) / max(h - thumb, 1)
        self._redraw()

                                                                                              
    def rebuild(self):
        needle = "" if self.placeholder else self.filter_var.get().strip().lower()
        rows = [g for g in self.manager.groups.values()
                if not needle or needle in g.name.lower() or needle in g.classname.lower()]
        rows.sort(key=self._sort_value, reverse=self.sort_desc)
        self.rows = rows
        self.update_summary()
        self._paint_card()
        self._redraw()

    def refresh_values(self):
        self.update_summary()
        self._paint_card()
        self._redraw()
        if hasattr(self, "room_tree"):
            self.update_room()

    def _tick(self):
        self.dots += 1
        if any(g.price.state in ("pending", "loading") for g in self.manager.groups.values()):
            self._redraw()
        self.root.after(450, self._tick)

    def update_summary(self):
        groups = list(self.manager.groups.values())
        done = sum(1 for g in groups if g.price.state not in ("pending", "loading"))
        self.prog = (done, max(len(groups), 1))
        self._paint_progress()
        lister = self.manager.lister
        if self.manager.furnimatic_running:
            self.status_var.set(self.manager.furnimatic_status)
        elif lister.running or (lister.status and lister.done):
            self.status_var.set(lister.status)
        elif self.manager.inventory_loading:
            self.status_var.set("Loading inventory...")
        elif groups:
            busy = len(groups) - done
            self.status_var.set(f"Pricing {done}/{len(groups)}..." if busy else "Prices complete")

    def _paint_progress(self):
        p = self.progress
        p.delete("all")
        done, total = self.prog
        p.create_rectangle(0, 0, 219, 17, fill=C["outline"], outline=C["outline"])
        p.create_rectangle(1, 1, 218, 16, fill="#444444", outline="#444444")
        segs = 20
        filled = int(segs * done / total)
        for i in range(segs):
            x = 3 + i * 10.4
            colour = "#7fd63f" if i < filled else "#5a5a5a"
            p.create_rectangle(x, 3, x + 8.6, 14, fill=colour, outline=colour)

                                                                                      
    def _hover(self, e):
        idx = int((e.y + self.offset) // ROW_H)
        if idx != self.hover_row:
            self.hover_row = idx if 0 <= idx < len(self.rows) else -1
            self._redraw()
            self._hide_tip()
        if self.hover_row >= 0:
            if self.tip is None:
                self._show_tip(self.rows[self.hover_row], e)
            else:
                self.tip.geometry(f"+{e.x_root + 18}+{e.y_root + 14}")

    def _leave(self):
        self.hover_row = -1
        self._hide_tip()
        self._redraw()

    def _tip_text(self, g: FurniGroup) -> str:
        lines = [f"Furniture: {g.name or '(unknown)'}", f"Quantity: {g.quantity}"]
        if g.price.state != "ok":
            lines += ["", g.price.message or "Price not available yet"]
            return "\n".join(lines)
        if self.mode in ("avg", "both"):
            a = g.price.average
            lines += [f"Average price: {fmt_c(a)}", "", "Calculation:", f"{fmt_c(a)} x {g.quantity} = {fmt_c(a * g.quantity)}"]
        if self.mode in ("current", "both"):
            cur = g.price.current
            if self.mode == "both":
                lines.append("")
            lines += [f"Current (cheapest) price: {fmt_c(cur)}", "", "Calculation:",
                      f"{fmt_c(cur)} x {g.quantity} = {fmt_c(cur * g.quantity)}"]
        lines += ["", f"Active listings: {g.price.listings}"]
        if g.price.message:
            lines += [g.price.message]
        return "\n".join(lines)

    def _show_tip(self, g, e):
        tip = tk.Toplevel(self.root)
        tip.overrideredirect(True)
        tip.attributes("-topmost", True)
        tip.configure(bg="#ffffff")
        tk.Label(tip, text=self._tip_text(g), justify="left", bg=C["tip_bg"], fg=C["tip_fg"], font=self.f,
                 padx=12, pady=9).pack(padx=1, pady=1)
        tip.geometry(f"+{e.x_root + 18}+{e.y_root + 14}")
        tip.lift()
        self.tip = tip

    def _hide_tip(self):
        if self.tip is not None:
            self.tip.destroy()
            self.tip = None

                                                                                
    def _dialog(self, title, text, buttons):
        self._hide_tip()
        HabboDialog(self.root, title, text, buttons, (self.f, self.fb))

    def list_all(self):
        lister = self.manager.lister
        if lister.running:
            lister.stop()
            self.list_btn.configure_button(text="Stopping...", enabled=False)
            return
        if self.manager.inventory_loading or any(g.price.state in ("pending", "loading")
                                                 for g in self.manager.groups.values()):
            self._dialog("Please wait", "Prices are still loading. Try again when pricing is complete.",
                         [("OK", "blue", None)])
            return
        jobs, skipped = self.manager.listing_plan()
        if not jobs:
            self._dialog("Nothing to list", "No items have a usable MP AVG price.\n\n"
                         f"No price: {skipped['no_price']}\nEstimated average only: {skipped['estimated']}\n"
                         f"Not tradeable: {skipped['not_tradeable']}", [("OK", "blue", None)])
            return
        total = sum(j.price * j.quantity for j in jobs)
        item_count = sum(j.quantity for j in jobs)
        interval = float(self.settings["list_interval"])
        text = (f"List all {item_count} items on the Marketplace at their MP AVG?\n\n"
                f"{len(jobs)} Marketplace batches (one per furniture type)\n"
                f"Total asking price: {total:,}c\n"
                f"Estimated time: about {int(len(jobs) * (interval + 0.5))} seconds.\n\n"
                f"Skipped: {skipped['not_tradeable']} not tradeable, {skipped['no_price']} without a price, "
                f"{skipped['estimated']} with only an estimated average, {skipped['zero']} priced under 1c.\n\n"
                "Listing stops at the first error. Cancel offers in the Marketplace window if you change your mind.")
        self._dialog("Confirm listing", text, [("List them", "green", lambda: lister.start(jobs)),
                                               ("Cancel", "grey", None)])

    def furnimatic_toggle(self):
        manager = self.manager
        if manager.furnimatic_running:
            manager.stop_furnimatic()
            self.furnimatic_btn.configure_button(text="Stopping...", enabled=False)
            return
        if manager.lister.running:
            self._dialog("Please wait", "Marketplace listing is running. Stop it before starting FurniMatic.",
                         [("OK", "blue", None)])
            return
        if manager.inventory_loading or any(g.price.state in ("pending", "loading")
                                            for g in manager.groups.values()):
            self._dialog("Please wait", "Prices are still loading. Try again when pricing is complete.",
                         [("OK", "blue", None)])
            return
        try:
            max_avg = int(self.furnimatic_max_var.get().replace(",", "").strip())
            if max_avg < 1:
                raise ValueError
        except ValueError:
            self._dialog("Invalid number", "Enter a whole number of credits (1 or more) for the MP AVG limit.",
                         [("OK", "blue", None)])
            return
        self.settings.set("furnimatic_max_avg", max_avg)
        batches, stats = manager.furnimatic_plan(max_avg)
        if not batches:
            self._dialog("Nothing to recycle",
                         f"Need at least {RECYCLE_BATCH} items with an MP AVG below {max_avg:,}c.\n\n"
                         f"Matching items: {stats['matching']}\nWithout a usable price (ignored): {stats['no_price']}",
                         [("OK", "blue", None)])
            return
        count = sum(len(b) for b in batches)
        text = (f"Recycle {count} items with an MP AVG below {max_avg:,}c?\n\n"
                f"{len(batches)} recycler batches of {RECYCLE_BATCH} items ({stats['types']} furniture types)\n"
                f"Left over (not a full batch of {RECYCLE_BATCH}): {stats['leftover']}\n"
                f"Ignored (no usable price): {stats['no_price']}\n\n"
                "Recycled items are destroyed and cannot be got back. Stops at the first error.")
        self._dialog("Confirm FurniMatic", text, [("Recycle them", "red", lambda: manager.start_furnimatic(batches)),
                                                  ("Cancel", "grey", None)])

    def update_furnimatic(self):
        manager = self.manager
        if manager.furnimatic_running:
            self.furnimatic_btn.configure_button(text="Stop FurniMatic", theme="red", enabled=True)
        else:
            self.furnimatic_btn.configure_button(text="Start FurniMatic", theme="green", enabled=True)
        if manager.furnimatic_status:
            self.status_var.set(manager.furnimatic_status)

    def update_listing(self):
        lister = self.manager.lister
        if lister.running:
            self.list_btn.configure_button(text="Stop listing", theme="red", enabled=True)
        else:
            self.list_btn.configure_button(text="List all at MP AVG", theme="green", enabled=True)
        if lister.status:
            self.status_var.set(lister.status)
        if not lister.running and lister.done:
            self.manager.request_inventory()

                                                                                        
             
                                                                                        
def main() -> int:
                                                                           

                                                                                 
                                                                                    
                                          
       
    root = None
    ext = None
    startup_log("========== MyFurni process started ==========")
    startup_log(f"Python={sys.version.split()[0]} executable={sys.executable}")
    startup_log(f"Script directory={BASE_DIR}")
    startup_log(f"Arguments={sys.argv!r}")

    try:
        sys.path.insert(0, str(BASE_DIR))
        startup_log("Creating G-Python Extension object")
        ext = Extension(EXTENSION_INFO, sys.argv, {"use_click_trigger": True}, silent=True)

                                                                               
                                                                             
                                                                        
        ext.on_event("init", lambda: startup_log("G-Earth extension socket initialized (extension registered)"))
        ext.on_event("connection_end", lambda: startup_log("Habbo connection_end event received"))
        startup_log("G-Python extension object created; lifecycle diagnostics registered")

        ui_queue: "queue.Queue[Callable]" = queue.Queue()
        root = tk.Tk()
        root.withdraw()                                    
        startup_log("Tk root created and hidden")

        settings = Settings()
        startup_log(f"Settings loaded from {CONFIG_PATH}")
        manager = MyFurniManager(ext, settings, ui_queue.put)
        startup_log("MyFurniManager created; packet interceptors and worker services registered")

                                                                                   
                                                                                  
        startup_log("Calling ext.start()")
        ext.start()
        startup_log("ext.start() returned")

        manager.ui = InventoryWindow(root, manager)
        startup_log("Inventory UI constructed successfully")

        def pump():
            try:
                while True:
                    ui_queue.get_nowait()()
            except queue.Empty:
                pass
            except Exception:
                startup_log("Exception while processing a queued UI update", exc_info=True)
            try:
                if ext.is_closed():
                    startup_log("G-Python reports the G-Earth socket is closed; shutting down Tk")
                    root.destroy()
                    return
            except Exception:
                startup_log("Exception while checking extension socket state", exc_info=True)
            root.after(100, pump)

        startup_log("Entering Tk main loop")
        pump()
        root.mainloop()
        startup_log("Tk main loop exited; extension process is ending")
        return 0

    except BaseException:
        startup_log("FATAL STARTUP/RUNTIME FAILURE", exc_info=True)
        if root is not None:
            try:
                root.destroy()
            except Exception:
                pass
        return 1


if __name__ == "__main__":
    sys.exit(main())
