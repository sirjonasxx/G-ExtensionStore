from __future__ import annotations

import json
import os
import queue
import sys
import threading
import time
import urllib.request
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Optional

BASE_DIR = Path(__file__).resolve().parent
CONFIG_PATH = BASE_DIR / "config.json"
FURNIDATA_CACHE = BASE_DIR / "furnidata_cache.json"
STARTUP_LOG = BASE_DIR / "startup.log"
_STARTUP_LOG_LOCK = threading.Lock()


def startup_log(message: str, *, exc_info: bool = False) -> None:
                                                                                       
    try:
        stamp = time.strftime("%Y-%m-%d %H:%M:%S")
        detail = f"[{stamp}] [pid={os.getpid()}] {message}"
        if exc_info:
            import traceback
            detail += "\n" + traceback.format_exc()
        with _STARTUP_LOG_LOCK:
            with STARTUP_LOG.open("a", encoding="utf-8") as fh:
                fh.write(detail.rstrip() + "\n")
                fh.flush()
    except Exception:
                                                                     
        pass


                                                                                  
_ORIGINAL_EXCEPTHOOK = sys.excepthook

def _startup_excepthook(exc_type, exc_value, exc_tb):
    try:
        import traceback
        startup_log("UNCAUGHT PYTHON EXCEPTION\n" + "".join(
            traceback.format_exception(exc_type, exc_value, exc_tb)))
    finally:
        _ORIGINAL_EXCEPTHOOK(exc_type, exc_value, exc_tb)

sys.excepthook = _startup_excepthook
if hasattr(threading, "excepthook"):
    _ORIGINAL_THREAD_EXCEPTHOOK = threading.excepthook
    def _startup_thread_excepthook(args):
        try:
            import traceback
            startup_log(f"UNCAUGHT THREAD EXCEPTION ({args.thread.name})\n" + "".join(
                traceback.format_exception(args.exc_type, args.exc_value, args.exc_traceback)))
        finally:
            _ORIGINAL_THREAD_EXCEPTHOOK(args)
    threading.excepthook = _startup_thread_excepthook

try:
    from g_python.gextension import Extension
    try:                                                 
        from g_python.gextension import ConsoleColour
    except ImportError:                                                         
        class ConsoleColour:
            BLACK, BLUE, GREEN, ORANGE, RED = "black", "blue", "green", "orange", "red"
    from g_python.hmessage import Direction, HMessage
    from g_python.hpacket import HPacket
    from g_python.hparsers import HInventoryItem
    from g_python.htools import Inventory
except BaseException:
    startup_log("G-Python import/dependency failure", exc_info=True)
    raise


                                                                                
CHAT_OUT = "Chat"                                                                                   
MP_SEARCH_OUT = "GetMarketplaceOffers"                                                                        
MP_OFFERS_IN = "MarketPlaceOffers"                                                                          
MP_MAKEOFFER_OUT = "MakeOffer"                                                                                                    
MP_MAKEOFFER_RESULT = "marketplacemakeofferresult"                                                              
INVENTORY_REQUEST_OUT = "RequestFurniInventory"                                                
INVENTORY_LIST_IN = "FurniList"                                                                

EXTENSION_INFO = {
    "title": "MyFurni",
    "description": "Type :inv - inventory grouped by type, valued from Marketplace packets",
    "version": "1.0",
    "author": "floppidity",
}

PRICE_MODES = {"avg": "MP AVG", "current": "Current", "both": "Both"}


                                                                                        
                                                       
                                                                                        
DEFAULT_SETTINGS = {
    "price_mode": "avg",                                                                   
    "request_interval": 1.5,                                                                
    "request_timeout": 8.0,                                                         
    "request_retries": 1,                                                 
    "sort_type": 1,                                                                  
    "search_header_id": 0,                                                                                   
    "offers_header_id": 0,
    "makeoffer_header_id": 0,                                                                     
    "list_interval": 2.0,                                                        
    "list_timeout": 10.0,                                                                    
    "list_success_code": 1,                                                                            
    "ui_font": "",                                                                                       
    "custom_frame": True,                                                                       
    "list_skip_estimated": True,                                                                                                                                                            
    "furnidata_url": "https://www.habbo.com/gamedata/furnidata_json/1",
    "furnidata_path": "",                                                                    
}


class Settings:
    def __init__(self, path: Path = CONFIG_PATH):
        self.path = path
        self._lock = threading.Lock()
        self.data = dict(DEFAULT_SETTINGS)
        self.load()

    def load(self) -> None:
        try:
            with open(self.path, "r", encoding="utf-8") as fh:
                stored = json.load(fh)
            if isinstance(stored, dict):
                self.data.update({k: v for k, v in stored.items() if k in DEFAULT_SETTINGS})
        except FileNotFoundError:
            self.save()
        except (OSError, ValueError) as exc:
            print(f"[settings] could not read {self.path}: {exc} - using defaults", file=sys.stderr)
        if self.data["price_mode"] not in PRICE_MODES:
            self.data["price_mode"] = "avg"

    def save(self) -> None:
        with self._lock:
            tmp = self.path.with_suffix(".tmp")
            try:
                with open(tmp, "w", encoding="utf-8") as fh:
                    json.dump(self.data, fh, indent=2)
                os.replace(tmp, self.path)
            except OSError as exc:
                print(f"[settings] could not save {self.path}: {exc}", file=sys.stderr)

    def __getitem__(self, key: str):
        return self.data[key]

    def set(self, key: str, value) -> None:
        self.data[key] = value
        self.save()


                                                                                        
                              
                                                                                        
class MarketplaceParseError(Exception):
    pass


@dataclass
class OfferRow:
    offer_id: int
    kind: int                                 
    type_id: int                                                  
    price: int                                                    
    time_left: int
    average: int                                                                  
    count: int                                                 

    @property
    def is_floor(self) -> bool:
        return self.kind == 1


def parse_offers(packet: HPacket) -> list[OfferRow]:
       
                                                                    

                                                                
                            
                                                                             
                                                                                 
                                                                                       
                                                                                   
                                              
       
    packet.reset()
    try:
        count = packet.read_int()
        if not 0 <= count <= 5000:
            raise MarketplaceParseError(f"implausible row count {count}")
        rows: list[OfferRow] = []
        for _ in range(count):
            offer_id, _status, kind = packet.read("iii")
            if kind == 1:
                type_id = packet.read_int()
                category = packet.read_int()
                if category != 0:
                    raise MarketplaceParseError(f"unsupported stuff category {category}")
                packet.read_string()
            elif kind == 2:
                type_id = packet.read_int()
                packet.read_string()                                                 
            else:
                raise MarketplaceParseError(f"unsupported offer kind {kind}")
            price, time_left, average, offers = packet.read("iiii")
            if price < 0 or average < 0 or offers < 0:
                raise MarketplaceParseError("negative price/average/count")
            rows.append(OfferRow(offer_id, kind, type_id, price, time_left, average, offers))
                                                       
        remaining = len(packet.bytearray) - packet.read_index
        if remaining == 4:
            packet.read_int()
        elif remaining != 0:
            raise MarketplaceParseError(f"{remaining} unread bytes after parsing")
        return rows
    except MarketplaceParseError:
        raise
    except Exception as exc:                                         
        raise MarketplaceParseError(f"malformed packet: {exc}") from exc
    finally:
        packet.reset()


                                                                                        
            
                                                                                        
Key = tuple[bool, int]                              


@dataclass
class PriceInfo:
    state: str = "pending"                                                             
    average: Optional[int] = None                                       
    current: Optional[int] = None                              
    listings: int = 0
    message: str = ""
    avg_real: bool = False                                                                  


@dataclass
class FurniGroup:
    key: Key
    name: str
    classname: str
    quantity: int = 0
    marketable: int = 0                                                                 
    listable_ids: list[int] = field(default_factory=list)                                          
    price: PriceInfo = field(default_factory=PriceInfo)

    def unit(self, metric: str) -> Optional[int]:
        if self.price.state != "ok":
            return None
        return self.price.average if metric == "avg" else self.price.current

    def total(self, metric: str) -> Optional[int]:
        unit = self.unit(metric)
        return None if unit is None else unit * self.quantity


def fmt_c(value: Optional[int]) -> str:
    return "-" if value is None else f"{value:,}c"


                                                                                        
                                                            
                                                                                        
def load_furnidata(settings: Settings, log: Callable[[str], None]) -> dict[Key, tuple[str, str]]:
    raw = None
    local = settings["furnidata_path"] or str(BASE_DIR / "furnidata.json")
    try:
        if local and Path(local).is_file():
            raw = json.loads(Path(local).read_text(encoding="utf-8"))
        elif FURNIDATA_CACHE.is_file() and time.time() - FURNIDATA_CACHE.stat().st_mtime < 7 * 86400:
            raw = json.loads(FURNIDATA_CACHE.read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        log(f"furnidata cache unreadable: {exc}")
    if raw is None:
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                          "(KHTML, like Gecko) Chrome/124.0 Safari/537.36",
            "Accept": "application/json,text/plain,*/*", "Accept-Language": "en-US,en;q=0.9",
            "Referer": "https://www.habbo.com/", "Origin": "https://www.habbo.com"}
        try:
            req = urllib.request.Request(settings["furnidata_url"], headers=headers)
            with urllib.request.urlopen(req, timeout=30) as resp:
                body = resp.read()
        except Exception as exc:
            raise RuntimeError(
                f"{exc}. Habbo blocked the download. Open {settings['furnidata_url']} in your browser, "
                f"save the page as furnidata.json next to the extension and restart it.") from exc
        raw = json.loads(body.decode("utf-8"))
        try:
            FURNIDATA_CACHE.write_bytes(body)
        except OSError:
            pass
    names: dict[Key, tuple[str, str]] = {}
    for section, is_floor in (("roomitemtypes", True), ("wallitemtypes", False)):
        for entry in raw.get(section, {}).get("furnitype", []):
            try:
                names[(is_floor, int(entry["id"]))] = (str(entry.get("classname", "")),
                                                       str(entry.get("name") or entry.get("classname", "")))
            except (KeyError, ValueError, TypeError):
                continue
    if not names:
        raise ValueError("furnidata contained no furniture entries")
    return names


                                                                                        
                                                        
                                                                                        
class MarketplaceService:
       
                                      
                                                                                    
                                                                                          
                                                                                        
                                                                                         
                                                 
       

    def __init__(self, ext: Extension, settings: Settings, on_update: Callable[[], None],
                 log: Callable[[str], None]):
        self.ext, self.settings, self.on_update, self.log = ext, settings, on_update, log
        self.cache: dict[Key, PriceInfo] = {}
        self._queue: "queue.Queue[str]" = queue.Queue()
        self._pending: dict[str, set[Key]] = {}
        self._lock = threading.Lock()
        self._inflight: Optional[str] = None
        self._answer = threading.Event()
        self._result: Optional[list[OfferRow] | Exception] = None
        self.last_raw: Optional[bytes] = None
        self._last_sent = 0.0
        self.outstanding = 0
        ext.intercept(Direction.TO_CLIENT, self._on_offers, MP_OFFERS_IN)
        override = int(settings["offers_header_id"] or 0)
        if override:
            ext.intercept(Direction.TO_CLIENT, self._on_offers, override)
        ext.on_event("connection_start", self.report_headers)
        threading.Thread(target=self._worker, name="mp-worker", daemon=True).start()

                                 
    def resolve_header(self, name: str, direction: Direction, override_key: str) -> tuple[Optional[int], str]:
        override = int(self.settings[override_key] or 0)
        if override:
            return override, f"config {override_key}"
        if getattr(self.ext, "connection_info", None) is None:
            return None, "G-Earth is not connected to a Habbo client (reconnect to the hotel through G-Earth)"
        infos = getattr(self.ext, "packet_infos", None)
        if not infos:
            return None, "G-Earth sent no packet names (reconnect to the hotel while the extension is running)"
        table = infos.get(direction, {})
        entries = table.get(name)
        if not entries:
            for key, val in table.items():
                if isinstance(key, str) and key.lower() == name.lower() and val:
                    entries = val
                    break
        if not entries:
            return None, (f"G-Earth does not know a packet named '{name}' for this client version; "
                          f"find its header ID in the G-Earth packet log and set '{override_key}' in config.json")
        return int(entries[0]["Id"]), "G-Earth/Harble name"

    def report_headers(self) -> None:
        startup_log("Habbo connection_start event received; resolving Marketplace packet headers")
        out_id, out_src = self.resolve_header(MP_SEARCH_OUT, Direction.TO_SERVER, "search_header_id")
        in_id, in_src = self.resolve_header(MP_OFFERS_IN, Direction.TO_CLIENT, "offers_header_id")
        ok = out_id is not None and in_id is not None
        self.ext.write_to_console(
            f"{MP_SEARCH_OUT} -> {out_id if out_id is not None else 'UNRESOLVED: ' + out_src}; "
            f"{MP_OFFERS_IN} -> {in_id if in_id is not None else 'UNRESOLVED: ' + in_src}",
            ConsoleColour.GREEN if ok else ConsoleColour.RED)

                      
    def request(self, group: FurniGroup) -> None:
        key = group.key
        with self._lock:
            cached = self.cache.get(key)
            if cached is not None and cached.state in ("ok", "none"):
                group.price = cached
                return
            if group.marketable <= 0:
                group.price = PriceInfo("blocked", message="Not tradeable on Marketplace")
                return
            if not group.name:
                group.price = PriceInfo("error", message="Unknown furniture name")
                return
            group.price = self.cache.setdefault(key, PriceInfo("pending"))
            if group.price.state == "loading":
                return
            group.price.state = "loading"
            query = group.name
            first = query not in self._pending
            self._pending.setdefault(query, set()).add(key)
            self.outstanding += 1
        if first:
            self._queue.put(query)

                             
    def _on_offers(self, message: HMessage) -> None:
        with self._lock:
            if self._inflight is None:
                return                                                                             
        message.is_blocked = True                                                                    
        self.last_raw = bytes(message.packet.bytearray)
        try:
            self._result = parse_offers(message.packet)
        except MarketplaceParseError as exc:
            self._result = exc
        self._answer.set()

                             
    def _worker(self) -> None:
        while True:
            query = self._queue.get()
            with self._lock:
                keys = self._pending.pop(query, set())
            if not keys:
                continue
            rows, error = self._search(query)
            with self._lock:
                for key in keys:
                                                                                            
                    self.cache[key].__dict__.update(self._resolve(key, rows, error).__dict__)
                    self.outstanding -= 1
            self.on_update()

    def _search(self, query: str) -> tuple[Optional[list[OfferRow]], str]:
        error = "no response"
        for _attempt in range(1 + int(self.settings["request_retries"])):
            wait = self.settings["request_interval"] - (time.monotonic() - self._last_sent)
            if wait > 0:
                time.sleep(wait)
            self._answer.clear()
            self._result = None
            with self._lock:
                self._inflight = query
            header, why = self.resolve_header(MP_SEARCH_OUT, Direction.TO_SERVER, "search_header_id")
            if header is None:
                with self._lock:
                    self._inflight = None
                return None, why                                                                
            packet = HPacket(header, -1, -1, query, int(self.settings["sort_type"]), True)
            sent = self.ext.send_to_server(packet)
            self._last_sent = time.monotonic()
                                                                                                      
            if sent is False:
                with self._lock:
                    self._inflight = None
                return None, (f"G-Earth refused packet id {header} ({why}); is the client connected "
                              f"through G-Earth? Try reconnecting, see the G-Earth console")
            got = self._answer.wait(self.settings["request_timeout"])
            with self._lock:
                self._inflight = None
            if not got:
                error = f"timed out after {self.settings['request_timeout']}s"
                continue
            if isinstance(self._result, Exception):
                return None, str(self._result)                                           
            return self._result, ""
        return None, error

    @staticmethod
    def _resolve(key: Key, rows: Optional[list[OfferRow]], error: str) -> PriceInfo:
        if rows is None:
            return PriceInfo("error", message=error)
        match = [r for r in rows if (r.type_id, r.is_floor) == (key[1], key[0])]
        if not match:
            return PriceInfo("none", message="No active listings")
        current = min(r.price for r in match)
        weight = sum(r.count for r in match)
        if any(r.average > 0 for r in match) and weight > 0:
            average = round(sum(r.average * r.count for r in match) / weight)
            note = ""
        else:
            average = round(sum(r.price * max(r.count, 1) for r in match) / max(weight, len(match)))
            note = "No sales average reported by the Marketplace - MP AVG falls back to the listing price"
        return PriceInfo("ok", average=average, current=current, listings=weight, message=note,
                         avg_real=(note == ""))

    def debug_dump(self) -> None:
        self.report_headers()
        info = (self.ext.packet_infos or {}).get(Direction.TO_CLIENT, {}).get(MP_OFFERS_IN)
        self.ext.write_to_console(f"{MP_OFFERS_IN} G-Earth info: {info}", ConsoleColour.BLUE)
        if self.last_raw is None:
            self.ext.write_to_console("No Marketplace response captured yet - open :inv first.",
                                      ConsoleColour.ORANGE)
            return
        self.ext.write_to_console(f"raw ({len(self.last_raw)} bytes): {self.last_raw[:240].hex(' ')}",
                                  ConsoleColour.BLUE)
        try:
            rows = parse_offers(HPacket.from_bytes(self.last_raw))
            self.ext.write_to_console(f"parsed {len(rows)} rows; first: {rows[:3]}", ConsoleColour.GREEN)
        except MarketplaceParseError as exc:
            self.ext.write_to_console(f"parse failed: {exc}", ConsoleColour.RED)


                                                                                        
                                                                            
                                                                                        
@dataclass
class ListingJob:
    name: str
    kind: int                                                                    
    item_id: int
    price: int


class ListingService:
       
                                                                                                     
                                                                                                
                                                                                                  
                                                                               
                                                                                                      
                                                       
       

    def __init__(self, ext: Extension, settings: Settings, market: MarketplaceService,
                 on_update: Callable[[], None], log: Callable[[str], None]):
        self.ext, self.settings, self.market, self.on_update, self.log = ext, settings, market, on_update, log
        self.running = False
        self.total = self.done = 0
        self.credits = 0
        self.status = ""
        self._stop = threading.Event()
        self._awaiting = False
        self._event = threading.Event()
        self._code: Optional[int] = None
        self._raw = b""
        ext.intercept(Direction.TO_CLIENT, self._on_incoming)                                         

    def _is_result(self, header_id: int) -> bool:
        infos = (getattr(self.ext, "packet_infos", None) or {}).get(Direction.TO_CLIENT, {})
        for elem in infos.get(header_id, []):
            if (elem.get("Name") or "").replace("_", "").lower() == MP_MAKEOFFER_RESULT:
                return True
        return False

    def _on_incoming(self, message: HMessage) -> None:
        if not self._awaiting:
            return
        packet = message.packet
        if not self._is_result(packet.header_id()):
            return
        message.is_blocked = True                                                                  
        self._raw = bytes(packet.bytearray)
        try:
            self._code = packet.read_int()
        except Exception:
            self._code = None
        packet.reset()
        self._event.set()

    def start(self, jobs: list[ListingJob]) -> bool:
        if self.running or not jobs:
            return False
        self.running, self.total, self.done, self.credits = True, len(jobs), 0, 0
        self.status = f"Listing 0/{self.total}..."
        self._stop.clear()
        threading.Thread(target=self._run, args=(jobs,), name="mp-lister", daemon=True).start()
        self.on_update()
        return True

    def stop(self) -> None:
        self._stop.set()

    def _finish(self, text: str, colour=ConsoleColour.BLACK) -> None:
        self.running = False
        self._awaiting = False
        self.status = text
        self.log(text, colour)
        self.on_update()

    def _run(self, jobs: list[ListingJob]) -> None:
        for job in jobs:
            if self._stop.is_set():
                return self._finish(f"Stopped. Listed {self.done}/{self.total} items.", ConsoleColour.ORANGE)
            header, why = self.market.resolve_header(MP_MAKEOFFER_OUT, Direction.TO_SERVER, "makeoffer_header_id")
            if header is None:
                return self._finish(f"Stopped after {self.done}: {why}", ConsoleColour.RED)
            self._event.clear()
            self._code = None
            self._awaiting = True
            sent = self.ext.send_to_server(HPacket(header, job.price, job.kind, 1, job.item_id))
            if sent is False:
                return self._finish(f"Stopped after {self.done}: G-Earth refused the MakeOffer packet", ConsoleColour.RED)
            got = self._event.wait(float(self.settings["list_timeout"]))
            self._awaiting = False
            if not got:
                return self._finish(f"Stopped after {self.done}: no confirmation for '{job.name}' "
                                    f"(it may or may not have been listed - check your Marketplace offers)",
                                    ConsoleColour.RED)
            if self._code != int(self.settings["list_success_code"]):
                return self._finish(f"Stopped after {self.done}: server answered code {self._code} for "
                                    f"'{job.name}' (raw: {self._raw.hex(' ')})", ConsoleColour.RED)
            self.done += 1
            self.credits += job.price
            self.status = f"Listing {self.done}/{self.total}... ({job.name} at {job.price}c)"
            self.on_update()
            if self._stop.wait(float(self.settings["list_interval"])):
                return self._finish(f"Stopped. Listed {self.done}/{self.total} items.", ConsoleColour.ORANGE)
        self._finish(f"Done: listed {self.done} items, asking {self.credits:,}c in total.", ConsoleColour.GREEN)


                                                                                        
                                                          
                                                                                        
class MyFurniManager:
    def __init__(self, ext: Extension, settings: Settings, ui_post: Callable[[Callable], None]):
        self.ext, self.settings, self.ui_post = ext, settings, ui_post
        self.groups: dict[Key, FurniGroup] = {}
        self.names: Optional[dict[Key, tuple[str, str]]] = None
        self.names_error = ""
        self.inventory_loading = False
        self.ui = None                                                  
        self.market = MarketplaceService(ext, settings, self._notify, self.log)
        self.lister = ListingService(ext, settings, self.market, self._on_listing_update, self.log)
        self.inventory = Inventory(ext)
        self.inventory.on_inventory_load(self._on_inventory)
        ext.intercept(Direction.TO_SERVER, self._on_chat, CHAT_OUT)
        ext.on_event("double_click", self.open)
        threading.Thread(target=self._load_names, daemon=True).start()

    def log(self, text: str, colour: ConsoleColour = ConsoleColour.BLACK) -> None:
        try:
            self.ext.write_to_console(text, colour)
        except Exception:
            print(text, file=sys.stderr)

    def _on_listing_update(self) -> None:
        self.ui_post(lambda: self.ui and self.ui.update_listing())

    def listing_plan(self) -> tuple[list[ListingJob], dict]:
                                                                                                  
        jobs: list[ListingJob] = []
        skipped = {"no_price": 0, "estimated": 0, "not_tradeable": 0, "zero": 0}
        skip_est = bool(self.settings["list_skip_estimated"])
        for g in self.groups.values():
            if not g.listable_ids:
                skipped["not_tradeable"] += g.quantity
                continue
            skipped["not_tradeable"] += g.quantity - len(g.listable_ids)
            if g.price.state != "ok" or g.price.average is None:
                skipped["no_price"] += len(g.listable_ids)
            elif skip_est and not g.price.avg_real:
                skipped["estimated"] += len(g.listable_ids)
            elif g.price.average < 1:
                skipped["zero"] += len(g.listable_ids)
            else:
                kind = 1 if g.key[0] else 2
                jobs += [ListingJob(g.name, kind, i, int(g.price.average)) for i in g.listable_ids]
        return jobs, skipped

    def _notify(self) -> None:
        self.ui_post(lambda: self.ui and self.ui.refresh_values())

                            
    def _on_chat(self, message: HMessage) -> None:
        try:
            text = message.packet.read_string().strip().lower()
        except Exception:
            return
        if text == ":inv":
            message.is_blocked = True
            self.open()
        elif text == ":inv debug":
            message.is_blocked = True
            threading.Thread(target=self.market.debug_dump, daemon=True).start()

    def open(self) -> None:
        self.ui_post(lambda: self.ui and self.ui.show())
        self.request_inventory()

    def request_inventory(self) -> None:
        self.inventory_loading = True
        self._notify()
        self.inventory.request()

                         
    def _load_names(self) -> None:
        try:
            self.names = load_furnidata(self.settings, self.log)
            self.log(f"Loaded {len(self.names)} furniture names", ConsoleColour.GREEN)
        except Exception as exc:
            self.names_error = f"{exc}"
            self.log(f"Could not load furniture names: {exc}", ConsoleColour.RED)
        if self.groups:
            self._on_inventory_items(None)

                         
    def _on_inventory(self, items: list[HInventoryItem]) -> None:
        self._on_inventory_items(items)

    _last_items: list[HInventoryItem] = []

    def _on_inventory_items(self, items: Optional[list[HInventoryItem]]) -> None:
        if items is not None:
            self._last_items = list(items)
        groups: dict[Key, FurniGroup] = {}
        for item in self._last_items:
            key: Key = (bool(item.is_floor_furni), int(item.type_id))
            classname, name = (self.names or {}).get(key, ("", ""))
            group = groups.setdefault(key, FurniGroup(key, name, classname))
            group.quantity += 1
            if item.market_place_allowed:
                group.marketable += 1
                group.listable_ids.append(int(item.id))
        self.groups = groups
        self.inventory_loading = False
        for group in groups.values():
            if self.names is None:
                group.price = PriceInfo("error", message=f"Furniture names unavailable: {self.names_error or 'still loading'}")
            else:
                self.market.request(group)
        self.ui_post(lambda: self.ui and self.ui.rebuild())


                                                                                        
                                              
                                                                                        
def fmt_c(value):
    return "-" if value is None else f"{value:,}c"


                                                                                        
                                                                                              
                                                                                   
                                                                     
                                                               
                                                                                        
try:
    import tkinter as tk
    import tkinter.font as tkfont
except BaseException:
    startup_log("Tkinter import failed", exc_info=True)
    raise

C = {
    "outline": "#000000", "frame": "#1c1c1c",
    "title": "#2f7fa3", "title_hi": "#4aa0c6", "title_lo": "#1f5f7d",
    "panel": "#cfcfcf", "panel_hi": "#ececec", "panel_lo": "#9a9a9a",
    "inset": "#ffffff", "row_a": "#ffffff", "row_b": "#ececec", "row_hover": "#d6ecf7",
    "head": "#b8b8b8", "text": "#1d1d1d", "muted": "#6b6b6b", "good": "#2b7d1f",
    "warn": "#b05a00", "bad": "#b3261e", "coin": "#f4c20d", "coin_lo": "#a67c00",
    "tip_bg": "#000000", "tip_fg": "#ffffff",
}
BUTTONS = {                                       
    "green": ("#9be05a", "#5fae2e", "#3b7a19"),
    "blue": ("#74c4ee", "#3b97cf", "#216896"),
    "red": ("#f2776c", "#cc3a2e", "#8d231a"),
    "grey": ("#f3f3f3", "#c4c4c4", "#8e8e8e"),
}
ROW_H = 42
HEAD_H = 28


def tile_colour(seed: str) -> str:
                                                                                          
    h = sum((i + 1) * ord(ch) for i, ch in enumerate(seed or "?")) % 360
    import colorsys
    r, g, b = colorsys.hsv_to_rgb(h / 360, 0.35, 0.92)
    return "#%02x%02x%02x" % (int(r * 255), int(g * 255), int(b * 255))


class PixelButton(tk.Canvas):
                                                                  

    def __init__(self, master, text, command, theme="grey", width=150, height=32, font=None, bg=None):
        super().__init__(master, width=width, height=height, highlightthickness=0, bd=0,
                         bg=bg or C["panel"], cursor="hand2")
        self.w, self.h, self.command, self.theme, self.font = width, height, command, theme, font
        self.text, self.state, self.enabled = text, "normal", True
        self.bind("<Enter>", lambda _e: self._set("hover"))
        self.bind("<Leave>", lambda _e: self._set("normal"))
        self.bind("<ButtonPress-1>", lambda _e: self._set("down"))
        self.bind("<ButtonRelease-1>", self._release)
        self.draw()

    def _set(self, state):
        if self.enabled:
            self.state = state
            self.draw()

    def _release(self, event):
        if not self.enabled:
            return
        inside = 0 <= event.x <= self.w and 0 <= event.y <= self.h
        self._set("hover" if inside else "normal")
        if inside and self.command:
            self.command()

    def configure_button(self, text=None, theme=None, enabled=None):
        if text is not None:
            self.text = text
        if theme is not None:
            self.theme = theme
        if enabled is not None:
            self.enabled = enabled
            self.configure(cursor="hand2" if enabled else "arrow")
        self.draw()

    def draw(self):
        self.delete("all")
        hi, face, lo = BUTTONS["grey"] if not self.enabled else BUTTONS[self.theme]
        if not self.enabled:
            hi, face, lo = "#dcdcdc", "#b4b4b4", "#9a9a9a"
        if self.state == "hover":
            face = hi if self.theme != "grey" else "#d8d8d8"
        down = self.state == "down" and self.enabled
        w, h = self.w, self.h
        self.create_rectangle(0, 0, w - 1, h - 1, outline=C["outline"], fill=C["outline"])
        self.create_rectangle(1, 1, w - 2, h - 2, outline=face, fill=face)
        top, bottom = (lo, hi) if down else (hi, lo)
        self.create_rectangle(1, 1, w - 2, 3, outline=top, fill=top)
        self.create_rectangle(1, h - 4, w - 2, h - 2, outline=bottom, fill=bottom)
        self.create_rectangle(0, 0, 1, 1, fill=C["panel"], outline=C["panel"])
        self.create_rectangle(w - 2, 0, w - 1, 1, fill=C["panel"], outline=C["panel"])
        colour = "#ffffff" if (self.enabled and self.theme != "grey") else ("#222222" if self.enabled else "#7a7a7a")
        y = h // 2 + (1 if down else 0)
        if self.enabled and self.theme != "grey":
            self.create_text(w // 2 + 1, y + 1, text=self.text, font=self.font, fill="#00000066" if False else lo)
        self.create_text(w // 2, y, text=self.text, font=self.font, fill=colour)


class ChoiceList(tk.Canvas):
                                                              

    def __init__(self, master, items, selected, on_change, font, small, multi=False, width=560):
        self.items, self.multi, self.on_change, self.font, self.small = items, multi, on_change, font, small
        self.selected = set(selected) if multi else selected
        super().__init__(master, width=width, height=len(items) * 54, highlightthickness=0, bd=0,
                         bg=C["panel"], cursor="hand2")
        self.bind("<Button-1>", self._click)
        self.draw()

    def _click(self, event):
        idx = event.y // 54
        if not 0 <= idx < len(self.items):
            return
        key = self.items[idx][0]
        if self.multi:
            self.selected ^= {key}
        else:
            self.selected = key
        self.draw()
        self.on_change(sorted(self.selected) if self.multi else key)

    def draw(self):
        self.delete("all")
        for i, (key, label, desc) in enumerate(self.items):
            y = i * 54
            on = key in self.selected if self.multi else key == self.selected
            self.create_rectangle(4, y + 8, 28, y + 32, fill=C["outline"], outline=C["outline"])
            self.create_rectangle(5, y + 9, 27, y + 31, fill=C["inset"], outline=C["inset"])
            if on:
                if self.multi:
                    self.create_line(9, y + 21, 15, y + 27, 26, y + 13, fill=C["good"], width=4)
                else:
                    self.create_rectangle(10, y + 14, 22, y + 26, fill=C["good"], outline=C["good"])
            self.create_text(40, y + 14, text=label, anchor="w", font=self.font, fill=C["text"])
            self.create_text(40, y + 34, text=desc, anchor="w", font=self.small, fill=C["muted"])


class HabboDialog:
                                                                                    

    def __init__(self, parent, title, text, buttons, fonts):
        self.top = tk.Toplevel(parent)
        top = self.top
        top.overrideredirect(True)
        top.configure(bg=C["outline"])
        top.attributes("-topmost", True)
        body_font, bold = fonts
        frame = tk.Frame(top, bg=C["panel"])
        frame.pack(padx=2, pady=2)
        bar = tk.Canvas(frame, height=28, width=500, highlightthickness=0, bg=C["title"])
        bar.pack(fill="x")
        bar.create_rectangle(0, 0, 500, 13, fill=C["title_hi"], outline=C["title_hi"])
        bar.create_text(12, 14, text=title, anchor="w", font=bold, fill="#ffffff")
        tk.Label(frame, text=text, justify="left", wraplength=460, bg=C["panel"], fg=C["text"], font=body_font
                 ).pack(padx=20, pady=(16, 10), anchor="w")
        row = tk.Frame(frame, bg=C["panel"])
        row.pack(pady=(4, 16))
        for label, theme, cb in buttons:
            PixelButton(row, label, lambda cb=cb: self._press(cb), theme, 170, 32, bold).pack(side="left", padx=6)
        parent.update_idletasks()
        top.update_idletasks()
        x = parent.winfo_rootx() + (parent.winfo_width() - top.winfo_width()) // 2
        y = parent.winfo_rooty() + (parent.winfo_height() - top.winfo_height()) // 3
        top.geometry(f"+{max(x, 0)}+{max(y, 0)}")
        top.lift()
        top.update()
        try:
            top.grab_set()
        except tk.TclError:
            pass

    def _press(self, cb):
        try:
            self.top.grab_release()
        except tk.TclError:
            pass
        self.top.destroy()
        if cb:
            cb()


class InventoryWindow:
    W, H = 960, 700

    def __init__(self, root, manager):
        self.root, self.manager, self.settings = root, manager, manager.settings
        available = set(tkfont.families(root))
        family = next((f for f in (self.settings["ui_font"], "Verdana", "Tahoma", "DejaVu Sans", "Arial")
                       if f and f in available), tkfont.nametofont("TkDefaultFont").actual()["family"])
        self.f = tkfont.Font(root=root, family=family, size=10)
        self.fb = tkfont.Font(root=root, family=family, size=10, weight="bold")
        self.fs = tkfont.Font(root=root, family=family, size=8)
        self.fbig = tkfont.Font(root=root, family=family, size=18, weight="bold")
        self.sort_col, self.sort_desc = "total", True
        self.rows = []
        self.offset = 0
        self.hover_row = -1
        self.tip = None
        self.dots = 0
        self.custom_frame = bool(self.settings["custom_frame"])
        self.page = "inventory"

        root.title("MyFurni")
        root.configure(bg=C["outline"])
        if self.custom_frame:
            root.overrideredirect(True)
        root.geometry(f"{self.W}x{self.H}+120+60")
        root.protocol("WM_DELETE_WINDOW", root.withdraw)
        self._build()
        self.root.after(450, self._tick)

                                                                                     
    def _build(self):
        outer = tk.Frame(self.root, bg=C["frame"])
        outer.pack(fill="both", expand=True, padx=1, pady=1)
        self._build_title(outer)
        body = tk.Frame(outer, bg=C["panel"])
        body.pack(fill="both", expand=True, padx=3, pady=(0, 3))
        self._build_tabs(body)
        self.pages = tk.Frame(body, bg=C["panel"], highlightbackground=C["outline"], highlightthickness=1)
        self.pages.pack(fill="both", expand=True, padx=6, pady=(0, 6))
        self.inv_page = tk.Frame(self.pages, bg=C["panel"])
        self.set_page = tk.Frame(self.pages, bg=C["panel"])
        self._build_inventory(self.inv_page)
        self._build_settings(self.set_page)
        self.show_page("inventory")

    def _build_title(self, parent):
        bar = tk.Canvas(parent, height=34, highlightthickness=0, bg=C["title"])
        bar.pack(fill="x")
        self.title_bar = bar

        def paint(_e=None):
            w = bar.winfo_width()
            bar.delete("all")
            bar.create_rectangle(0, 0, w, 15, fill=C["title_hi"], outline=C["title_hi"])
            bar.create_rectangle(0, 30, w, 34, fill=C["title_lo"], outline=C["title_lo"])
                                     
            bar.create_rectangle(10, 8, 28, 26, fill=C["outline"], outline=C["outline"])
            bar.create_rectangle(11, 9, 27, 25, fill="#d99a4e", outline="#d99a4e")
            bar.create_rectangle(11, 15, 27, 19, fill="#a8672a", outline="#a8672a")
            bar.create_rectangle(17, 9, 21, 25, fill="#a8672a", outline="#a8672a")
            bar.create_text(37, 18, text="Inventory", anchor="w", font=self.fb, fill="#000000")
            bar.create_text(36, 17, text="Inventory", anchor="w", font=self.fb, fill="#ffffff")
            bar.create_rectangle(w - 34, 5, w - 8, 29, fill=C["outline"], outline=C["outline"])
            bar.create_rectangle(w - 33, 6, w - 9, 28, fill="#d9503f", outline="#d9503f")
            bar.create_rectangle(w - 33, 6, w - 9, 11, fill="#f08a7c", outline="#f08a7c")
            bar.create_line(w - 27, 12, w - 15, 23, fill="#ffffff", width=3)
            bar.create_line(w - 27, 23, w - 15, 12, fill="#ffffff", width=3)

        bar.bind("<Configure>", paint)

        def press(e):
            if e.x >= bar.winfo_width() - 36:
                self.root.withdraw()
            else:
                self._drag = (e.x_root - self.root.winfo_x(), e.y_root - self.root.winfo_y())

        def drag(e):
            if getattr(self, "_drag", None) and self.custom_frame:
                self.root.geometry(f"+{e.x_root - self._drag[0]}+{e.y_root - self._drag[1]}")

        bar.bind("<ButtonPress-1>", press)
        bar.bind("<B1-Motion>", drag)

    def _build_tabs(self, parent):
        tabs = tk.Canvas(parent, height=34, highlightthickness=0, bg=C["panel"])
        tabs.pack(fill="x", padx=6, pady=(8, 0))
        self.tabs = tabs
        self.tab_defs = [("inventory", "Inventory", 8), ("settings", "Settings", 150)]
        tabs.bind("<Button-1>", self._tab_click)
        tabs.bind("<Configure>", lambda _e: self._paint_tabs())

    def _paint_tabs(self):
        t = self.tabs
        t.delete("all")
        for key, label, x in self.tab_defs:
            active = key == self.page
            y0 = 4 if active else 9
            fill = C["panel_hi"] if active else C["head"]
            t.create_rectangle(x, y0, x + 132, 34, fill=C["outline"], outline=C["outline"])
            t.create_rectangle(x + 1, y0 + 1, x + 131, 34, fill=fill, outline=fill)
            t.create_text(x + 66, (y0 + 34) // 2 + 1, text=label, font=self.fb, fill=C["text"])

    def _tab_click(self, e):
        for key, _label, x in self.tab_defs:
            if x <= e.x <= x + 132:
                self.show_page(key)

    def show_page(self, key):
        self.page = key
        self.inv_page.pack_forget()
        self.set_page.pack_forget()
        (self.inv_page if key == "inventory" else self.set_page).pack(fill="both", expand=True, padx=8, pady=8)
        self._paint_tabs()

    def _build_inventory(self, p):
                    
        card = tk.Canvas(p, height=84, highlightthickness=0, bg=C["panel"])
        card.pack(fill="x")
        self.card = card
        card.bind("<Configure>", lambda _e: self._paint_card())

                              
        bar = tk.Frame(p, bg=C["panel"])
        bar.pack(fill="x", pady=(8, 6))
        box = tk.Frame(bar, bg=C["outline"])
        box.pack(side="left", fill="x", expand=True, ipady=0)
        inner = tk.Frame(box, bg=C["inset"])
        inner.pack(fill="x", padx=1, pady=1)
        self.filter_var = tk.StringVar()
        self.entry = tk.Entry(inner, textvariable=self.filter_var, relief="flat", bd=0, bg=C["inset"], fg=C["text"],
                              insertbackground=C["text"], font=self.f, highlightthickness=0)
        self.entry.pack(fill="x", padx=8, pady=7)
        self.placeholder = True
        self._set_placeholder()
        self.entry.bind("<FocusIn>", self._focus_in)
        self.entry.bind("<FocusOut>", lambda _e: self._set_placeholder())
        self.filter_var.trace_add("write", lambda *_: self._filter_changed())
        PixelButton(bar, "Refresh", self.manager.request_inventory, "blue", 110, 34, self.fb).pack(side="left", padx=(8, 0))

              
        wrap = tk.Frame(p, bg=C["outline"])
        wrap.pack(fill="both", expand=True)
        inner = tk.Frame(wrap, bg=C["inset"])
        inner.pack(fill="both", expand=True, padx=1, pady=1)
        self.head = tk.Canvas(inner, height=HEAD_H, highlightthickness=0, bg=C["head"])
        self.head.pack(fill="x")
        mid = tk.Frame(inner, bg=C["inset"])
        mid.pack(fill="both", expand=True)
        self.list = tk.Canvas(mid, highlightthickness=0, bg=C["row_a"])
        self.list.pack(side="left", fill="both", expand=True)
        self.sbar = tk.Canvas(mid, width=16, highlightthickness=0, bg=C["panel_lo"])
        self.sbar.pack(side="right", fill="y")
        self.list.bind("<Configure>", lambda _e: self._redraw())
        self.list.bind("<Motion>", self._hover)
        self.list.bind("<Leave>", lambda _e: self._leave())
        self.head.bind("<Button-1>", self._head_click)
        for widget in (self.list, self.sbar):
            widget.bind("<MouseWheel>", self._wheel)
            widget.bind("<Button-4>", lambda _e: self._scroll(-ROW_H * 2))
            widget.bind("<Button-5>", lambda _e: self._scroll(ROW_H * 2))
        self.sbar.bind("<ButtonPress-1>", self._sb_press)
        self.sbar.bind("<B1-Motion>", self._sb_drag)

                
        foot = tk.Frame(p, bg=C["panel"])
        foot.pack(fill="x", pady=(8, 0))
        self.list_btn = PixelButton(foot, "List all at MP AVG", self.list_all, "green", 200, 34, self.fb)
        self.list_btn.pack(side="right")
        self.status_var = tk.StringVar(value="Type :inv in a room to load your inventory.")
        tk.Label(foot, textvariable=self.status_var, bg=C["panel"], fg=C["muted"], font=self.f, anchor="w"
                 ).pack(side="left", fill="x", expand=True)
        self.progress = tk.Canvas(foot, width=220, height=18, highlightthickness=0, bg=C["panel"])
        self.progress.pack(side="right", padx=12)
        self.prog = (0, 1)

    def _build_settings(self, p):
        tk.Label(p, text="Price information shown", bg=C["panel"], fg=C["text"], font=self.fb).pack(anchor="w")
        modes = [("avg", "MP AVG", "Average price reported by the Marketplace (default)"),
                 ("current", "Current", "Cheapest active Marketplace listing"),
                 ("both", "Both", "Show both columns and both totals")]
        ChoiceList(p, modes, self.settings["price_mode"], self._mode_changed, self.fb, self.fs).pack(anchor="w", pady=(6, 14))

        tk.Label(p, text="Speed", bg=C["panel"], fg=C["text"], font=self.fb).pack(anchor="w")
        self._speed_control(
            p, "Inventory indexing / MP refresh", 
            "Delay between Marketplace price lookups while inventory is being indexed. Lower is faster.",
            "request_interval", 0.5, 3.0)
        self._speed_control(
            p, "Marketplace listing", 
            "Delay between successful item listings. Lower is faster; server confirmations are still required.",
            "list_interval", 0.5, 5.0)

        tk.Label(p, text="Listing", bg=C["panel"], fg=C["text"], font=self.fb).pack(anchor="w", pady=(12, 0))
        opts = [("skip_est", "Skip items without a real sales average",
                 "When the Marketplace reports no sales average, MP AVG is only a listing price")]
        sel = ["skip_est"] if self.settings["list_skip_estimated"] else []
        ChoiceList(p, opts, sel, lambda v: self._skip_changed("skip_est" in v), self.fb, self.fs, multi=True
                   ).pack(anchor="w", pady=(6, 12))
        tk.Label(p, text="Settings are saved automatically to config.json", bg=C["panel"], fg=C["muted"],
                 font=self.fs).pack(anchor="w")

    def _speed_control(self, parent, title, description, key, minimum, maximum):
        wrap = tk.Frame(parent, bg=C["panel"])
        wrap.pack(fill="x", anchor="w", pady=(6, 3))
        head = tk.Frame(wrap, bg=C["panel"])
        head.pack(fill="x")
        tk.Label(head, text=title, bg=C["panel"], fg=C["text"], font=self.fb).pack(side="left")
        value_var = tk.StringVar(value=f"{float(self.settings[key]):.1f}s")
        tk.Label(head, textvariable=value_var, bg=C["panel"], fg=C["title_lo"], font=self.fb).pack(side="right", padx=(8, 18))
        tk.Label(wrap, text=description, bg=C["panel"], fg=C["muted"], font=self.fs).pack(anchor="w", pady=(2, 0))
        scale = tk.Scale(
            wrap, from_=minimum, to=maximum, resolution=0.1, orient="horizontal",
            showvalue=False, length=520, width=12, sliderlength=20,
            bg=C["panel"], fg=C["text"], troughcolor=C["panel_lo"],
            activebackground=C["title_hi"], highlightthickness=0, bd=0,
            command=lambda raw: value_var.set(f"{float(raw):.1f}s"))
        scale.set(max(minimum, min(maximum, float(self.settings[key]))))
        scale.pack(anchor="w", fill="x", padx=(0, 18), pady=(0, 4))

        def save_value(_event=None):
            self.settings.set(key, round(float(scale.get()), 1))

        scale.bind("<ButtonRelease-1>", save_value)
        scale.bind("<KeyRelease>", save_value)

    def _mode_changed(self, key):
        self.settings.set("price_mode", key)
        self.rebuild()

    def _skip_changed(self, on):
        self.settings.set("list_skip_estimated", bool(on))

                                                                                           
    def _set_placeholder(self):
        if not self.filter_var.get():
            self.placeholder = True
            self.entry.configure(fg=C["muted"])
            self.entry.delete(0, "end")
            self.entry.insert(0, "Search furni by name or classname...")

    def _focus_in(self, _e):
        if self.placeholder:
            self.entry.delete(0, "end")
            self.entry.configure(fg=C["text"])
            self.placeholder = False

    def _filter_changed(self):
        if not self.placeholder:
            self.offset = 0
            self.rebuild()

                                                                                
    @property
    def mode(self) -> str:
        return self.settings["price_mode"]

    def _metric(self) -> str:
        return "current" if self.mode == "current" else "avg"

    def show(self):
        self.root.deiconify()
        self.root.lift()
        self.root.attributes("-topmost", True)
        self.root.after(300, lambda: self.root.attributes("-topmost", False))

    def _cols(self, width):
                                                                                        
        right = width - 14
        cols = {}
        for key, w in (("total", 130), ("current", 100), ("avg", 100), ("qty", 70)):
            if key == "current" and self.mode == "avg":
                continue
            if key == "avg" and self.mode == "current":
                continue
            cols[key] = right
            right -= w
        return cols, right

    def _cells(self, g: FurniGroup):
        st = g.price.state
        if st in ("pending", "loading"):
            dots = "." * (self.dots % 3 + 1)
            return {"avg": dots, "current": dots, "total": "loading" + dots}, C["muted"]
        if st == "ok":
            return {"avg": fmt_c(g.price.average), "current": fmt_c(g.price.current),
                    "total": fmt_c(g.total(self._metric()))}, C["text"]
        label = {"none": "no listings", "blocked": "not tradeable", "error": "unavailable"}[st]
        return {"avg": "-", "current": "-", "total": label}, C["warn"]

    def _sort_value(self, g: FurniGroup):
        c = self.sort_col
        if c == "name":
            return (g.name or "~").lower()
        if c == "qty":
            return g.quantity
        if c == "avg":
            return g.price.average if g.price.state == "ok" else -1
        if c == "current":
            return g.price.current if g.price.state == "ok" else -1
        total = g.total(self._metric())
        return -1 if total is None else total

                                                                                 
    def _paint_card(self):
        c = self.card
        c.delete("all")
        w = max(c.winfo_width(), 300)
        c.create_rectangle(0, 0, w - 1, 83, fill=C["outline"], outline=C["outline"])
        c.create_rectangle(1, 1, w - 2, 82, fill="#2b2b2b", outline="#2b2b2b")
        c.create_rectangle(1, 1, w - 2, 3, fill="#444444", outline="#444444")
              
        c.create_oval(16, 20, 62, 66, fill=C["coin_lo"], outline=C["outline"], width=2)
        c.create_oval(19, 20, 59, 60, fill=C["coin"], outline="#ffe066", width=2)
        c.create_text(39, 40, text="c", font=self.fbig, fill=C["coin_lo"])
        groups = list(self.manager.groups.values())
        metrics = ("avg", "current") if self.mode == "both" else (self._metric(),)
        label = {"avg": "MP AVG", "current": "Current"}
        x = 80
        for m in metrics:
            total = sum(g.total(m) or 0 for g in groups)
            c.create_text(x, 24, text=f"Total value ({label[m]})", anchor="w", font=self.fs, fill="#bdbdbd")
            c.create_text(x, 50, text=fmt_c(total), anchor="w", font=self.fbig, fill="#ffffff")
            x += 300
        unvalued_types = unvalued_pieces = 0
        for g in groups:
            if g.unit(self._metric()) is None:
                unvalued_types += 1
                unvalued_pieces += g.quantity
        loading = any(g.price.state in ("pending", "loading") for g in groups)
        if not groups:
            note, colour = "", "#bdbdbd"
        elif unvalued_types:
            note = (f"{unvalued_types} furni type(s) / {unvalued_pieces} item(s) could not be valued "
                    f"and are excluded" + (" (still loading)" if loading else ""))
            colour = "#ffb347"
        else:
            note, colour = "All furniture valued", "#8be36b"
        c.create_text(80, 72, text=note, anchor="w", font=self.fs, fill=colour)
        pieces = sum(g.quantity for g in groups)
        c.create_text(w - 16, 24, text=f"{len(groups)} types", anchor="e", font=self.fb, fill="#ffffff")
        c.create_text(w - 16, 46, text=f"{pieces} items", anchor="e", font=self.fs, fill="#bdbdbd")

    def _paint_head(self):
        h = self.head
        h.delete("all")
        w = max(self.list.winfo_width(), 300)
        cols, name_right = self._cols(w)
        h.create_rectangle(0, 0, w, HEAD_H, fill=C["head"], outline=C["head"])
        h.create_rectangle(0, HEAD_H - 2, w, HEAD_H, fill=C["panel_lo"], outline=C["panel_lo"])
        titles = {"name": "Furniture", "qty": "Qty", "avg": "MP AVG", "current": "Current", "total": "Total value"}
        self._head_zones = []
        for key, text in titles.items():
            if key == "name":
                x0, x1, anchor, tx = 0, name_right, "w", 58
            elif key in cols:
                x1 = cols[key]
                x0 = x1 - (70 if key == "qty" else 130 if key == "total" else 100)
                anchor, tx = "e", x1
            else:
                continue
            arrow = (" ▼" if self.sort_desc else " ▲") if key == self.sort_col else ""
            h.create_text(tx, HEAD_H // 2, text=text + arrow, anchor=anchor, font=self.fb, fill=C["text"])
            self._head_zones.append((x0, x1, key))

    def _head_click(self, e):
        for x0, x1, key in getattr(self, "_head_zones", []):
            if x0 <= e.x <= x1:
                self.sort_desc = (not self.sort_desc) if key == self.sort_col else (key != "name")
                self.sort_col = key
                self.rebuild()
                return

    def _redraw(self):
        c = self.list
        c.delete("all")
        w, h = max(c.winfo_width(), 300), max(c.winfo_height(), 50)
        self._clamp(h)
        cols, name_right = self._cols(w)
        first = int(self.offset // ROW_H)
        last = min(len(self.rows), int((self.offset + h) // ROW_H) + 1)
        for i in range(first, last):
            g = self.rows[i]
            y = i * ROW_H - self.offset
            fill = C["row_hover"] if i == self.hover_row else (C["row_a"] if i % 2 == 0 else C["row_b"])
            c.create_rectangle(0, y, w, y + ROW_H, fill=fill, outline=fill)
            c.create_rectangle(0, y + ROW_H - 1, w, y + ROW_H, fill="#d4d4d4", outline="#d4d4d4")
            tile = tile_colour(g.classname or g.name)
            c.create_rectangle(10, y + 5, 46, y + 37, fill=C["outline"], outline=C["outline"])
            c.create_rectangle(11, y + 6, 45, y + 36, fill=tile, outline=tile)
            c.create_rectangle(11, y + 6, 45, y + 10, fill="#ffffff", outline="#ffffff", stipple="gray50")
            c.create_text(28, y + 21, text=(g.name or "?")[:1].upper(), font=self.fb, fill="#333333")
            cells, colour = self._cells(g)
            c.create_text(58, y + 15, text=self._clip(g.name or f"(unknown #{g.key[1]})", name_right - 66),
                          anchor="w", font=self.fb, fill=C["text"])
            c.create_text(58, y + 30, text=self._clip(g.classname or "-", name_right - 66), anchor="w",
                          font=self.fs, fill=C["muted"])
            c.create_text(cols["qty"], y + ROW_H // 2, text=f"x{g.quantity}", anchor="e", font=self.fb, fill=C["text"])
            for key in ("avg", "current"):
                if key in cols:
                    c.create_text(cols[key], y + ROW_H // 2, text=cells[key], anchor="e", font=self.f, fill=colour)
            total_colour = C["good"] if g.price.state == "ok" else colour
            c.create_text(cols["total"], y + ROW_H // 2, text=cells["total"], anchor="e", font=self.fb, fill=total_colour)
        if not self.rows:
            msg = ("Loading inventory..." if self.manager.inventory_loading
                   else "No furniture to show. Type :inv in a room to load your inventory.")
            c.create_text(w // 2, 60, text=msg, font=self.f, fill=C["muted"])
        self._paint_head()
        self._paint_sbar()

    def _clip(self, text, width):
        if self.f.measure(text) <= width:
            return text
        while text and self.f.measure(text + "...") > width:
            text = text[:-1]
        return text + "..."

    def _paint_sbar(self):
        s = self.sbar
        s.delete("all")
        h = max(s.winfo_height(), 20)
        total = len(self.rows) * ROW_H
        view = max(self.list.winfo_height(), 1)
        s.create_rectangle(0, 0, 16, h, fill="#b9b9b9", outline="#b9b9b9")
        if total <= view:
            return
        thumb = max(30, int(h * view / total))
        y = int((h - thumb) * (self.offset / (total - view)))
        s.create_rectangle(1, y, 15, y + thumb, fill=C["outline"], outline=C["outline"])
        s.create_rectangle(2, y + 1, 14, y + thumb - 1, fill="#5fae2e", outline="#5fae2e")
        s.create_rectangle(2, y + 1, 14, y + 4, fill="#9be05a", outline="#9be05a")
        s.create_rectangle(2, y + thumb - 4, 14, y + thumb - 1, fill="#3b7a19", outline="#3b7a19")
        self._thumb = (y, thumb)

    def _clamp(self, view=None):
        view = view or max(self.list.winfo_height(), 1)
        self.offset = max(0, min(self.offset, max(0, len(self.rows) * ROW_H - view)))

    def _scroll(self, delta):
        self.offset += delta
        self._redraw()

    def _wheel(self, e):
        self._scroll(-int(e.delta / 120 * ROW_H * 2) if abs(e.delta) >= 120 else -int(e.delta * ROW_H))

    def _sb_press(self, e):
        self._sb_start = (e.y, self.offset)
        y, th = getattr(self, "_thumb", (0, 0))
        if not (y <= e.y <= y + th):
            self._sb_drag(e, jump=True)

    def _sb_drag(self, e, jump=False):
        total = len(self.rows) * ROW_H
        view = max(self.list.winfo_height(), 1)
        h = max(self.sbar.winfo_height(), 1)
        if total <= view:
            return
        thumb = max(30, int(h * view / total))
        if jump:
            frac = (e.y - thumb / 2) / max(h - thumb, 1)
            self.offset = frac * (total - view)
        else:
            start_y, start_off = self._sb_start
            self.offset = start_off + (e.y - start_y) * (total - view) / max(h - thumb, 1)
        self._redraw()

                                                                                              
    def rebuild(self):
        needle = "" if self.placeholder else self.filter_var.get().strip().lower()
        rows = [g for g in self.manager.groups.values()
                if not needle or needle in g.name.lower() or needle in g.classname.lower()]
        rows.sort(key=self._sort_value, reverse=self.sort_desc)
        self.rows = rows
        self.update_summary()
        self._paint_card()
        self._redraw()

    def refresh_values(self):
        self.update_summary()
        self._paint_card()
        self._redraw()

    def _tick(self):
        self.dots += 1
        if any(g.price.state in ("pending", "loading") for g in self.manager.groups.values()):
            self._redraw()
        self.root.after(450, self._tick)

    def update_summary(self):
        groups = list(self.manager.groups.values())
        done = sum(1 for g in groups if g.price.state not in ("pending", "loading"))
        self.prog = (done, max(len(groups), 1))
        self._paint_progress()
        lister = self.manager.lister
        if lister.running or (lister.status and lister.done):
            self.status_var.set(lister.status)
        elif self.manager.inventory_loading:
            self.status_var.set("Loading inventory...")
        elif groups:
            busy = len(groups) - done
            self.status_var.set(f"Pricing {done}/{len(groups)}..." if busy else "Prices complete")

    def _paint_progress(self):
        p = self.progress
        p.delete("all")
        done, total = self.prog
        p.create_rectangle(0, 0, 219, 17, fill=C["outline"], outline=C["outline"])
        p.create_rectangle(1, 1, 218, 16, fill="#444444", outline="#444444")
        segs = 20
        filled = int(segs * done / total)
        for i in range(segs):
            x = 3 + i * 10.4
            colour = "#7fd63f" if i < filled else "#5a5a5a"
            p.create_rectangle(x, 3, x + 8.6, 14, fill=colour, outline=colour)

                                                                                      
    def _hover(self, e):
        idx = int((e.y + self.offset) // ROW_H)
        if idx != self.hover_row:
            self.hover_row = idx if 0 <= idx < len(self.rows) else -1
            self._redraw()
            self._hide_tip()
        if self.hover_row >= 0:
            if self.tip is None:
                self._show_tip(self.rows[self.hover_row], e)
            else:
                self.tip.geometry(f"+{e.x_root + 18}+{e.y_root + 14}")

    def _leave(self):
        self.hover_row = -1
        self._hide_tip()
        self._redraw()

    def _tip_text(self, g: FurniGroup) -> str:
        lines = [f"Furniture: {g.name or '(unknown)'}", f"Quantity: {g.quantity}"]
        if g.price.state != "ok":
            lines += ["", g.price.message or "Price not available yet"]
            return "\n".join(lines)
        if self.mode in ("avg", "both"):
            a = g.price.average
            lines += [f"Average price: {fmt_c(a)}", "", "Calculation:", f"{fmt_c(a)} x {g.quantity} = {fmt_c(a * g.quantity)}"]
        if self.mode in ("current", "both"):
            cur = g.price.current
            if self.mode == "both":
                lines.append("")
            lines += [f"Current (cheapest) price: {fmt_c(cur)}", "", "Calculation:",
                      f"{fmt_c(cur)} x {g.quantity} = {fmt_c(cur * g.quantity)}"]
        lines += ["", f"Active listings: {g.price.listings}"]
        if g.price.message:
            lines += [g.price.message]
        return "\n".join(lines)

    def _show_tip(self, g, e):
        tip = tk.Toplevel(self.root)
        tip.overrideredirect(True)
        tip.attributes("-topmost", True)
        tip.configure(bg="#ffffff")
        tk.Label(tip, text=self._tip_text(g), justify="left", bg=C["tip_bg"], fg=C["tip_fg"], font=self.f,
                 padx=12, pady=9).pack(padx=1, pady=1)
        tip.geometry(f"+{e.x_root + 18}+{e.y_root + 14}")
        tip.lift()
        self.tip = tip

    def _hide_tip(self):
        if self.tip is not None:
            self.tip.destroy()
            self.tip = None

                                                                                
    def _dialog(self, title, text, buttons):
        self._hide_tip()
        HabboDialog(self.root, title, text, buttons, (self.f, self.fb))

    def list_all(self):
        lister = self.manager.lister
        if lister.running:
            lister.stop()
            self.list_btn.configure_button(text="Stopping...", enabled=False)
            return
        if self.manager.inventory_loading or any(g.price.state in ("pending", "loading")
                                                 for g in self.manager.groups.values()):
            self._dialog("Please wait", "Prices are still loading. Try again when pricing is complete.",
                         [("OK", "blue", None)])
            return
        jobs, skipped = self.manager.listing_plan()
        if not jobs:
            self._dialog("Nothing to list", "No items have a usable MP AVG price.\n\n"
                         f"No price: {skipped['no_price']}\nEstimated average only: {skipped['estimated']}\n"
                         f"Not tradeable: {skipped['not_tradeable']}", [("OK", "blue", None)])
            return
        total = sum(j.price for j in jobs)
        interval = float(self.settings["list_interval"])
        text = (f"List {len(jobs)} items on the Marketplace at their MP AVG?\n\n"
                f"Total asking price: {total:,}c\n"
                f"Takes about {int(len(jobs) * (interval + 0.5))} seconds, one item at a time.\n\n"
                f"Skipped: {skipped['not_tradeable']} not tradeable, {skipped['no_price']} without a price, "
                f"{skipped['estimated']} with only an estimated average, {skipped['zero']} priced under 1c.\n\n"
                "Listing stops at the first error. Cancel offers in the Marketplace window if you change your mind.")
        self._dialog("Confirm listing", text, [("List them", "green", lambda: lister.start(jobs)),
                                               ("Cancel", "grey", None)])

    def update_listing(self):
        lister = self.manager.lister
        if lister.running:
            self.list_btn.configure_button(text="Stop listing", theme="red", enabled=True)
        else:
            self.list_btn.configure_button(text="List all at MP AVG", theme="green", enabled=True)
        if lister.status:
            self.status_var.set(lister.status)
        if not lister.running and lister.done:
            self.manager.request_inventory()

                                                                                        
             
                                                                                        
def main() -> int:
                                                                           

                                                                                 
                                                                                    
                                          
       
    root = None
    ext = None
    startup_log("========== MyFurni process started ==========")
    startup_log(f"Python={sys.version.split()[0]} executable={sys.executable}")
    startup_log(f"Script directory={BASE_DIR}")
    startup_log(f"Arguments={sys.argv!r}")

    try:
        sys.path.insert(0, str(BASE_DIR))
        startup_log("Creating G-Python Extension object")
        ext = Extension(EXTENSION_INFO, sys.argv, {"use_click_trigger": True}, silent=True)

                                                                               
                                                                             
                                                                        
        ext.on_event("init", lambda: startup_log("G-Earth extension socket initialized (extension registered)"))
        ext.on_event("connection_end", lambda: startup_log("Habbo connection_end event received"))
        startup_log("G-Python extension object created; lifecycle diagnostics registered")

        ui_queue: "queue.Queue[Callable]" = queue.Queue()
        root = tk.Tk()
        root.withdraw()                                    
        startup_log("Tk root created and hidden")

        settings = Settings()
        startup_log(f"Settings loaded from {CONFIG_PATH}")
        manager = MyFurniManager(ext, settings, ui_queue.put)
        startup_log("MyFurniManager created; packet interceptors and worker services registered")

                                                                                   
                                                                                  
        startup_log("Calling ext.start()")
        ext.start()
        startup_log("ext.start() returned")

        manager.ui = InventoryWindow(root, manager)
        startup_log("Inventory UI constructed successfully")

        def pump():
            try:
                while True:
                    ui_queue.get_nowait()()
            except queue.Empty:
                pass
            except Exception:
                startup_log("Exception while processing a queued UI update", exc_info=True)
            try:
                if ext.is_closed():
                    startup_log("G-Python reports the G-Earth socket is closed; shutting down Tk")
                    root.destroy()
                    return
            except Exception:
                startup_log("Exception while checking extension socket state", exc_info=True)
            root.after(100, pump)

        startup_log("Entering Tk main loop")
        pump()
        root.mainloop()
        startup_log("Tk main loop exited; extension process is ending")
        return 0

    except BaseException:
        startup_log("FATAL STARTUP/RUNTIME FAILURE", exc_info=True)
        if root is not None:
            try:
                root.destroy()
            except Exception:
                pass
        return 1


if __name__ == "__main__":
    sys.exit(main())
