const { Extension, HDirection, HPacket } = require('gnode-api');
const fetch = require('node-fetch');

let extensionInfo = require('./package.json');
extensionInfo.name = 'Private Profile Fixer';

const ext = new Extension(extensionInfo);
let hotel = "www.habbo.com";
ext.run();

ext.interceptByNameOrHash(HDirection.TOCLIENT, 'ExtendedProfile', onExtendedProfile);

ext.on('connect', (host, connectionPort, hotelVersion, clientIdentifier, clientType) => {
    switch(host) {
        case "game-nl.habbo.com":
            hotel = "www.habbo.nl";
            break;
        case "game-br.habbo.com":
            hotel = "www.habbo.com.br";
            break;
        case "game-tr.habbo.com":
            hotel = "www.habbo.com.tr";
            break;
        case "game-de.habbo.com":
            hotel = "www.habbo.de";
            break;
        case "game-fr.habbo.com":
            hotel = "www.habbo.fr";
            break;
        case "game-fi.habbo.com":
            hotel = "www.habbo.fi";
            break;
        case "game-es.habbo.com":
            hotel = "www.habbo.es";
            break;
        case "game-it.habbo.com":
            hotel = "www.habbo.it";
            break;
        case "game-s2.habbo.com":
            hotel = "sandbox.habbo.com";
            break;
        default:
            hotel = "www.habbo.com";
            break;
    }
});

function onExtendedProfile(hMessage) {
    const packet = hMessage.getPacket();
    const base = packet.read('iSSSSiiBBBi');
    console.log(base);
    if (base[5] === 0 && base[6] === -1) {
        fetch(`https://${hotel}/api/public/users?name=${base[1]}`)
            .then(res => res.json())
            .then(userJson => {
                let user = {
                    id: base[0],
                    name: base[1],
                    figureString: base[2],
                    motto: base[3],
                    memberSince: base[4]
                };

                if(!('error' in userJson)) {
                    user.memberSince = userJson.memberSince.substring(0, 10).split('-').reverse().join('-');
                    user.motto = userJson.motto;
                }

                let packet = new HPacket('ExtendedProfile', HDirection.TOCLIENT)
                    .appendInt(user.id)
                    .appendString(user.name)
                    .appendString(user.figureString)
                    .appendString(user.motto)
                    .appendString(user.memberSince)
                    .appendInt(0)
                    .appendInt(0)
                    .appendBoolean(base[7])
                    .appendBoolean(base[8])
                    .appendBoolean(base[9])
                    .appendInt(0)
                    .appendInt(-1)
                    .appendBoolean(true);
                ext.sendToClient(packet);
            });
    }
}
