import os
import sys
import json
from g_python.gextension import Extension
from g_python.hpacket import HPacket
from g_python.hmessage import Direction, HMessage
from time import sleep, time
import threading
from threading import Timer
from PyQt5 import QtWidgets, uic
from PyQt5.QtWidgets import (QApplication, QWidget)


extension_info = {
    "title": "HandItem Chooser",
    "description": "Automatically pick the desired items from a furni.",
    "author": "denio4321",
    "version": "0.1"
}

extension_settings = {
    "use_click_trigger": True,
    "can_leave": True,
    "can_delete": True
}

ext = Extension(extension_info, args=sys.argv, extension_settings=extension_settings)

ext.start()

exit_event = threading.Event()


class HanditemChooser:
    def __init__(self):
        self.active = False
        self.selected_item = list()
        ext.send_to_server(HPacket('AvatarExpression', 0))
        ext.intercept(Direction.TO_CLIENT, self.get_user_index, 'Expression')
        ext.intercept(Direction.TO_SERVER, self.request_user_index, 'GetHeightMap')
        ext.intercept(Direction.TO_CLIENT, self.check_item, 'CarryObject', mode="async")
        ext.intercept(Direction.TO_SERVER, self.get_furni, 'UseFurniture')

    def get_user_index(self, message: HMessage):
        (index, expression) = message.packet.read('ii')
        if expression == 0:
            self.user_index = index

    def request_user_index(self, message: HMessage):
        ext.send_to_server(HPacket('AvatarExpression', 0))

    def add_item(self):
        item = QtWidgets.QListWidgetItem(window.item_selected.currentText())
        if int(window.item_selected.currentText().split(':')[1]) in self.selected_item: return
        window.selected_item_list.addItem(item)
        for i in range(window.selected_item_list.count()):
            if int(window.selected_item_list.item(i).text().split(':')[1]) not in self.selected_item:
                self.selected_item.append(int(window.selected_item_list.item(i).text().split(':')[1]))

    def remove_item(self):
        list_items = window.selected_item_list.selectedItems()
        if not list_items: return
        for item in list_items:
            self.selected_item.remove(int(item.text().split(':')[1]))
            window.selected_item_list.takeItem(window.selected_item_list.row(item))

    def start(self):
        exit_event.clear()
        self.starting_time = time()
        self.active = True
        self.task = threading.Thread(target=self.loop)
        self.task.daemon = True
        self.task.start()

    def loop(self):
        while self.active == True:
            ext.send_to_server(HPacket('UseFurniture', self.furni_id, 0))
            sleep(1.5)
            if exit_event.is_set():
                break

    def check_item(self, message: HMessage):
        (index, handitem) = message.packet.read('ii')
        if self.selected_item != None:
            if index == self.user_index:
                if handitem in self.selected_item:
                    exit_event.set()
                    self.active = False
                    self.end_time = time()
                    elapsed_seconds = self.end_time - self.starting_time
                    ext.send_to_client(
                        HPacket('Whisper', -1, "Completed in: {} seconds".format(int(elapsed_seconds)), 0, 30, 0, -1))

    def get_furni(self, message: HMessage):
        self.furni_id = message.packet.read_int()

    def stop(self):
        exit_event.set()
        if self.active == True:
            elapsed_seconds = self.end_time - self.starting_time
            self.end_time = time()
            ext.send_to_client(
                HPacket('Whisper', -1, "Exited, time executed: {} seconds".format(int(elapsed_seconds)), 0, 30, 0, -1))
        self.active = False


class Ui(QWidget):
    def __init__(self):
        super(Ui, self).__init__()
        uic.loadUi('main.ui', self)
        self.load_language_btn.clicked.connect(self.translate_ui)
        self.start_btn.clicked.connect(handitem_chooser.start)
        self.add_btn.clicked.connect(handitem_chooser.add_item)
        self.remove_btn.clicked.connect(handitem_chooser.remove_item)
        self.stop_btn.clicked.connect(handitem_chooser.stop)

    def translate_ui(self):
        self.item_selected.clear()
        if self.language_selector.currentText() == "English":
            with open('langs/com.json', 'r') as f:
                conf = json.load(f)
                self.start_btn.setText(conf['ui']['start'])
                self.load_language_btn.setText(conf['ui']['language'])
                self.note.setText(conf['ui']['notes'])
                self.language_label.setText(conf['ui']['language_label'])
                self.select_item_label.setText(conf['ui']['select_item'])
                self.stop_btn.setText(conf['ui']['stop_btn'])
                self.add_btn.setText(conf['ui']['add'])
                self.remove_btn.setText(conf['ui']['remove'])
                item_list = list()
                for items in conf['items']:
                    for key in items:
                        item_list.append(items[key] + ":" + key)
                item_list.sort()
                for item in item_list:
                    self.item_selected.addItem(item)
        elif self.language_selector.currentText() == "Español":
            with open('langs/es.json', 'r') as f:
                conf = json.load(f)
                self.start_btn.setText(conf['ui']['start'])
                self.load_language_btn.setText(conf['ui']['language'])
                self.note.setText(conf['ui']['notes'])
                self.language_label.setText(conf['ui']['language_label'])
                self.select_item_label.setText(conf['ui']['select_item'])
                self.stop_btn.setText(conf['ui']['stop_btn'])
                self.add_btn.setText(conf['ui']['add'])
                self.remove_btn.setText(conf['ui']['remove'])
                item_list = list()
                for items in conf['items']:
                    for key in items:
                        item_list.append(items[key] + ":" + key)
                item_list.sort()
                for item in item_list:
                    self.item_selected.addItem(item)
        elif self.language_selector.currentText() == "Português":
            with open('langs/com.br.json', 'r') as f:
                conf = json.load(f)
                self.start_btn.setText(conf['ui']['start'])
                self.load_language_btn.setText(conf['ui']['language'])
                self.note.setText(conf['ui']['notes'])
                self.language_label.setText(conf['ui']['language_label'])
                self.select_item_label.setText(conf['ui']['select_item'])
                self.stop_btn.setText(conf['ui']['stop_btn'])
                self.add_btn.setText(conf['ui']['add'])
                self.remove_btn.setText(conf['ui']['remove'])
                item_list = list()
                for items in conf['items']:
                    for key in items:
                        item_list.append(items[key] + ":" + key)
                item_list.sort()
                for item in item_list:
                    self.item_selected.addItem(item)

    def closeEvent(self, event):
        if event.spontaneous():
            # Ignore close and hide if triggered by close button
            event.ignore()
            self.hide()
        else:
            # Close if triggered by calling close()
            event.accept()
            # Stop entire program
            os._exit(0)

if __name__ == '__main__':
    handitem_chooser = HanditemChooser()

    app = QApplication(sys.argv)

    window = Ui()
    # Window has to be shown when .exec() iscalled
    window.show()
    ext.on_event('double_click', window.show)  # Show window on click in G-Earth


    # Check if extension is still connected to G-Earth every second
    def checkExtensionActive():
        if ext.is_closed():
            # Close window and stop if extension isn't connected
            window.close()

        # Repeat every second
        Timer(1.0, checkExtensionActive).start()


    checkExtensionActive()

    # Hide window after .exec() is called
    Timer(0.1, window.hide).start()
    sys.exit(app.exec())
