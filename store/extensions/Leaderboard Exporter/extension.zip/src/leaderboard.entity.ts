export type Leaderboard = {
  iconSrc: string,
  id: number,
  scoreType: string,
  clearType: string,
  scores: any[]
}