# Habbo Scanner: A Brief Overview 🎮

Welcome to Habbo Scanner, a powerful data archiving tool for Habbo. This G-Earth extension is designed to extract and store a wealth of information from Habbo, providing a comprehensive database for users. 

Please note that Habbo Scanner is intended for educational purposes only. Any misuse of this tool for illegal activities is strictly prohibited. By using this tool, you agree to abide by all applicable laws and regulations.

## What is Habbo Scanner? 🕵️‍♂️

Habbo Scanner is a tool that extracts data from Habbo and saves it to a MySQL database. It archives details about furni, users, pets, and bots seen in Habbo rooms, creating a rich dataset for analysis and insight.

## Key Features 🚀

- **Data Extraction and Storage**: Catalogs every piece of furni, bots, and pets in rooms and stores the information in a MySQL database.
- **Bot Mode**: The bot mode allows the character to automatically rotate rooms in various modes, collecting data as it goes.
- **Command System**: Users can control the extension's behavior directly from the logic.game.
- **Discord Integration**: Habbo Scanner allows remote command execution via Discord.

## Prerequisites for Configuration ⚙️

Before you start, make sure you have the following:

- Java installed on your machine.
- G-Earth installed on your machine.
- MySQL installed and properly configured.

For detailed configuration instructions, please refer to the [Configuration Guide](https://github.com/slogga-dev/Habbo-Scanner/wiki/Dev-Environment-Configuration-Guide-%F0%9F%9B%A0%EF%B8%8F).

## Contributing to the Project 🤝

Habbo Scanner is an open project and we welcome contributions! If you have ideas for improvements or new features, you can contribute by sending pull requests. If you're not sure where to start, you can join our Discord server through the following [link](https://discord.gg/dpEPGKvD6f). Our community is always ready to help you get started on your contribution journey.

## Credits 🏆

Habbo Scanner was born from the idea of dha, who wanted to keep track of his furni in Habbo. The project then took on a life of its own and was developed by Jason, shokato and .Lenin, with valuable feedback from ,Homy and Dolce95. We thank them for their contributions to this project.
