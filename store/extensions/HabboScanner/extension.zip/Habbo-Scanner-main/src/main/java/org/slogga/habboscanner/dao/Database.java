package org.slogga.habboscanner.dao;

import java.sql.Connection;
import java.sql.SQLException;

import java.util.Optional;
import java.util.Properties;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

import org.slogga.habboscanner.HabboScanner;

public class Database {
    private static Database instance;

    public static Database getInstance() {
        return Optional.ofNullable(instance).orElseGet(() -> {
            instance = new Database();

            return instance;
        });
    }

    private final HikariDataSource dataSource;

    private Database() {
        Properties properties = HabboScanner.getInstance().getConfigurator().getProperties().get("mysql");

        String database = properties.getProperty("database");
        String user = properties.getProperty("user");
        String password = properties.getProperty("password");

        HikariConfig config = new HikariConfig();

        config.setJdbcUrl(String.format("jdbc:mysql://localhost:3306/%s?rewriteBatchedStatements=true", database));
        config.setUsername(user);
        config.setPassword(password);

        config.setDriverClassName("com.mysql.cj.jdbc.Driver");

        dataSource = new HikariDataSource(config);
    }

    public Connection getConnection() throws SQLException {
        return dataSource.getConnection();
    }
}
