package org.slogga.habboscanner.logic.commands;

public interface Command {
    void execute(CommandExecutorProperties properties);

    String getDescription();
}
