package org.slogga.habboscanner.logic.commands.common.start;

import java.util.List;
import java.util.Optional;
import java.util.Properties;
import java.util.stream.Collectors;

import lombok.Data;

import org.slogga.habboscanner.HabboScanner;

import org.slogga.habboscanner.logic.commands.Command;
import org.slogga.habboscanner.logic.commands.CommandExecutorProperties;
import org.slogga.habboscanner.logic.commands.CommandFactory;

import org.slogga.habboscanner.logic.commands.common.EnergySavingCommand;

import org.slogga.habboscanner.logic.game.console.commands.channel.ChannelConsoleCommand;
import org.slogga.habboscanner.models.enums.CommandKeys;
import org.slogga.habboscanner.models.enums.MessageChannel;

@Data
public class StartCommand implements Command {
    private boolean hasExecuted = false;
    private boolean isBotRunning = false;

    @Override
    public void execute(CommandExecutorProperties properties) {
        if (hasExecuted) return;

        hasExecuted = true;
        isBotRunning = true;

        HabboScanner.getInstance().getConfigurator().getRoomEntryHandlers().refreshLastRoomAccess();

        setupChannel();
        setupEnergySavingMode();

        Optional<String> enabledModeKeyOptional = Optional.ofNullable(getEnableModeKey(properties));

        enabledModeKeyOptional.ifPresent(enabledModeKey -> StartModeFactory.getStartModeStrategy(enabledModeKey)
                .execute(properties));
    }

    @Override
    public String getDescription() {
        return HabboScanner.getInstance().getConfigurator().getProperties().get("command_description")
                .getProperty("start.command.description");
    }

    private void setupChannel() {
        MessageChannel defaultChannel = MessageChannel.fromValue(HabboScanner.getInstance()
                .getConfigurator().getProperties().get("bot")
                .getProperty("bot.default.message.channel"));

        ChannelConsoleCommand channelConsoleCommand = (ChannelConsoleCommand) CommandFactory.getCommandExecutor()
                .getCommands().get(CommandKeys.CHANNEL.getKey());
        channelConsoleCommand.setChannel(Optional.ofNullable(channelConsoleCommand.getChannel()).orElse(defaultChannel));
    }

    private void setupEnergySavingMode() {
        boolean isEnergySavingModeEnabled = Boolean.parseBoolean(HabboScanner.getInstance()
                .getConfigurator().getProperties().get("bot").getProperty("bot.energy.saving.mode.enabled"));

        if (!isEnergySavingModeEnabled) return;

        EnergySavingCommand energySavingCommand = (EnergySavingCommand) CommandFactory.getCommandExecutor()
                .getCommands().get(CommandKeys.ENERGY_SAVING.getKey());
        energySavingCommand.setEnergySavingMode(true);
    }

    private String getEnableModeKey(CommandExecutorProperties properties) {
        Properties botProperties = HabboScanner.getInstance()
                .getConfigurator()
                .getProperties()
                .get("bot");

        List<String> enabledModeKeys = StartModeFactory.getStartModeKeys().stream()
                .filter(modeKey -> Boolean.parseBoolean(botProperties.getProperty(modeKey)))
                .collect(Collectors.toList());

        if (enabledModeKeys.size() != 1) {
            String impossibleStartBotMessage = HabboScanner.getInstance()
                    .getConfigurator()
                    .getProperties()
                    .get("message")
                    .getProperty("impossible.start.bot.message");

            CommandFactory.getCommandExecutor().sendMessage(impossibleStartBotMessage, properties);

            return null;
        }

        return enabledModeKeys.get(0);
    }
}
