package org.slogga.habboscanner.models.enums;

import lombok.Getter;

import java.util.Arrays;
import java.util.Objects;

@Getter
public enum IdOrder {
    ASC("asc"),
    DESC("desc"),
    RANDOM("random");

    public static IdOrder fromValue(String value) {
        return Arrays.stream(IdOrder.values())
                .filter(mode -> Objects.equals(mode.getOrder(), value))
                .findFirst()
                .orElse(null);
    }

    private final String order;

    IdOrder(String order) {
        this.order = order;
    }
}
