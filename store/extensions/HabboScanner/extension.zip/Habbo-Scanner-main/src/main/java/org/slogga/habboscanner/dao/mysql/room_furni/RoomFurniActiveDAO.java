package org.slogga.habboscanner.dao.mysql.room_furni;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slogga.habboscanner.dao.Database;

import org.slogga.habboscanner.models.furni.Furni;

public class RoomFurniActiveDAO {
    private static final Logger logger = LoggerFactory.getLogger(RoomFurniActiveDAO.class);

    public static void insertRoomFurniActive(Furni furni) {
        String query = "INSERT IGNORE INTO room_furni_active (id, classname, name, owner, type, " +
                "room_id, x, y, z, location, extradata, timestamp) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection connection = Database.getInstance().getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, furni.getId());
            statement.setString(2, furni.getClassname());
            statement.setString(3, furni.getName());
            statement.setString(4, furni.getOwner());
            statement.setString(5, furni.getType().getTypeName());
            statement.setInt(6, furni.getRoomId());
            statement.setInt(7, furni.getCoordinates().getX());
            statement.setInt(8, furni.getCoordinates().getY());
            statement.setDouble(9, furni.getCoordinates().getZ());
            statement.setString(10, furni.getLocation());
            statement.setString(11, furni.getExtradata());
            statement.setTimestamp(12, furni.getTimestamp());

            statement.execute();
        } catch (SQLException exception) {
            logger.error(exception.getMessage());
        }
    }

    public static void deleteRoomFurniActive(int roomId) {
        String query = "DELETE FROM room_furni_active WHERE room_id = ?";

        try (Connection connection = Database.getInstance().getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, roomId);
            statement.execute();
        } catch (SQLException exception) {
            logger.error(exception.getMessage());
        }
    }
}
