package org.slogga.habboscanner;

import java.util.Optional;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import lombok.Getter;
import lombok.Setter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import gearth.extensions.Extension;
import gearth.extensions.ExtensionInfo;

import org.slogga.habboscanner.logic.commands.CommandExecutorType;
import org.slogga.habboscanner.logic.commands.CommandFactory;
import org.slogga.habboscanner.logic.configurators.FurnidataConfigurator;
import org.slogga.habboscanner.logic.configurators.HabboScannerConfigurator;

import org.slogga.habboscanner.logic.discord.DiscordBot;

@Getter
@Setter
@ExtensionInfo(
        Title = "Habbo Scanner",
        Description = "Scan data all around Habbo!",
        Version = "3.0.0",
        Author = "slogga.it"
)
public class HabboScanner extends Extension {
    private static HabboScanner instance;

    private static final Logger logger = LoggerFactory.getLogger(HabboScanner.class);

    private final ScheduledExecutorService executorService = Executors.newSingleThreadScheduledExecutor();

    private final HabboScannerConfigurator configurator;
    private final FurnidataConfigurator furnidataConfigurator;

    private DiscordBot discordBot;

    private boolean criticalAirCrashWarning;

    public static void main(String[] args) {
        instance = new HabboScanner(args);
        instance.run();
    }

    public HabboScanner(String[] args) {
        super(args);

        configurator = new HabboScannerConfigurator();
        furnidataConfigurator = new FurnidataConfigurator();
    }

    public static HabboScanner getInstance() {
        return Optional.ofNullable(instance)
                .orElseThrow(() -> new IllegalStateException("HabboScanner instance has not yet been initialized."));
    }

    @Override
    protected void initExtension() {
        configurator.setupConfig();
        furnidataConfigurator.setupConfig();

        CommandFactory.getCommandExecutor(CommandExecutorType.CONSOLE, null);

        boolean isDiscordBotEnabled = Boolean.parseBoolean(configurator.getProperties()
                .get("discord").getProperty("discord.bot.enabled"));
        boolean isBotEnabled = Boolean.parseBoolean(configurator.getProperties()
                .get("bot").getProperty("bot.enabled"));

        Optional.of(isDiscordBotEnabled && isBotEnabled)
                .filter(Boolean::booleanValue)
                .ifPresent(enabled -> {
                    discordBot = new DiscordBot();

                    CommandFactory.getCommandExecutor(CommandExecutorType.DISCORD, null);
                });

        configurator.getNavigatorHandlers().scheduleOnlineStatisticsUpdate();
        scheduleAirCrashCheck();

        logger.info("Habbo Scanner has started.");
    }

    @Override
    protected void onEndConnection() {
        Optional.ofNullable(discordBot).ifPresent(bot -> {
            String botCrashMessage = configurator
                    .getProperties()
                    .get("message")
                    .getProperty("bot.crash.message");

            bot.getMessageHandler().sendMessageToFeedChannel(botCrashMessage);
        });

        executorService.schedule(() -> System.exit(0), 2, TimeUnit.SECONDS);
    }

    private void scheduleAirCrashCheck() {
        /*
            Time in milliseconds.
            400000 ms is approximately 6.67 minutes (400000 ms / 60000 ms/minutes).
        */
        final long accessTimeout = 400000;
        final String crashMessage = configurator.getProperties().get("message")
                .getProperty("bot.room.manager.crash.message");

        long lastRoomAccess = configurator.getRoomEntryHandlers().getLastRoomAccess();

        executorService.scheduleAtFixedRate(() -> {
            boolean isAccessRecent = lastRoomAccess > 0;
            boolean isTimeExceeded = (System.currentTimeMillis() - lastRoomAccess) > accessTimeout;

            if (criticalAirCrashWarning || !isAccessRecent || !isTimeExceeded) return;

            Optional.ofNullable(discordBot).ifPresent(bot ->
                    bot.getMessageHandler().sendMessageToFeedChannel(crashMessage));

            criticalAirCrashWarning = true;
        }, 0, 2, TimeUnit.MINUTES);
    }
}