package org.slogga.habboscanner.logic.game.entities;

import gearth.extensions.parsers.HEntity;

import java.util.Arrays;
import java.util.stream.Collectors;

import org.slogga.habboscanner.dao.mysql.entities.PetsDAO;

import org.slogga.habboscanner.models.habbo_entities.HabboPet;
import org.slogga.habboscanner.utils.UTF8Utils;

public class PetEntity extends BaseEntity {
    public PetEntity(HEntity entity, int roomId) {
        super(entity, roomId);
    }

    @Override
    public void processEntity() {
        Object[] rawExtradata = entity.getStuff();
        String extradata = Arrays.stream(rawExtradata)
                .map(Object::toString)
                .collect(Collectors.joining(", "));

        extradata = UTF8Utils.convertToUTF8(extradata);

        HabboPet pet = new HabboPet(entity.getId(), entity.getName());
        PetsDAO.insertPet(pet, roomId, extradata);
    }
}