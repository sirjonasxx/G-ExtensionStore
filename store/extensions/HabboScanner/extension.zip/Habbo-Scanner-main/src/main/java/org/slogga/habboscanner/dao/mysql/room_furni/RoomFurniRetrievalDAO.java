package org.slogga.habboscanner.dao.mysql.room_furni;

import java.sql.*;

import java.util.ArrayList;
import java.util.HashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slogga.habboscanner.dao.Database;

public class RoomFurniRetrievalDAO {
    private static final Logger logger = LoggerFactory.getLogger(RoomFurniRetrievalDAO.class);

    public static HashMap<String, Object> retrieveRoomFurni(int id, String type) {
        String query = "SELECT * FROM room_furni WHERE id = ? AND type = ? LIMIT 1";

        try (Connection connection = Database.getInstance().getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, id);
            statement.setString(2, type);

            try (ResultSet resultSet = statement.executeQuery()) {
                ResultSetMetaData resultSetMetaData = resultSet.getMetaData();

                int columnCount = resultSetMetaData.getColumnCount();

                HashMap<String, Object> row = new HashMap<>();

                if (!resultSet.next()) return null;

                for (int columnIndex = 1; columnIndex <= columnCount; columnIndex++) {
                    String columnName = resultSetMetaData.getColumnName(columnIndex);
                    Object columnValue = resultSet.getObject(columnIndex);

                    row.put(columnName, columnValue);
                }

                return row;
            }
        } catch (SQLException exception) {
            logger.error(exception.getMessage());
        }

        return null;
    }

    public static ArrayList<HashMap<String, Object>> retrieveRoomFurniHistory(int id, String type) {
        String query = "SELECT owner, timestamp from room_furni WHERE id IN " +
                "(SELECT id FROM room_furni WHERE (id,type) = (?,?)) ORDER BY timestamp DESC";

        try (Connection connection = Database.getInstance().getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, id);
            statement.setString(2, type);

            try (ResultSet resultSet = statement.executeQuery()) {
                ResultSetMetaData resultSetMetaData = resultSet.getMetaData();
                int columnCount = resultSetMetaData.getColumnCount();

                ArrayList<HashMap<String, Object>> result = new ArrayList<>();

                while (resultSet.next()) {
                    HashMap<String, Object> row = new HashMap<>();

                    for (int columnIndex = 1; columnIndex <= columnCount; columnIndex++) {
                        String columnName = resultSetMetaData.getColumnName(columnIndex);
                        Object columnValue = resultSet.getObject(columnIndex);

                        row.put(columnName, columnValue);
                    }

                    result.add(row);
                }

                return result;
            }
        } catch (SQLException exception) {
            logger.error(exception.getMessage());
        }

        return null;
    }
}
