package org.slogga.habboscanner.handlers;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import gearth.protocol.HMessage;
import gearth.protocol.HPacket;

import org.slogga.habboscanner.HabboScanner;

import org.slogga.habboscanner.dao.mysql.rooms.NavigatorRoomsDAO;
import org.slogga.habboscanner.dao.mysql.OnlineStatsDAO;

import org.slogga.habboscanner.logic.game.HabboActions;

import org.slogga.habboscanner.logic.commands.CommandFactory;
import org.slogga.habboscanner.logic.commands.common.follow.FollowCommand;
import org.slogga.habboscanner.logic.commands.common.start.StartCommand;

import org.slogga.habboscanner.models.enums.CommandKeys;
import org.slogga.habboscanner.models.enums.RoomAccessMode;

import org.slogga.habboscanner.models.room.NavigatorRoom;

import org.slogga.habboscanner.utils.DateUtils;

public class NavigatorHandlers {
    private static final long ROOM_VISIT_INTERVAL_IN_MILLISECONDS = 1000 * 60 * 5; // 5 minutes.

    private boolean onlineStatisticsInsertionEnabled;

    private final Map<Integer, Long> roomTimestamps = new HashMap<>();

    public void scheduleOnlineStatisticsUpdate() {
        ScheduledExecutorService executorService = Executors.newSingleThreadScheduledExecutor();
        executorService.scheduleAtFixedRate(() -> onlineStatisticsInsertionEnabled = true,
                0, 3, TimeUnit.MINUTES);
    }

    public void onNavigatorSearchResultBlocks(HMessage message) {
        StartCommand startCommand = (StartCommand) CommandFactory.getCommandExecutor()
                .getCommands().get(CommandKeys.START.getKey());
        if (!startCommand.isBotRunning()) return;

        HPacket packet = message.getPacket();

        String unknownMessage1 = packet.readString();
        String unknownMessage2 = packet.readString();
        int unknownMessage3 = packet.readInteger();
        String unknownMessage4 = packet.readString();
        String unknownMessage5 = packet.readString();
        int unknownMessage6 = packet.readInteger();
        int unknownMessage7 = packet.readInteger();
        boolean unknownMessage8 = packet.readBoolean();

        int roomsFoundAmount = packet.readInteger();
        int totalRoomUserAmount = 0;

        ArrayList<String> rooms = new ArrayList<>();

        for (int roomIndex = 1; roomIndex <= roomsFoundAmount; roomIndex++) {
            NavigatorRoom room = readRoomFromPacket(packet);
            totalRoomUserAmount += room.getUserAmount();

            if (room.getUserAmount() == 0) roomsFoundAmount--;

            if (shouldMoveToRoom(room))
                moveToRoom(room);

            rooms.add(room.toString());
        }

        boolean isStatisticsInsertionActive = Boolean.parseBoolean(HabboScanner.getInstance()
                .getConfigurator()
                .getProperties()
                .get("bot").getProperty("statistics.insertion.active"));

        if (!isStatisticsInsertionActive || !onlineStatisticsInsertionEnabled) return;

        updateStatistics(totalRoomUserAmount, roomsFoundAmount, rooms);
    }

    private NavigatorRoom readRoomFromPacket(HPacket packet) {
        int roomId = packet.readInteger();
        String roomName = packet.readString();

        int unknownMessage1 = packet.readInteger();
        String ownerName = packet.readString();

        int accessMode = packet.readInteger();
        int roomUserAmount = packet.readInteger();

        int maximumRoomUserAmount = packet.readInteger();
        String roomDescription = packet.readString();

        int unknownMessage2 = packet.readInteger();
        int unknownMessage3 = packet.readInteger();
        int unknownMessage4 = packet.readInteger();
        int unknownMessage5 = packet.readInteger();
        int tagAmount = packet.readInteger();

        if (tagAmount > 0) {
            String unknownMessage6 = packet.readString();

            if (tagAmount == 2) {
                String unknownMessage7 = packet.readString();
            }
        }

        int multiUse = packet.readInteger();

        if ((multiUse & 1) > 0) {
            String unknownMessage8 = packet.readString();
        }

        if ((multiUse & 2) > 0) {
            int unknownMessage9 = packet.readInteger();
            String unknownMessage10 = packet.readString();
            String unknownMessage11 = packet.readString();
        }

        if ((multiUse & 4) > 0) {
            String unknownMessage12 = packet.readString();
            String unknownMessage13 = packet.readString();
            int unknownMessage14 = packet.readInteger();
        }

        return new NavigatorRoom(roomId, roomName, roomDescription, ownerName,
                roomUserAmount, maximumRoomUserAmount, accessMode);
    }

    private boolean shouldMoveToRoom(NavigatorRoom room) {
        FollowCommand followCommand = (FollowCommand) CommandFactory.getCommandExecutor()
                .getCommands().get(CommandKeys.FOLLOW.getKey());

        long currentTime = System.currentTimeMillis();
        long lastRoomTime = roomTimestamps.getOrDefault(room.getId(), 0L);
        boolean isRoomOpen = room.getAccessMode() == RoomAccessMode.OPEN.getAccessMode();
        boolean isTimeForRoomVisit = currentTime - lastRoomTime > ROOM_VISIT_INTERVAL_IN_MILLISECONDS;

        return !followCommand.isFollowing() && isRoomOpen && isTimeForRoomVisit;
    }

    private void moveToRoom(NavigatorRoom room) {
        long currentTime = System.currentTimeMillis();
        roomTimestamps.put(room.getId(), currentTime);

        HabboActions.moveToRoom(room.getId());
    }

    private void updateStatistics(int totalRoomUserAmount, int roomsFoundAmount, ArrayList<String> rooms) {
        String currentDateTime = DateUtils.getCurrentDateTime();
        OnlineStatsDAO.insertOnlineStats(totalRoomUserAmount, roomsFoundAmount, currentDateTime);

        NavigatorRoomsDAO.deleteNavigatorRooms();
        NavigatorRoomsDAO.insertNavigatorRooms(rooms);

        onlineStatisticsInsertionEnabled = false;
    }
}
