package org.slogga.habboscanner.handlers.item;

import java.sql.Date;

import java.util.Arrays;

import gearth.extensions.parsers.HFloorItem;
import gearth.extensions.parsers.HWallItem;
import gearth.extensions.parsers.IFurni;

import gearth.protocol.HMessage;

import org.slogga.habboscanner.HabboScanner;

import org.slogga.habboscanner.handlers.GroupHandlers;
import org.slogga.habboscanner.handlers.room.RoomEntryHandlers;

import org.slogga.habboscanner.logic.commands.common.follow.FollowCommand;
import org.slogga.habboscanner.logic.commands.common.follow.FollowingActionFactory;

import org.slogga.habboscanner.logic.configurators.HabboScannerConfigurator;
import org.slogga.habboscanner.logic.game.HabboActions;
import org.slogga.habboscanner.logic.game.ItemProcessor;

import org.slogga.habboscanner.logic.commands.CommandFactory;

import org.slogga.habboscanner.logic.game.console.commands.FollowConsoleCommand;
import org.slogga.habboscanner.logic.game.furni.FurniInsightsAndTransactionExecutor;

import org.slogga.habboscanner.models.enums.CommandKeys;
import org.slogga.habboscanner.models.enums.FollowingAction;
import org.slogga.habboscanner.models.enums.FurnitypeEnum;

public class ItemProcessingHandlers {
    private final FurniInsightsAndTransactionExecutor furniInsightsAndTransactionExecutor = new FurniInsightsAndTransactionExecutor();

    public void onFloorItems(HMessage message) {
        HFloorItem[] items = HFloorItem.parse(message.getPacket());
        processItems(items, FurnitypeEnum.FLOOR);
    }

    public void onWallItems(HMessage message) {
        HWallItem[] items = HWallItem.parse(message.getPacket());
        processItems(items, FurnitypeEnum.WALL);

        handleBotActions();
        leaveGroupAndResetProcessingState();
    }

    public void processItems(IFurni[] items, FurnitypeEnum type) {
        RoomEntryHandlers roomEntryHandlers = HabboScanner.getInstance().getConfigurator().getRoomEntryHandlers();
        ItemProcessor itemProcessor = roomEntryHandlers.getItemProcessor();
        int roomId = roomEntryHandlers.getRoomId();

        Arrays.stream(items).forEach(item -> {
            switch (type) {
                case FLOOR: {
                    if (!(item instanceof HFloorItem)) return;
                    HFloorItem floorItem = (HFloorItem) item;

                    itemProcessor.processFloorItem(floorItem, FurnitypeEnum.FLOOR, roomId);

                    break;
                }

                case WALL: {
                    if (!(item instanceof HWallItem)) return;
                    HWallItem wallItem = (HWallItem) item;

                    itemProcessor.processWallItem(wallItem, FurnitypeEnum.WALL, roomId);
                }
            }
        });
    }

    public void executeTransactionsAndProvideInsights() {
        Date estimatedDate = HabboScanner.getInstance().getConfigurator().getRoomEntryHandlers()
                .getItemProcessor().estimateDateForOldestFurni();

        FollowConsoleCommand followConsoleCommand = (FollowConsoleCommand) CommandFactory.getCommandExecutor()
                .getCommands().get(CommandKeys.FOLLOW.getKey());

        if (estimatedDate == null) {
            followConsoleCommand.handleEmptyRoom();

            return;
        }

        furniInsightsAndTransactionExecutor.executeTransactionsAndProvideFurniInsights(estimatedDate);
    }

    private void handleBotActions() {
        boolean isBotEnabled = Boolean.parseBoolean(HabboScanner.getInstance().getConfigurator()
                .getProperties().get("bot").getProperty("bot.enabled"));

        if (!isBotEnabled) {
            executeTransactionsAndProvideInsights();

            return;
        }

        FollowCommand followCommand = (FollowCommand) CommandFactory.getCommandExecutor()
                .getCommands().get(CommandKeys.FOLLOW.getKey());

        if (!followCommand.isFollowing()) return;

        FollowingAction followingAction = followCommand.getFollowingAction();
        FollowingActionFactory.getFollowingActionStrategy(followingAction).execute();
    }

    private void leaveGroupAndResetProcessingState() {
        HabboScannerConfigurator configurator = HabboScanner.getInstance().getConfigurator();
        int botId = Integer.parseInt(configurator.getProperties().get("bot").getProperty("bot.id"));

        GroupHandlers groupHandlers = configurator.getGroupHandlers();
        if (!groupHandlers.isProcessingGroup()) return;

        HabboActions.leaveGroup(groupHandlers.getGroupId(), botId);
        groupHandlers.setProcessingGroup(false);
    }
}
