package org.slogga.habboscanner.logic.commands.common.convert.files;

import java.io.PrintWriter;

import org.slogga.habboscanner.logic.commands.CommandExecutorProperties;
import org.slogga.habboscanner.logic.commands.common.convert.Converter;

import org.slogga.habboscanner.models.enums.ConvertFile;
import org.slogga.habboscanner.models.enums.FurnitypeEnum;

public class ConvertItemsTimeline extends Converter {
    public void execute(CommandExecutorProperties properties) {
        super.execute(properties, ConvertFile.ITEMS_TIMELINE);
    }

    public void processLine(String line, String cvsSplitBy, PrintWriter printWriter, ConvertFile file) {
        String[] timeLine = line.split(cvsSplitBy, -1);

        processAndPrint(timeLine, 0, 1, FurnitypeEnum.FLOOR, printWriter, file);
        processAndPrint(timeLine, 4, 5, FurnitypeEnum.WALL, printWriter, file);
    }

    private void processAndPrint(String[] timeLine, int dateIndex, int idIndex,
                                 FurnitypeEnum furnitype, PrintWriter printWriter, ConvertFile file) {
        String date = processField(timeLine, dateIndex);
        String id = processField(timeLine, idIndex);

        if (date.equals("NULL") || id.equals("NULL") || id.isEmpty()) return;

        printWriter.println(String.format("INSERT INTO %s (date, id, type) VALUES (%s, %s, '%s');",
                file.getFileName(), date, id, furnitype.getTypeName()));
    }
}
