package org.slogga.habboscanner.logic.commands.common.convert;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.function.Supplier;

import org.slogga.habboscanner.logic.commands.common.convert.files.*;

import org.slogga.habboscanner.models.enums.ConvertFile;

public class ConvertFileFactory {
    private static final Map<ConvertFile, Supplier<Converter>> fileMap = new HashMap<>();

    static {
        fileMap.put(ConvertFile.ITEMS, ConvertItems::new);
        fileMap.put(ConvertFile.ITEMS_TIMELINE, ConvertItemsTimeline::new);
    }

    public static Converter getFollowingActionStrategy(ConvertFile file) {
        Supplier<Converter> fileSupplier = fileMap.get(file);

        return Optional.ofNullable(fileSupplier)
                .map(Supplier::get)
                .orElse(null);
    }
}
