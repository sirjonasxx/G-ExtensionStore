package org.slogga.habboscanner.dao.mysql.entities.habbo_users;

import java.sql.*;
import java.util.*;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slogga.habboscanner.dao.Database;
import org.slogga.habboscanner.models.habbo_entities.HabboUser;

public class HabboUsersDAO {
    private static final Logger logger = LoggerFactory.getLogger(HabboUsersDAO.class);

    public static ArrayList<HashMap<String, Object>> getUserById(int id) {
        String query = "SELECT * FROM habbo_users WHERE id = ?";

        try (Connection connection = Database.getInstance().getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, id);

            try (ResultSet resultSet = statement.executeQuery()) {
                ResultSetMetaData resultSetMetaData = resultSet.getMetaData();
                int columnCount = resultSetMetaData.getColumnCount();

                ArrayList<HashMap<String, Object>> result = new ArrayList<>();

                while (resultSet.next()) {
                    HashMap<String, Object> row = new HashMap<>();

                    for (int columnIndex = 1; columnIndex <= columnCount; columnIndex++) {
                        String columnName = resultSetMetaData.getColumnName(columnIndex);
                        Object columnValue = resultSet.getObject(columnIndex);

                        row.put(columnName, columnValue);
                    }

                    result.add(row);
                }

                return result;
            }
        } catch (SQLException exception) {
            logger.error(exception.getMessage());
        }

        return null;
    }

    public static void insertUser(HabboUser user, int roomId) {
        String query = "INSERT INTO `habbo_users` (`id`, `name`, `motto`, `gender`, " +
                "`look`, `seen_times`, `room_id`) VALUES (?, ?, ?, ?, ?, 0, ?)";

        try (Connection connection = Database.getInstance().getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, user.getId());
            statement.setString(2, user.getName());
            statement.setString(3, user.getMotto());
            statement.setString(4, user.getGender());
            statement.setString(5, user.getLook());
            statement.setInt(6, roomId);

            statement.execute();
        } catch (SQLException exception) {
            logger.error(exception.getMessage());
        }
    }

    public static void updateUser(HabboUser user, int seenTimes, int roomId) {
        String query = "UPDATE `habbo_users` SET `name` = ?, `motto` = ?, `gender` = ?, " +
                "`look` = ?, `seen_times` = ?, `room_id` = ?, `last_seen` = ? WHERE `id` = ?";

        try (Connection connection = Database.getInstance().getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, user.getName());
            statement.setString(2, user.getMotto());
            statement.setString(3, user.getGender());
            statement.setString(4, user.getLook());
            statement.setInt(5, seenTimes);
            statement.setInt(6, roomId);
            statement.setTimestamp(7, new Timestamp(System.currentTimeMillis()));
            statement.setInt(8, user.getId());

            statement.execute();
        } catch (SQLException exception) {
            logger.error(exception.getMessage());
        }
    }
}
