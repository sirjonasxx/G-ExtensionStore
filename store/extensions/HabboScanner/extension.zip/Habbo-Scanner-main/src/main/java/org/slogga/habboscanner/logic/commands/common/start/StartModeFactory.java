package org.slogga.habboscanner.logic.commands.common.start;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.function.Supplier;

import org.slogga.habboscanner.logic.commands.common.start.modes.*;
import org.slogga.habboscanner.logic.commands.common.start.modes.bot_per_groups_id.StartBotPerGroupsId;
import org.slogga.habboscanner.logic.commands.common.start.modes.bot_per_id.StartBotPerId;

public class StartModeFactory {
    private static final Map<String, Supplier<IStarter>> startModeMap = new HashMap<>();

    static {
        startModeMap.put("bot.per.id", StartBotPerId::new);
        startModeMap.put("bot.per.owner.name.list", StartBotPerOwnerNameList::new);
        startModeMap.put("bot.per.room.id.list", StartBotPerRoomIdList::new);
        startModeMap.put("bot.in.active.rooms", StartBotInActiveRooms::new);
        startModeMap.put("bot.per.groups.id", StartBotPerGroupsId::new);
    }

    public static IStarter getStartModeStrategy(String modeKey) {
        // Get the mode supplier from the map using the provided key.
        Optional<Supplier<IStarter>> modeSupplierOptional = Optional.ofNullable(startModeMap.get(modeKey));

        Supplier<IStarter> modeSupplier = modeSupplierOptional.orElseThrow(() ->
                new IllegalArgumentException("Invalid start mode key."));

        return modeSupplier.get();
    }

    public static Set<String> getStartModeKeys() {
        return startModeMap.keySet();
    }
}
