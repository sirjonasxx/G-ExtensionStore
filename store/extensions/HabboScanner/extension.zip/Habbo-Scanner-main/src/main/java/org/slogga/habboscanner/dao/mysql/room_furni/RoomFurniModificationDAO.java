package org.slogga.habboscanner.dao.mysql.room_furni;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slogga.habboscanner.dao.Database;

import org.slogga.habboscanner.models.furni.Furni;

public class RoomFurniModificationDAO {
    private static final Logger logger = LoggerFactory.getLogger(RoomFurniModificationDAO.class);

    public static void insertRoomFurni(Furni furni) {
        String query = "INSERT IGNORE INTO room_furni (id, classname, name, owner, type, "
                + "room_id, extradata, timestamp) VALUES (?, ?, ?, ?, ?, ?, ?, ?) "
                + "ON DUPLICATE KEY UPDATE extradata = IF(extradata IS NULL OR extradata = '', VALUES(extradata), extradata);";

        try (Connection connection = Database.getInstance().getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, furni.getId());
            statement.setString(2, furni.getClassname());
            statement.setString(3, furni.getName());
            statement.setString(4, furni.getOwner());
            statement.setString(5, furni.getType().getTypeName());
            statement.setInt(6, furni.getRoomId());
            statement.setString(7, furni.getExtradata());
            statement.setTimestamp(8, furni.getTimestamp());

            statement.execute();
        } catch (SQLException exception) {
            logger.error(exception.getMessage());
        }
    }

    public static void updateRoomFurniOwner(String oldOwner, String newOwner) {
        String updateQuery = "UPDATE IGNORE room_furni SET owner = ? WHERE owner = ?";
        String deleteQuery = "DELETE FROM room_furni WHERE owner = ?";

        try (Connection connection = Database.getInstance().getConnection();
             PreparedStatement updateStatement = connection.prepareStatement(updateQuery)) {
            updateStatement.setString(1, newOwner);
            updateStatement.setString(2, oldOwner);
            updateStatement.execute();
        } catch (SQLException exception) {
            logger.error(exception.getMessage());
        }

        try (Connection connection = Database.getInstance().getConnection();
             PreparedStatement deleteStatement = connection.prepareStatement(deleteQuery)) {
            deleteStatement.setString(1, oldOwner);
            deleteStatement.execute();
        } catch (SQLException exception) {
            logger.error(exception.getMessage());
        }
    }
}
