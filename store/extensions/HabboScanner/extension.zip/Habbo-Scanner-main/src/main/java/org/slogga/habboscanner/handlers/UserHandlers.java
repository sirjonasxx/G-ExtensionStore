package org.slogga.habboscanner.handlers;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import gearth.extensions.parsers.HEntity;

import gearth.protocol.HMessage;

import org.slogga.habboscanner.HabboScanner;

import org.slogga.habboscanner.logic.commands.CommandFactory;
import org.slogga.habboscanner.logic.commands.common.start.StartCommand;

import org.slogga.habboscanner.logic.game.BaseEntityFactory;
import org.slogga.habboscanner.logic.game.console.commands.FollowConsoleCommand;
import org.slogga.habboscanner.logic.game.entities.BaseEntity;

import org.slogga.habboscanner.models.enums.CommandKeys;

import org.slogga.habboscanner.utils.ActionMapGenerator;

public class UserHandlers {
    private List<BaseEntity> entities;

    public void onUsers(HMessage message) {
        boolean isUserScannerActive = Boolean.parseBoolean(HabboScanner.getInstance()
                .getConfigurator()
                .getProperties()
                .get("bot").getProperty("user.active"));

        int roomId = HabboScanner.getInstance().getConfigurator().getRoomEntryHandlers().getRoomId();

        if (!isUserScannerActive || roomId == -1) return;

        entities = Stream.of(HEntity.parse(message.getPacket()))
                .map(entity -> BaseEntityFactory.createEntity(entity, roomId))
                .collect(Collectors.toList());

        entities.forEach(BaseEntity::processEntity);
    }

    public void onChat(HMessage message) {
        if (!shouldHandleChat()) return;

        int unknownMessage1 = message.getPacket().readInteger();

        String messageText = message.getPacket().readString();
        if (entities == null || messageText == null) return;

        handleChatMessage(messageText);
    }

    public void onFollowFriendFailed(HMessage message) {
        FollowConsoleCommand followConsoleCommand = (FollowConsoleCommand) CommandFactory.getCommandExecutor()
                .getCommands().get(CommandKeys.FOLLOW.getKey());

        followConsoleCommand.notifyUserOnRoomStatus(message, "unknown.room.access.message");
    }

    private boolean shouldHandleChat() {
        boolean isBotEnabled = getBotPropertyAsBoolean("bot.enabled");
        boolean isResponseToChatEnabled = getBotPropertyAsBoolean("response.to.chat.enabled");

        StartCommand startCommand = (StartCommand) CommandFactory.getCommandExecutor()
                .getCommands().get(CommandKeys.START.getKey());

        return isBotEnabled && isResponseToChatEnabled && startCommand.isBotRunning();
    }

    private boolean getBotPropertyAsBoolean(String propertyName) {
        return Boolean.parseBoolean(HabboScanner.getInstance()
                .getConfigurator()
                .getProperties()
                .get("bot").getProperty(propertyName));
    }

    private void handleChatMessage(String messageText) {
        String[] triggerPhrases = getTriggerPhrases();

        for (String phrase : triggerPhrases) {
            Map<Character, Runnable> actions = getActionsFromPhrase(phrase);

            if (!messageTextContainsKey(messageText, phrase) || !actionsContainsActionKey(actions, phrase))
                continue;

            actions.get(getActionKey(phrase)).run();
        }
    }


    private String[] getTriggerPhrases() {
        String phrasesThatTriggerBotReaction = HabboScanner.getInstance()
                .getConfigurator()
                .getProperties()
                .get("message").getProperty("phrases.that.trigger.bot.reaction");

        return phrasesThatTriggerBotReaction.split("---");
    }

    private Map<Character, Runnable> getActionsFromPhrase(String phrase) {
        String value = getValueFromPhrase(phrase);

        return ActionMapGenerator.generateActionMapFromValue(value);
    }

    private String getValueFromPhrase(String phrase) {
        int delimiterIndex = phrase.indexOf(":");

        return phrase.substring(delimiterIndex + 1);
    }

    private boolean messageTextContainsKey(String messageText, String phrase) {
        String key = getKeyFromPhrase(phrase);

        return messageText.contains(key);
    }

    private String getKeyFromPhrase(String phrase) {
        int delimiterIndex = phrase.indexOf(":");

        return phrase.substring(0, delimiterIndex);
    }

    private boolean actionsContainsActionKey(Map<Character, Runnable> actions, String phrase) {
        char actionKey = getActionKey(phrase);

        return actions.containsKey(actionKey);
    }

    private char getActionKey(String phrase) {
        String value = getValueFromPhrase(phrase);

        return value.charAt(0);
    }
}
