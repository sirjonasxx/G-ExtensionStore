package org.slogga.habboscanner.logic.game.furni;

import java.sql.Date;
import java.sql.Timestamp;

import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import org.slogga.habboscanner.dao.mysql.room_furni.AggregateRoomFurniDAO;

import org.slogga.habboscanner.logic.commands.CommandFactory;

import org.slogga.habboscanner.logic.configurators.HabboScannerConfigurator;
import org.slogga.habboscanner.logic.game.HabboActions;
import org.slogga.habboscanner.logic.game.ItemProcessor;

import org.slogga.habboscanner.logic.commands.common.follow.FollowCommand;

import org.slogga.habboscanner.HabboScanner;

import org.slogga.habboscanner.models.enums.CommandKeys;

import org.slogga.habboscanner.models.furni.Furni;

import org.slogga.habboscanner.utils.DateUtils;

public class FurniInsightsAndTransactionExecutor {
    private final ScheduledExecutorService executorService = Executors.newSingleThreadScheduledExecutor();

    private List<String> transactions;

    public void executeTransactionsAndProvideFurniInsights(Date estimatedDate) {
        HabboScannerConfigurator configurator = HabboScanner.getInstance().getConfigurator();
        boolean isBotEnabled = Boolean.parseBoolean(configurator.getProperties().get("bot").getProperty("bot.enabled"));

        ItemProcessor itemProcessor = configurator.getRoomEntryHandlers().getItemProcessor();
        Furni oldestFurni = itemProcessor.getOldestFurni();
        String oldestFurniInRoomMessage = generateOldestFurniInsight(oldestFurni, estimatedDate);

        if (!isBotEnabled) {
            executorService.schedule(() -> HabboActions.whisperMessage(oldestFurniInRoomMessage),
                    1, TimeUnit.SECONDS);

            return;
        }

        int consoleUserId = HabboScanner.getInstance().getConfigurator().getConsoleHandlers().getUserId();
        String rarestFurniInRoomMessage = generateRarestFurniInsight(itemProcessor);

        HabboActions.sendMessage(consoleUserId, oldestFurniInRoomMessage);

        executorService.schedule(() -> HabboActions.sendMessage(consoleUserId, rarestFurniInRoomMessage),
                2, TimeUnit.SECONDS);

        executorService.schedule(this::executeTransactionsAndTerminateSession, 4, TimeUnit.SECONDS);
    }

    private String generateOldestFurniInsight(Furni oldestFurni, Date estimatedDate) {
        String name = oldestFurni.getName();
        String classname = oldestFurni.getClassname();

        Timestamp timestamp = new Timestamp(estimatedDate.getTime());
        String formattedDate = DateUtils.formatTimestampToDate(timestamp);

        String oldestFurniInRoomMessage = HabboScanner.getInstance()
                .getConfigurator().getProperties()
                .get("message").getProperty("oldest.furni.in.room.message");

        return oldestFurniInRoomMessage
                .replace("%name%", name)
                .replace("%classname%", classname)
                .replace("%date%", formattedDate);
    }

    private String generateRarestFurniInsight(ItemProcessor itemProcessor) {
        String rarestFurniName = itemProcessor.getRarestFurniName();
        int highestSeenPieces = itemProcessor.getHighestSeenPieces();

        String rarestFurniInRoomMessage = HabboScanner.getInstance()
                .getConfigurator().getProperties()
                .get("message").getProperty("rarest.furni.in.room.message");

        return rarestFurniInRoomMessage
                .replace("%rarestFurniName%", rarestFurniName)
                .replace("%highestSeenPieces%", Integer.toString(highestSeenPieces));
    }

    private void executeTransactionsAndTerminateSession() {
        performFurniTransactions();

        /*
         Schedule the dispatchGoodbyeMessageAndUpdateAccess method to
         run after all transactions have been processed.
         */
        executorService.schedule(this::dispatchGoodbyeMessageAndUpdateAccess,
                4L * transactions.size() + 1, TimeUnit.SECONDS);
    }

    private void performFurniTransactions() {
        String currentOwnerName = HabboScanner.getInstance()
                .getConfigurator().getRoomDetailsHandlers()
                .getRoomDetails().getCurrentOwnerName();
        int roomId = HabboScanner.getInstance().getConfigurator().getRoomEntryHandlers().getRoomId();

        transactions = AggregateRoomFurniDAO.retrieveRoomFurniTransactions(currentOwnerName, roomId);

        int consoleUserId = HabboScanner.getInstance().getConfigurator().getConsoleHandlers().getUserId();

        if (transactions.isEmpty()) {
            String noTradesDetectedMessage = HabboScanner.getInstance().getConfigurator()
                    .getProperties().get("message").getProperty("no.trades.detected.message");

            HabboActions.sendMessage(consoleUserId, noTradesDetectedMessage);

            return;
        }

        String latestFurniPassedMessage = HabboScanner.getInstance().getConfigurator().getProperties().get("message")
                .getProperty("latest.furni.passed.message");

        HabboActions.sendMessage(consoleUserId, latestFurniPassedMessage);

        transactions.forEach((transaction) -> executorService.schedule(() -> HabboActions.
                sendMessage(consoleUserId, transaction), 5, TimeUnit.SECONDS));
    }

    private void dispatchGoodbyeMessageAndUpdateAccess() {
        String botGoodbyeMessage = HabboScanner.getInstance()
                .getConfigurator().getProperties().get("message").getProperty("bot.goodbye.message");
        String[] botGoodbyeMessageArray = botGoodbyeMessage.split("---");

        int randomIndex = (int) (Math.random() * botGoodbyeMessageArray.length);
        botGoodbyeMessage = botGoodbyeMessageArray[randomIndex];

        int userId = HabboScanner.getInstance().getConfigurator().getConsoleHandlers().getUserId();
        String finalMessage = botGoodbyeMessage;

        HabboActions.sendMessage(userId, finalMessage);

        FollowCommand followCommand = (FollowCommand) CommandFactory.getCommandExecutor()
                .getCommands().get(CommandKeys.FOLLOW.getKey());

        followCommand.initiateBotAndRefreshRoomAccess();
    }
}
