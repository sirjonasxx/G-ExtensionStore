package org.slogga.habboscanner.logic.game.furni;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.*;

import lombok.Getter;

import org.slogga.habboscanner.HabboScanner;

import org.slogga.habboscanner.dao.mysql.room_furni.RoomFurniRetrievalDAO;

import org.slogga.habboscanner.logic.configurators.HabboScannerConfigurator;
import org.slogga.habboscanner.logic.game.HabboActions;

import org.slogga.habboscanner.models.enums.FurnitypeEnum;

public class FurniHistoricalInfoBroadcaster {
    private final FurniOwnershipTracker furniOwnershipTracker;

    @Getter
    private StringBuilder aggregatedMessage;

    private final ScheduledExecutorService executorService = Executors.newSingleThreadScheduledExecutor();

    public FurniHistoricalInfoBroadcaster() {
        furniOwnershipTracker = new FurniOwnershipTracker();
    }

    public void broadcastFurniHistoryDetails(int id, FurnitypeEnum type, String formattedDate, int userId) {
        HashMap<String, Object> furni;

        aggregatedMessage = new StringBuilder();

        furni = RoomFurniRetrievalDAO.retrieveRoomFurni(id, type.getTypeName());

        if (furni == null) {
            notifyUserOfEmptyRoom(formattedDate, userId);

            return;
        }

        executeFurniInfoBroadcast(furni, formattedDate, id, userId, type);
    }

    private void notifyUserOfEmptyRoom(String formattedDate, int userId) {
        String dateNotification = HabboScanner
                .getInstance()
                .getConfigurator()
                .getProperties()
                .get("message")
                .getProperty("date.notification.message");
        dateNotification = dateNotification.replace("%formattedDate%", formattedDate);

        aggregatedMessage.append(dateNotification).append("\n");

        HabboActions.sendMessage(userId, dateNotification);

        String furniJustPlacedMessage = HabboScanner
                .getInstance()
                .getConfigurator()
                .getProperties()
                .get("message")
                .getProperty("furni.just.placed.message");
        HabboActions.sendMessage(userId, furniJustPlacedMessage);

        aggregatedMessage.append(furniJustPlacedMessage).append("\n");
    }

    private void executeFurniInfoBroadcast(HashMap<String, Object> furni, String formattedDate,
                                           int id, int userId, FurnitypeEnum type) {
        String name = (String) furni.get("name");
        String classname = (String) furni.get("classname");

        Map<String, String> itemDefinition = HabboScanner.getInstance()
                .getFurnidataConfigurator().getItems().get(classname);

        HabboScannerConfigurator configurator = HabboScanner.getInstance().getConfigurator();

        boolean isBotEnabled = Boolean.parseBoolean(configurator.getProperties()
                .get("bot").getProperty("bot.enabled"));
        String furniNameDateInfoMessage = getFurniNameDateInfoMessage(configurator, name, formattedDate);

        if (!isBotEnabled) {
            HabboActions.whisperMessage(furniNameDateInfoMessage);

            return;
        }

        String finalMessage = getFinalMessage(itemDefinition, configurator, furniNameDateInfoMessage);

        aggregatedMessage.append(finalMessage).append("\n");

        scheduleTasks(itemDefinition, userId, finalMessage, id, classname, type);
    }

    private String getFurniNameDateInfoMessage(HabboScannerConfigurator configurator, String name, String formattedDate) {
        String furniNameDateInfoMessage = configurator.getProperties().get("message")
                .getProperty("furni.name.date.info.message");
        return furniNameDateInfoMessage.replace("%name%", name)
                .replace("%formattedDate%", formattedDate);
    }

    private String getFinalMessage(Map<String, String> itemDefinition, HabboScannerConfigurator configurator, String furniNameDateInfoMessage) {
        String category = Optional.ofNullable(itemDefinition)
                .map(item -> item.get("category"))
                .orElse("");
        String itemCategoryMessage = configurator.getProperties().get("message").getProperty("item.category.message");
        itemCategoryMessage = itemCategoryMessage.replace("%category%", category);

        return furniNameDateInfoMessage + (category.isEmpty() ? "" : ". " + itemCategoryMessage);
    }

    private void scheduleTasks(Map<String, String> itemDefinition, int userId, String finalMessage, int id, String classname, FurnitypeEnum type) {
        executorService.schedule(() -> HabboActions.sendMessage(userId, finalMessage), 2, TimeUnit.SECONDS);

        Optional.ofNullable(itemDefinition).ifPresent(item -> {
            executorService.schedule(() -> furniOwnershipTracker.trackTopFurniOwners(item, classname),
                    4, TimeUnit.SECONDS);
            executorService.schedule(() -> furniOwnershipTracker.manageFurniOwnershipHistory(id, userId, type),
                    8, TimeUnit.SECONDS);
        });
    }
}
