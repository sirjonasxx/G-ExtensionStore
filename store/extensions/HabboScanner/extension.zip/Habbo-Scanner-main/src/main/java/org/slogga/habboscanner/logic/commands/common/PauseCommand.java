package org.slogga.habboscanner.logic.commands.common;

import org.slogga.habboscanner.HabboScanner;

import org.slogga.habboscanner.logic.commands.Command;
import org.slogga.habboscanner.logic.commands.CommandExecutorProperties;
import org.slogga.habboscanner.logic.commands.CommandFactory;
import org.slogga.habboscanner.logic.commands.common.start.StartCommand;

import org.slogga.habboscanner.models.enums.CommandKeys;

public class PauseCommand implements Command {
    @Override
    public void execute(CommandExecutorProperties properties) {
        StartCommand startCommand = (StartCommand) CommandFactory.getCommandExecutor()
                .getCommands().get(CommandKeys.START.getKey());
        startCommand.setBotRunning(false);

        String relaxMomentMessage = HabboScanner.getInstance().getConfigurator().getProperties().get("message")
                .getProperty("relax.moment.message");

        CommandFactory.getCommandExecutor().sendMessage(relaxMomentMessage, properties);
    }

    @Override
    public String getDescription() {
        return HabboScanner.getInstance().getConfigurator().getProperties().get("command_description")
                .getProperty("pause.command.description");
    }
}
