package org.slogga.habboscanner.handlers;

import gearth.protocol.HMessage;

import org.slogga.habboscanner.HabboScanner;

import org.slogga.habboscanner.handlers.room.RoomEntryHandlers;

import org.slogga.habboscanner.logic.game.HabboActions;

import org.slogga.habboscanner.logic.commands.common.follow.FollowCommand;
import org.slogga.habboscanner.logic.commands.CommandFactory;

import org.slogga.habboscanner.dao.mysql.LogsDAO;

import org.slogga.habboscanner.logic.game.console.commands.LiveConsoleCommand;
import org.slogga.habboscanner.models.enums.CommandKeys;
import org.slogga.habboscanner.models.enums.SourceType;

import java.util.Optional;

public class ErrorHandlers {
    public void onCantConnect(HMessage message) {
        message.setBlocked(true);

        int packetValue = message.getPacket().readInteger();
        String errorMessage = getErrorMessage(packetValue);

        handleFollowCommand(errorMessage);
    }

    public void onErrorReport(HMessage message) {
        int unknownVariable = message.getPacket().readInteger();
        int errorCode = message.getPacket().readInteger();

        FollowCommand followCommand = (FollowCommand)
                CommandFactory.getCommandExecutor().getCommands().get(CommandKeys.FOLLOW.getKey());
        followCommand.initiateBotAndRefreshRoomAccess();

        RoomEntryHandlers roomEntryHandlers = HabboScanner.getInstance()
                .getConfigurator().getRoomEntryHandlers();
        int roomId = roomEntryHandlers.getRoomId();

        String serverErrorMessage = HabboScanner.getInstance()
                .getConfigurator()
                .getProperties()
                .get("message").getProperty("server.error.message");

        serverErrorMessage = serverErrorMessage
                .replace("%roomId%", String.valueOf(roomId))
                .replace("%errorId%", String.valueOf(errorCode));

        LogsDAO.insertLog(serverErrorMessage);
    }

    public void onGenericError(HMessage message) {
        LiveConsoleCommand liveConsoleCommand = (LiveConsoleCommand) CommandFactory.getCommandExecutor()
                .getCommands().get(CommandKeys.LIVE.getKey());
        if (!liveConsoleCommand.isLiveMode()) return;

        int errorMessage = message.getPacket().readInteger();
        if (errorMessage != -100005) return;

        message.setBlocked(true);
    }

    private String getErrorMessage(int packetValue) {
        String botBannedFromRoomMessage = HabboScanner.getInstance()
                .getConfigurator()
                .getProperties()
                .get("message")
                .getProperty("bot.banned.from.room.message");

        String roomFullMessage = HabboScanner.getInstance()
                .getConfigurator()
                .getProperties()
                .get("message")
                .getProperty("room.full.message");

        return (packetValue == 4) ? botBannedFromRoomMessage : roomFullMessage;
    }

    private void handleFollowCommand(String errorMessage) {
        FollowCommand followCommand = (FollowCommand)
                CommandFactory.getCommandExecutor().getCommands().get(CommandKeys.FOLLOW.getKey());

        followCommand.initiateBotAndRefreshRoomAccess();

        Optional.ofNullable(followCommand.getSourceType())
                .ifPresent(sourceType -> sendMessageBasedOnSourceType(sourceType, errorMessage));
    }

    private void sendMessageBasedOnSourceType(SourceType sourceType, String errorMessage) {
        switch (sourceType) {
            case HABBO: sendHabboMessage(errorMessage);
            case DISCORD: sendDiscordMessage(errorMessage);
        }
    }

    private void sendHabboMessage(String errorMessage) {
        int consoleUserId = HabboScanner.getInstance()
                .getConfigurator()
                .getConsoleHandlers()
                .getUserId();

        HabboActions.sendPrivateMessage(consoleUserId, errorMessage);
    }

    private void sendDiscordMessage(String errorMessage) {
        Optional.ofNullable(HabboScanner.getInstance().getDiscordBot())
                .ifPresent(discordBot -> discordBot.getMessageHandler().sendMessageToFeedChannel(errorMessage));
    }
}
