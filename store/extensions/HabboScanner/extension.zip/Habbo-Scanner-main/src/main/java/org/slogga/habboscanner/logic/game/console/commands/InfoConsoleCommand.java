package org.slogga.habboscanner.logic.game.console.commands;

import org.slogga.habboscanner.logic.commands.CommandExecutorProperties;
import org.slogga.habboscanner.logic.commands.common.InfoCommand;

public class InfoConsoleCommand extends InfoCommand {
    @Override
    public void execute(CommandExecutorProperties properties) {
        properties.getMessage().setBlocked(true);

        super.execute(properties);
    }
}
