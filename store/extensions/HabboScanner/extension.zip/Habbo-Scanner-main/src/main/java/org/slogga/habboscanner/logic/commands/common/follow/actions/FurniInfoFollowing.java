package org.slogga.habboscanner.logic.commands.common.follow.actions;

import java.util.Objects;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import org.slogga.habboscanner.HabboScanner;

import org.slogga.habboscanner.logic.commands.CommandFactory;

import org.slogga.habboscanner.logic.commands.common.follow.FollowCommand;
import org.slogga.habboscanner.logic.commands.common.follow.IFollower;

import org.slogga.habboscanner.logic.configurators.HabboScannerConfigurator;

import org.slogga.habboscanner.logic.game.HabboActions;

import org.slogga.habboscanner.models.enums.CommandKeys;
import org.slogga.habboscanner.models.enums.FollowingAction;

public class FurniInfoFollowing implements IFollower {
    @Override
    public void execute() {
        HabboScannerConfigurator configurator = HabboScanner.getInstance().getConfigurator();

        int consoleUserId = configurator.getConsoleHandlers().getUserId();
        String moveRotateFurniMessage = configurator.getProperties()
                .get("message").getProperty("move.rotate.furni.message");

        ScheduledExecutorService executorService = Executors.newSingleThreadScheduledExecutor();

        HabboActions.sendMessage(consoleUserId, moveRotateFurniMessage);
        executorService.schedule(() -> sendInfoAndInitiateBot(executorService, consoleUserId, configurator), 2, TimeUnit.MINUTES);
    }

    private void sendInfoAndInitiateBot(ScheduledExecutorService executorService, int consoleUserId, HabboScannerConfigurator configurator) {
        FollowCommand followCommand = (FollowCommand) CommandFactory.getCommandExecutor()
                .getCommands().get(CommandKeys.FOLLOW.getKey());

        if (!Objects.equals(followCommand.getFollowingAction().getAction(),
                FollowingAction.INFO.getAction())) return;

        String endOfFurniInfoModeMessage = configurator
                .getProperties().get("message").getProperty("end.of.furni_info.mode.message");
        HabboActions.sendMessage(consoleUserId, endOfFurniInfoModeMessage);

        executorService.schedule(followCommand::initiateBotAndRefreshRoomAccess,
                2, TimeUnit.SECONDS);
    }
}
