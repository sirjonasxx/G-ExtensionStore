package org.slogga.habboscanner.dao.mysql.entities;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slogga.habboscanner.dao.Database;

import org.slogga.habboscanner.models.habbo_entities.HabboBot;

public class BotsDAO {
    private static final Logger logger = LoggerFactory.getLogger(BotsDAO.class);

    public static void insertBot(HabboBot bot, int roomId, String extradata) {
        String query = "INSERT IGNORE INTO `bots` (`id`, `name`, `motto`, `look`, " +
                "`room_id`, `old_bot`, `extradata`) VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (Connection connection = Database.getInstance().getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, bot.getId());
            statement.setString(2, bot.getName());
            statement.setString(3, bot.getMotto());
            statement.setString(4, bot.getLook());
            statement.setInt(5, roomId);
            statement.setBoolean(6, bot.isOldBot());
            statement.setString(7, extradata);

            statement.execute();
        } catch (SQLException exception) {
            logger.error(exception.getMessage());
        }
    }
}
