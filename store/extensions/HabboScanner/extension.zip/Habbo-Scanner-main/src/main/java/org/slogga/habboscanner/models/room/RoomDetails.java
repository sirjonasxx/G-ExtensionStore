package org.slogga.habboscanner.models.room;

import lombok.Getter;

import org.slogga.habboscanner.models.enums.RoomAccessMode;

@Getter
public final class RoomDetails {
    private final int guestRoomId;
    private final String roomName;
    private final int ownerId;
    private final String currentOwnerName;
    private final RoomAccessMode roomAccessMode;

    public RoomDetails(int guestRoomId, String roomName, int ownerId, String currentOwnerName,
                       RoomAccessMode roomAccessMode) {
        this.guestRoomId = guestRoomId;
        this.roomName = roomName;
        this.ownerId = ownerId;
        this.currentOwnerName = currentOwnerName;
        this.roomAccessMode = roomAccessMode;
    }

    @Override
    public String toString() {
        return "RoomDetails[" +
                "guestRoomId=" + guestRoomId + ", " +
                "roomName=" + roomName + ", " +
                "ownerId=" + ownerId + ", " +
                "currentOwnerName=" + currentOwnerName + ", " +
                "roomAccessMode=" + roomAccessMode + ']';
    }

}
