package org.slogga.habboscanner.models.habbo_entities;

import lombok.Getter;

@Getter
public final class HabboPet {
    private final int id;
    private final String name;

    public HabboPet(int id, String name) {
        this.id = id;
        this.name = name;
    }

    @Override
    public String toString() {
        return "HabboPet[" +
                "id=" + id + ", " +
                "name=" + name + ']';
    }

}
