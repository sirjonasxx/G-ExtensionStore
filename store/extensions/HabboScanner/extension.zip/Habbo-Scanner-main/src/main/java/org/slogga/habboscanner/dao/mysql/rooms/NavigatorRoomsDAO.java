package org.slogga.habboscanner.dao.mysql.rooms;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slogga.habboscanner.dao.Database;
import org.slogga.habboscanner.logic.DefaultValues;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import java.util.ArrayList;

public class NavigatorRoomsDAO {
    private static final Logger logger = LoggerFactory.getLogger(NavigatorRoomsDAO.class);

    public static void deleteNavigatorRooms() {
        String deleteQuery = "DELETE FROM `navigator_rooms`";

        try (Connection connection = Database.getInstance().getConnection();
             PreparedStatement statement = connection.prepareStatement(deleteQuery)) {

            statement.execute();
        } catch (SQLException exception) {
            logger.error(exception.getMessage());
        }
    }

    public static void insertNavigatorRooms(ArrayList<String> rooms) {
        String query = "INSERT INTO `navigator_rooms` (`id`, `name`, `description`, " +
                "`owner_name`, `users`, `max_users`, `access_type`) VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (Connection connection = Database.getInstance().getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
            for (String room : rooms) {
                String divider = DefaultValues.getInstance().getRoomDataDivider();
                String[] data = room.split(divider);

                statement.setInt(1, Integer.parseInt(data[0]));
                statement.setString(2, data[1]);
                statement.setString(3, data[2]);
                statement.setString(4, data[3]);
                statement.setInt(5, Integer.parseInt(data[4]));
                statement.setInt(6, Integer.parseInt(data[5]));
                statement.setString(7, data[6]);

                statement.execute();

                statement.clearParameters();
            }
        } catch (SQLException exception) {
            logger.error(exception.getMessage());
        }
    }
}
