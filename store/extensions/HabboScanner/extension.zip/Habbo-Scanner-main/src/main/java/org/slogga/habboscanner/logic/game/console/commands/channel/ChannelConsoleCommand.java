package org.slogga.habboscanner.logic.game.console.commands.channel;

import java.util.Arrays;
import java.util.Optional;
import java.util.Properties;

import lombok.Data;

import org.slogga.habboscanner.HabboScanner;

import org.slogga.habboscanner.logic.commands.Command;
import org.slogga.habboscanner.logic.commands.CommandExecutorProperties;

import org.slogga.habboscanner.logic.commands.CommandFactory;
import org.slogga.habboscanner.models.enums.MessageChannel;

@Data
public class ChannelConsoleCommand implements Command {
    private MessageChannel channel;

    @Override
    public void execute(CommandExecutorProperties properties) {
        String[] arguments = properties.getMessageText().split(" ", 2);
        Optional<String> channelString = Arrays.stream(arguments)
                .skip(1)
                .findFirst();

        Properties messageProperties = HabboScanner.getInstance()
                .getConfigurator().getProperties()
                .get("message");

        if (!channelString.isPresent()) {
            String channelDecisionMessage = messageProperties.getProperty("channel.decision.message");
            CommandFactory.getCommandExecutor().sendMessage(channelDecisionMessage, properties);

            return;
        }

        boolean isValidArgument = channelString.get().equals("chat") || channelString.get().equals("console");

        if (!isValidArgument) {
            String invalidChannelModeMessage = messageProperties.getProperty("invalid.channel.mode.message");
            CommandFactory.getCommandExecutor().sendMessage(invalidChannelModeMessage, properties);

            return;
        }

        channel = MessageChannel.fromValue(channelString.get());
        IChannelMode modeStrategy = ChannelModeFactory.getChanelModeStrategy(channel);

        if (modeStrategy == null) return;

        modeStrategy.execute();

        String modeChangeSuccessMessage = messageProperties.getProperty("mode.change.success.message");
        CommandFactory.getCommandExecutor().sendMessage(modeChangeSuccessMessage, properties);
    }

    @Override
    public String getDescription() {
        return HabboScanner.getInstance()
                .getConfigurator().getProperties()
                .get("command_description").getProperty("channel.command.description");
    }
}
