package org.slogga.habboscanner.models.enums;

import java.util.Arrays;
import java.util.Objects;

import lombok.Getter;

@Getter
public enum FurnitypeEnum {
    FLOOR("Floor"),
    WALL("Wall");

    public static FurnitypeEnum fromValue(String value) {
        return Arrays.stream(FurnitypeEnum.values())
                .filter(mode -> Objects.equals(mode.getTypeName(), value))
                .findFirst()
                .orElse(null);
    }

    private final String typeName;

    FurnitypeEnum(String typeName) {
        this.typeName = typeName;
    }
}
