package org.slogga.habboscanner.logic.commands.common.start.modes.bot_per_id.orders;

import java.util.concurrent.atomic.AtomicInteger;

import org.slogga.habboscanner.logic.commands.common.start.modes.bot_per_id.IRoomVisitOrder;

public class DescVisitOrder implements IRoomVisitOrder {
    private final AtomicInteger roomId;

    public DescVisitOrder(int initialRoomId) {
        this.roomId = new AtomicInteger(initialRoomId);
    }

    @Override
    public int getNextRoomId() {
        return roomId.getAndDecrement();
    }
}
