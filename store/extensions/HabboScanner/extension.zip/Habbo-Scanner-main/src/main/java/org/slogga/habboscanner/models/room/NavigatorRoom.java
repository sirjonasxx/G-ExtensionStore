package org.slogga.habboscanner.models.room;

import lombok.Getter;

import org.slogga.habboscanner.logic.DefaultValues;

@Getter
public final class NavigatorRoom {
    private final int id;
    private final String name;
    private final String description;
    private final String ownerName;
    private final int userAmount;
    private final int maxUserAmount;
    private final int accessMode;

    public NavigatorRoom(int id, String name, String description, String ownerName, int userAmount,
                         int maxUserAmount, int accessMode) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.ownerName = ownerName;
        this.userAmount = userAmount;
        this.maxUserAmount = maxUserAmount;
        this.accessMode = accessMode;
    }

    @Override
    public String toString() {
        String divider = DefaultValues.getInstance().getRoomDataDivider();

        return id + divider +
                name + divider +
                description + divider +
                ownerName + divider +
                userAmount + divider +
                maxUserAmount + divider +
                accessMode;
    }
}
