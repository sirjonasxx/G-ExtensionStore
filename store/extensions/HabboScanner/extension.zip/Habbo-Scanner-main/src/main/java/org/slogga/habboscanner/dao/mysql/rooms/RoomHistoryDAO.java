package org.slogga.habboscanner.dao.mysql.rooms;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slogga.habboscanner.dao.Database;

public class RoomHistoryDAO {
    private static final Logger logger = LoggerFactory.getLogger(RoomHistoryDAO.class);

    public static void insertRoomHistory(int userId, int roomId) {
        String query = "INSERT IGNORE INTO `room_history` (`user_id`, `room_id`) VALUES (?, ?)";

        try (Connection connection = Database.getInstance().getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, userId);
            statement.setInt(2, roomId);

            statement.execute();
        } catch (SQLException exception) {
            logger.error(exception.getMessage());
        }
    }
}
