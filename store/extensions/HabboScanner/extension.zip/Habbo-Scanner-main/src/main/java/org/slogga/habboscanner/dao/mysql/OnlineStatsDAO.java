package org.slogga.habboscanner.dao.mysql;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slogga.habboscanner.dao.Database;

public class OnlineStatsDAO {
    private static final Logger logger = LoggerFactory.getLogger(OnlineStatsDAO.class);

    public static void insertOnlineStats(int onlineAmount, int roomsAmount, String timestamp) {
        String query = "INSERT IGNORE INTO online_stats (online_amount, rooms_amount, timestamp) VALUES (?, ?, ?)";

        try (Connection connection = Database.getInstance().getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, onlineAmount);
            statement.setInt(2, roomsAmount);
            statement.setString(3, timestamp);

            statement.executeUpdate();
        } catch (SQLException exception) {
            logger.error(exception.getMessage());
        }
    }
}
