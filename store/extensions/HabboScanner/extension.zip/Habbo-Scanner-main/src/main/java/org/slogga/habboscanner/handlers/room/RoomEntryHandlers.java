package org.slogga.habboscanner.handlers.room;

import java.util.Optional;

import lombok.Data;

import gearth.protocol.HMessage;
import gearth.protocol.HPacket;

import org.slogga.habboscanner.dao.mysql.room_furni.RoomFurniActiveDAO;

import org.slogga.habboscanner.logic.discord.DiscordBot;

import org.slogga.habboscanner.logic.commands.CommandFactory;
import org.slogga.habboscanner.logic.commands.common.start.StartCommand;

import org.slogga.habboscanner.models.enums.CommandKeys;

import org.slogga.habboscanner.logic.game.ItemProcessor;

import org.slogga.habboscanner.HabboScanner;

@Data
public class RoomEntryHandlers {
    private ItemProcessor itemProcessor;
    private int roomId;
    private long lastRoomAccess;

    public void onRoomReady(HMessage message) {
        initializeRoom(message);
        handleDiscordBotActivity();
        handleRoomFurniActivity();
    }

    public void refreshLastRoomAccess() {
        lastRoomAccess = System.currentTimeMillis();
    }

    private void initializeRoom(HMessage message) {
        HPacket packet = message.getPacket();

        packet.setReadIndex(15);

        roomId = packet.readInteger();
        itemProcessor = new ItemProcessor();
        lastRoomAccess = System.currentTimeMillis();
    }

    private void handleDiscordBotActivity() {
        Optional.ofNullable(HabboScanner.getInstance().getDiscordBot())
                .ifPresent(discordBot -> {
                    handleCriticalAirCrashWarning(discordBot);
                    setBotActivityToArchivingRoom(discordBot);
                });
    }

    private void handleCriticalAirCrashWarning(DiscordBot discordBot) {
        boolean criticalAirCrashWarning = HabboScanner.getInstance().isCriticalAirCrashWarning();

        if (!criticalAirCrashWarning) return;

        StartCommand startCommand = (StartCommand) CommandFactory.getCommandExecutor().getCommands()
                .get(CommandKeys.START.getKey());
        boolean isBotRunning = startCommand != null && startCommand.isBotRunning();

        if (!isBotRunning) return;

        String criticalWarningMessage = HabboScanner.getInstance()
                .getConfigurator()
                .getProperties()
                .get("message")
                .getProperty("discord.bot.critical.warning.message");
        discordBot.getMessageHandler().sendMessageToFeedChannel(criticalWarningMessage);

        HabboScanner.getInstance().setCriticalAirCrashWarning(false);
    }

    private void setBotActivityToArchivingRoom(DiscordBot discordBot) {
        String archivingRoomIdMessage = HabboScanner.getInstance()
                .getConfigurator()
                .getProperties()
                .get("message")
                .getProperty("discord.bot.archiving.room.id.message");
        archivingRoomIdMessage = archivingRoomIdMessage.replace("%roomId%", String.valueOf(roomId));

        discordBot.updateActivity(archivingRoomIdMessage);
    }

    private void handleRoomFurniActivity() {
        boolean isRoomFurniActiveEnabled = Boolean.parseBoolean(HabboScanner.getInstance()
                .getConfigurator()
                .getProperties()
                .get("bot")
                .getProperty("room_furni_active.enabled"));

        if (!isRoomFurniActiveEnabled) return;

        RoomFurniActiveDAO.deleteRoomFurniActive(roomId);
    }
}
