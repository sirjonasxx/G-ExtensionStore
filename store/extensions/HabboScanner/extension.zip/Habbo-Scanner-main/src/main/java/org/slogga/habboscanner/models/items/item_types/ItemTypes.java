package org.slogga.habboscanner.models.items.item_types;

import java.util.ArrayList;

import lombok.Getter;

import org.slogga.habboscanner.models.furni.Furnitype;

@Getter
public class ItemTypes {
    private final ArrayList<Furnitype> furnitype;

    protected ItemTypes(ArrayList<Furnitype> furnitype) {
        this.furnitype = furnitype;
    }
}
