package org.slogga.habboscanner.logic.commands.common.start.modes.bot_per_id.orders;

import java.util.Random;

import org.slogga.habboscanner.dao.mysql.rooms.RoomsDAO;

import org.slogga.habboscanner.logic.commands.common.start.modes.bot_per_id.IRoomVisitOrder;

public class RandomVisitOrder implements IRoomVisitOrder {
    private final Random random = new Random();

    @Override
    public int getNextRoomId() {
        int randomRoomId;
        int MAX_ROOM_ID = 15120371;

        do {
            // Generate a random number between 1 and 15 million.
            randomRoomId = random.nextInt(MAX_ROOM_ID) + 1;
        } while (RoomsDAO.hasRoomBeenVisited(randomRoomId));

        return randomRoomId;
    }
}
