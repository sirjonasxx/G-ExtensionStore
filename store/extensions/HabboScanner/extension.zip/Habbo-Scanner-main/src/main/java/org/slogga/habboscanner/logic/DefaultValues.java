package org.slogga.habboscanner.logic;

import java.util.*;

import lombok.Data;

@Data
public class DefaultValues {
    private static DefaultValues instance;

    private final List<String> propertyNames = Arrays.asList("bot", "message", "discord", "command_description", "mysql");
    private final List<String> validDomains = Arrays.asList("s2", "it", "fi", "es", "de",
            "com.br", "com.tr", "com", "fr", "nl");
    private final Set<String> staffNames = new HashSet<>(Arrays.asList("Adaara", "Mrs.Phoebe", "Johno",
            "Macklebee", "official_rooms", "singhr", "Morgaine", "Teppo", "Alyx_Staff", "-istanbul-", "Lafollegrenouille"));
    private final String roomDataDivider = "---DIVIDER---";

    public static DefaultValues getInstance() {
        return Optional.ofNullable(instance).orElseGet(DefaultValues::new);
    }
}
