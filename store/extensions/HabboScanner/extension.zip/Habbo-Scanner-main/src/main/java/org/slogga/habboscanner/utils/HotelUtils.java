package org.slogga.habboscanner.utils;

import java.util.HashMap;
import java.util.Map;

public class HotelUtils {
    private static final Map<String, String> DOMAIN_URLS;

    static {
        DOMAIN_URLS = new HashMap<>();
        DOMAIN_URLS.put("s2", "https://sandbox.habbo.com/gamedata/furnidata_json/1");
        DOMAIN_URLS.put("default", "https://www.habbo.%s/gamedata/furnidata_json/1");
    }

    public static String getFurnidataURL(String hotelDomain) {
        return DOMAIN_URLS.getOrDefault(hotelDomain, String.format(DOMAIN_URLS.get("default"), hotelDomain));
    }
}
