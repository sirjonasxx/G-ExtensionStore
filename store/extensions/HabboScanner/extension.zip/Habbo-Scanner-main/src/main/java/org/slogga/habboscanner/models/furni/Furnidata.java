package org.slogga.habboscanner.models.furni;

import com.google.gson.Gson;

import org.slogga.habboscanner.models.items.item_types.RoomItemTypes;
import org.slogga.habboscanner.models.items.item_types.WallItemTypes;

import org.slogga.habboscanner.models.enums.FurnitypeEnum;

import java.util.Optional;

public class Furnidata {
    private static Furnidata instance;

    private final RoomItemTypes roomitemtypes;
    private final WallItemTypes wallitemtypes;

    public Furnidata(RoomItemTypes roomitemtypes, WallItemTypes wallitemtypes) {
        this.roomitemtypes = roomitemtypes;
        this.wallitemtypes = wallitemtypes;
    }

    public static void setInstance(String furnidataJson){
        Gson gson = new Gson();

        instance = gson.fromJson(furnidataJson, Furnidata.class);
    }

    public static Furnidata getInstance() {
        return Optional.ofNullable(instance)
                .orElseThrow(() -> new IllegalStateException("Furnidata instance has not yet been initialized."));
    }

    public Furnitype getFurnitype(int id, FurnitypeEnum type) {
        Furnitype floorFurnitype = roomitemtypes.getFurnitype()
                .stream()
                .filter(furnitype -> furnitype.getId() == id)
                .findAny()
                .orElse(null);

        Furnitype wallFurnitype = wallitemtypes.getFurnitype()
                .stream()
                .filter(furnitype -> furnitype.getId() == id)
                .findAny()
                .orElse(null);

        return type == FurnitypeEnum.FLOOR ? floorFurnitype : wallFurnitype;
    }

    @Override
    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();

        roomitemtypes.getFurnitype().forEach(furnitype -> stringBuilder.append(furnitype.toString()));
        wallitemtypes.getFurnitype().forEach(furnitype -> stringBuilder.append(furnitype.toString()));

        return stringBuilder.toString();
    }
}
