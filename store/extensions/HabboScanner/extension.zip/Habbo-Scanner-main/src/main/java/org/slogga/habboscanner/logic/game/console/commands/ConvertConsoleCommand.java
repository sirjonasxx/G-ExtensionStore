package org.slogga.habboscanner.logic.game.console.commands;

import org.slogga.habboscanner.HabboScanner;

import org.slogga.habboscanner.logic.game.HabboActions;

import org.slogga.habboscanner.logic.commands.CommandExecutorProperties;
import org.slogga.habboscanner.logic.commands.common.convert.ConvertCommand;

import org.slogga.habboscanner.models.enums.ConvertFile;

import java.util.Arrays;
import java.util.Optional;

public class ConvertConsoleCommand extends ConvertCommand {
    @Override
    public void execute(CommandExecutorProperties properties) {
        properties.getMessage().setBlocked(true);

        String[] arguments = properties.getMessageText().split(" ");

        Optional<String> file = Arrays.stream(arguments)
                .skip(1)
                .findFirst();

        if (arguments.length < 2) {
            String noParametersMessage = HabboScanner.getInstance()
                    .getConfigurator().getProperties().get("message")
                    .getProperty("convert.command.no.parameters.message");

            HabboActions.sendPrivateMessage(properties.getUserId(), noParametersMessage);

            return;
        }

        convertFile = ConvertFile.fromValue(file.orElse(null));

        super.execute(properties);
    }
}
