package org.slogga.habboscanner.logic.commands.common;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import org.slogga.habboscanner.HabboScanner;

import org.slogga.habboscanner.logic.commands.Command;
import org.slogga.habboscanner.logic.commands.CommandExecutorProperties;
import org.slogga.habboscanner.logic.commands.CommandFactory;

public class ShutdownCommand implements Command {
    @Override
    public void execute(CommandExecutorProperties properties) {
        String message = HabboScanner.getInstance()
                .getConfigurator()
                .getProperties().get("message")
                .getProperty("bot.shutdown.message");

        CommandFactory.getCommandExecutor().sendMessage(message, properties);

        ScheduledExecutorService executorService = Executors.newSingleThreadScheduledExecutor();
        executorService.schedule(() -> System.exit(0), 2, TimeUnit.SECONDS);
    }

    @Override
    public String getDescription() {
        return HabboScanner.getInstance().getConfigurator().getProperties().get("command_description")
                .getProperty("shutdown.command.description");
    }
}