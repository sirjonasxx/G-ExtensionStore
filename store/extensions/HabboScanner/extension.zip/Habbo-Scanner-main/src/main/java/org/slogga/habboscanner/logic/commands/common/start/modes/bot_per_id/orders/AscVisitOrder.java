package org.slogga.habboscanner.logic.commands.common.start.modes.bot_per_id.orders;

import java.util.concurrent.atomic.AtomicInteger;

import org.slogga.habboscanner.logic.commands.common.start.modes.bot_per_id.IRoomVisitOrder;

public class AscVisitOrder implements IRoomVisitOrder {
    private final AtomicInteger roomId;

    public AscVisitOrder(int initialRoomId) {
        this.roomId = new AtomicInteger(initialRoomId);
    }

    @Override
    public int getNextRoomId() {
        return roomId.getAndIncrement();
    }
}
