package org.slogga.habboscanner.logic.game.entities;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Objects;
import java.util.Optional;

import gearth.extensions.parsers.HEntity;

import org.slogga.habboscanner.dao.mysql.LogsDAO;
import org.slogga.habboscanner.dao.mysql.rooms.RoomHistoryDAO;

import org.slogga.habboscanner.dao.mysql.room_furni.RoomFurniModificationDAO;

import org.slogga.habboscanner.dao.mysql.entities.habbo_users.HabboUsersDAO;
import org.slogga.habboscanner.dao.mysql.entities.habbo_users.HabboUsersHistoryDAO;

import org.slogga.habboscanner.HabboScanner;

import org.slogga.habboscanner.logic.DefaultValues;
import org.slogga.habboscanner.logic.discord.DiscordWebhook;

import org.slogga.habboscanner.models.habbo_entities.HabboUser;

import org.slogga.habboscanner.utils.UTF8Utils;

public class HabboEntity extends BaseEntity {
    private static final Logger logger = LoggerFactory.getLogger(HabboEntity.class);

    public HabboEntity(HEntity entity, int roomId) {
        super(entity, roomId);
    }

    @Override
    public void processEntity() {
        ArrayList<HashMap<String, Object>> user;

        user = HabboUsersDAO.getUserById(entity.getId());

        RoomHistoryDAO.insertRoomHistory(entity.getId(), roomId);
        HabboUser newUser = extractUserFromEntity(entity);

        if (user.isEmpty()) {
            HabboUsersDAO.insertUser(newUser, roomId);

            return;
        }

        HashMap<String, Object> userRow = user.get(0);
        HabboUser oldUser = extractUserFromRow(userRow);

        if (hasDetailsChanged(oldUser, newUser))
            HabboUsersHistoryDAO.addUserToHistory(oldUser);

        if (hasNameChanged(oldUser, newUser))
            handleNameChange(oldUser, newUser);

        int updatedSeenTimes = oldUser.getSeenTimes() + 1;
        HabboUsersDAO.updateUser(newUser, updatedSeenTimes, roomId);

        if (!isStaff((newUser))) return;

        notifyStaffSpotted(newUser);
    }

    private HabboUser extractUserFromRow(HashMap<String, Object> userRow) {
        int id = (int) userRow.get("id");
        String name = (String) userRow.get("name");
        String motto = Optional.ofNullable((String) userRow.get("motto")).orElse("");
        String gender = Optional.ofNullable((String) userRow.get("gender")).orElse("");
        String look = Optional.ofNullable((String) userRow.get("look")).orElse("");
        int seenTimes = (int) userRow.get("seen_times");

        return new HabboUser(id, name, motto, gender, look, seenTimes);
    }

    private HabboUser extractUserFromEntity(HEntity entity) {
        int id = entity.getId();
        String name = entity.getName();
        String motto = UTF8Utils.convertToUTF8(entity.getMotto());
        String gender = entity.getGender().toString();
        String look = entity.getFigureId();

        return new HabboUser(id, name, motto, gender, look, 0);
    }

    private boolean hasDetailsChanged(HabboUser oldUser, HabboUser newUser) {
        return !Objects.equals(oldUser.getName(), newUser.getName()) ||
                !Objects.equals(oldUser.getGender(), newUser.getGender()) ||
                !Objects.equals(oldUser.getMotto(), newUser.getMotto()) ||
                !Objects.equals(oldUser.getLook(), newUser.getLook());
    }

    private boolean hasNameChanged(HabboUser oldUser, HabboUser newUser) {
        return !oldUser.getName().equals(newUser.getName());
    }

    private void handleNameChange(HabboUser oldUser, HabboUser newUser) {
        String userNameChangeLogMessage = HabboScanner.getInstance()
                .getConfigurator()
                .getProperties()
                .get("message")
                .getProperty("user.name.change.log.message");

        userNameChangeLogMessage = userNameChangeLogMessage
                .replace("%name%", oldUser.getName())
                .replace("%newName%", newUser.getName());

        LogsDAO.insertLog(userNameChangeLogMessage);

        DiscordWebhook.sendDiscordEmbedMessage(oldUser.getName() + " ha cambiato nome!", oldUser.getName() + " ora si chiama **" +
                        newUser.getName() + "** in Habbo IT", 0xffff00,
                "https://www.habbo.it/habbo-imaging/avatarimage?direction=4&user=" + newUser.getName() +
                        "&headonly=1", "https://i.imgur.com/NDlWDSi.png", "Habbo IT", null);

        logger.info("{} ha cambiato nome, ora si chiama {}", oldUser.getName(), newUser.getName());

        RoomFurniModificationDAO.updateRoomFurniOwner(oldUser.getName(), newUser.getName());
    }

    private boolean isStaff(HabboUser user) {
        return DefaultValues.getInstance().getStaffNames().contains(user.getName());
    }

    private void notifyStaffSpotted(HabboUser user) {
        DiscordWebhook.sendDiscordEmbedMessage("Ho avvistato " + user.getName() + "!",
                "Ho appena avvistato " + user.getName() + " nella stanza ID: **" + roomId +
                        "** in Habbo IT", 0xffff00,
                "https://www.habbo.it/habbo-imaging/avatarimage?direction=4&user=" +
                        user.getName() + "&headonly=1", "https://i.imgur.com/NDlWDSi.png",
                "Habbo IT", null);

        logger.info("Ho avvistato {} nella stanza Id: {}", user.getName(), roomId);
    }
}