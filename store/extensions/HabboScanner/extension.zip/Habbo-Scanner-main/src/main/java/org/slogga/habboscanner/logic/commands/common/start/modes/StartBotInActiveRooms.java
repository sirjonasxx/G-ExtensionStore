package org.slogga.habboscanner.logic.commands.common.start.modes;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import lombok.Data;

import org.slogga.habboscanner.logic.commands.CommandExecutorProperties;
import org.slogga.habboscanner.logic.commands.CommandFactory;

import org.slogga.habboscanner.logic.game.HabboActions;

import org.slogga.habboscanner.logic.commands.common.start.IStarter;
import org.slogga.habboscanner.logic.commands.common.start.StartCommand;

import org.slogga.habboscanner.models.enums.CommandKeys;

@Data
public class StartBotInActiveRooms implements IStarter {
    @Override
    public void execute(CommandExecutorProperties properties) {
        ScheduledExecutorService executorService = Executors.newSingleThreadScheduledExecutor();

        executorService.scheduleAtFixedRate(() -> {
            StartCommand startCommand = (StartCommand) CommandFactory.getCommandExecutor().getCommands()
                    .get(CommandKeys.START.getKey());
            boolean isBotRunning = startCommand.isBotRunning();

            if (!isBotRunning) return;

            HabboActions.sendNavigatorSearch("groups", "");
        }, 0, 2, TimeUnit.SECONDS);
    }
}