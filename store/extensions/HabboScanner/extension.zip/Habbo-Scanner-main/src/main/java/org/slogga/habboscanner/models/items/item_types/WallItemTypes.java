package org.slogga.habboscanner.models.items.item_types;

import java.util.ArrayList;

import org.slogga.habboscanner.models.furni.Furnitype;

public class WallItemTypes extends ItemTypes {
    public WallItemTypes(ArrayList<Furnitype> furnitype) {
        super(furnitype);
    }
}
