package org.slogga.habboscanner.dao.mysql.entities.habbo_users;

import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slogga.habboscanner.dao.Database;
import org.slogga.habboscanner.models.habbo_entities.HabboUser;

public class HabboUsersHistoryDAO {
    private static final Logger logger = LoggerFactory.getLogger(HabboUsersHistoryDAO.class);

    public static void addUserToHistory(HabboUser user) {
        String query = "INSERT INTO `habbo_users_history` (`id`, `name`, `motto`, `gender`, `look`) VALUES (?, ?, ?, ?, ?)";

        try (PreparedStatement statement = Database.getInstance().getConnection().prepareStatement(query)) {
            statement.setInt(1, user.getId());
            statement.setString(2, user.getName());
            statement.setString(3, user.getMotto());
            statement.setString(4, user.getGender());
            statement.setString(5, user.getLook());

            statement.execute();
        } catch (SQLException exception) {
            logger.error(exception.getMessage());
        }
    }
}
