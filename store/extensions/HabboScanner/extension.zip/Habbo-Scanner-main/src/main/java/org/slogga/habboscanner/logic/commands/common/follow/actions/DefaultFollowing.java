package org.slogga.habboscanner.logic.commands.common.follow.actions;

import org.slogga.habboscanner.HabboScanner;

import org.slogga.habboscanner.logic.commands.common.follow.IFollower;

public class DefaultFollowing implements IFollower {
    @Override
    public void execute() {
        HabboScanner.getInstance().getConfigurator()
                .getItemProcessingHandlers().executeTransactionsAndProvideInsights();
    }
}
