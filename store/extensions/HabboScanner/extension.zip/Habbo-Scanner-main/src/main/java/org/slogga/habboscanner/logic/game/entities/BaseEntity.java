package org.slogga.habboscanner.logic.game.entities;

import gearth.extensions.parsers.HEntity;

public abstract class BaseEntity {
    protected final HEntity entity;
    protected final int roomId;

    public BaseEntity(HEntity entity, int roomId) {
        this.entity = entity;
        this.roomId = roomId;
    }

    public abstract void processEntity();
}