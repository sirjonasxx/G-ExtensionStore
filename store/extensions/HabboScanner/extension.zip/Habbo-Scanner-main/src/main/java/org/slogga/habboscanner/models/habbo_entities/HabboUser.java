package org.slogga.habboscanner.models.habbo_entities;

import lombok.Getter;

@Getter
public final class HabboUser {
    private final int id;
    private final String name;
    private final String motto;
    private final String gender;
    private final String look;
    private final int seenTimes;

    public HabboUser(int id, String name, String motto, String gender, String look, int seenTimes) {
        this.id = id;
        this.name = name;
        this.motto = motto;
        this.gender = gender;
        this.look = look;
        this.seenTimes = seenTimes;
    }

    @Override
    public String toString() {
        return "HabboUser[" +
                "id=" + id + ", " +
                "name=" + name + ", " +
                "motto=" + motto + ", " +
                "gender=" + gender + ", " +
                "look=" + look + ", " +
                "seenTimes=" + seenTimes + ']';
    }

}
