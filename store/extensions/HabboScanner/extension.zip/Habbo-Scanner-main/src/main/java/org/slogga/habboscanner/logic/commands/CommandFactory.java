package org.slogga.habboscanner.logic.commands;

import java.util.Map;
import java.util.HashMap;
import java.util.Optional;
import java.util.function.Supplier;

import org.slogga.habboscanner.logic.game.console.ConsoleCommandExecutor;

import org.slogga.habboscanner.logic.discord.commands.DiscordCommandExecutor;

public class CommandFactory {
    private static final Map<CommandExecutorType, Supplier<CommandExecutor>> executorMap = new HashMap<>();

    /**
     * This is the instance of the CommandExecutor.
     * Depending on the context, this could be an instance of ConsoleCommandExecutor or DiscordCommandExecutor.
     */
    private static CommandExecutor commandExecutorInstance;

    static {
        executorMap.put(CommandExecutorType.CONSOLE, () -> new ConsoleCommandExecutor(null));
        executorMap.put(CommandExecutorType.DISCORD, () -> new DiscordCommandExecutor(null));
    }

    public static void getCommandExecutor(CommandExecutorType commandExecutorType, CommandExecutorProperties properties) {
        Optional<Supplier<CommandExecutor>> executorSupplierOptional = Optional.ofNullable(executorMap.get(commandExecutorType));

        Supplier<CommandExecutor> executorSupplier = executorSupplierOptional.orElseThrow(() ->
                new RuntimeException("Unable to get instance of command executor type."));

        // If the commandExecutorInstance is null, initialize it with the executor from the supplier.
        commandExecutorInstance = Optional.ofNullable(commandExecutorInstance).orElse(executorSupplier.get());
        commandExecutorInstance.setProperties(properties);
    }

    public static CommandExecutor getCommandExecutor() {
        return Optional.ofNullable(commandExecutorInstance)
                .orElseThrow(() -> new RuntimeException("CommandExecutor instance is not initialized."));
    }
}
