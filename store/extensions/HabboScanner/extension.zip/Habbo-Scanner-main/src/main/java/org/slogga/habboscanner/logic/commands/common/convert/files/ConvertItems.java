package org.slogga.habboscanner.logic.commands.common.convert.files;

import java.io.PrintWriter;

import org.slogga.habboscanner.logic.commands.CommandExecutorProperties;
import org.slogga.habboscanner.logic.commands.common.convert.Converter;

import org.slogga.habboscanner.models.enums.ConvertFile;

public class ConvertItems extends Converter {
    public void execute(CommandExecutorProperties properties) {
        super.execute(properties, ConvertFile.ITEMS);
    }

    public void processLine(String line, String cvsSplitBy,
                            PrintWriter printWriter, ConvertFile file) {
        String[] furni = line.split(cvsSplitBy, -1);

        String classname = processField(furni, 2);
        String category = processField(furni, 4);
        String type = processField(furni, 6);
        String seenPieces = processField(furni, 8);

        printWriter.println("INSERT INTO " + file.getFileName() + " (classname, category, type, seen_pieces) VALUES ("
                + classname + ", " + category + ", " + type + ", " + seenPieces + ");");
    }
}
