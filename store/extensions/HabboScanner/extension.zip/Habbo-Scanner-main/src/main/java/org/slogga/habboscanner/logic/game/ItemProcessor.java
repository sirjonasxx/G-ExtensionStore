package org.slogga.habboscanner.logic.game;

import java.sql.Date;
import java.util.Arrays;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.commons.lang3.tuple.Triple;

import lombok.Getter;

import gearth.extensions.parsers.HFloorItem;
import gearth.extensions.parsers.HWallItem;
import gearth.extensions.parsers.IFurni;

import org.slogga.habboscanner.dao.mysql.items.ItemsTimelineDAO;

import org.slogga.habboscanner.logic.configurators.HabboScannerConfigurator;
import org.slogga.habboscanner.logic.game.furni.FurniHandler;

import org.slogga.habboscanner.models.enums.FurnitypeEnum;

import org.slogga.habboscanner.models.furni.Furnidata;
import org.slogga.habboscanner.models.furni.Furni;
import org.slogga.habboscanner.models.furni.Furnitype;

import org.slogga.habboscanner.HabboScanner;

import org.slogga.habboscanner.models.items.ItemTimeline;

import org.slogga.habboscanner.utils.DateUtils;
import org.slogga.habboscanner.utils.UTF8Utils;

@Getter
public class ItemProcessor {
    private int highestSeenPieces;

    private final Furni oldestFurni;

    private final FurniHandler furniHandler = new FurniHandler();

    private String rarestFurniName;

    public ItemProcessor(){
        highestSeenPieces = Integer.MAX_VALUE;

        oldestFurni = new Furni();
    }

    public void processFloorItem(HFloorItem item, FurnitypeEnum type, int roomId) {
        Furnitype furnitype = Furnidata.getInstance().getFurnitype(item.getTypeId(), type);

        Map<String, String> itemDefinition = HabboScanner.getInstance()
                .getFurnidataConfigurator().getItems().get(furnitype.getClassname());

        int seenPieces = Optional.ofNullable(itemDefinition)
                .map(map -> map.get("seen_pieces"))
                .map(Integer::parseInt)
                .orElse(0);

        if (highestSeenPieces > seenPieces) {
            highestSeenPieces = seenPieces;
            rarestFurniName = furnitype.getName();
        }

        if (oldestFurni.getId() == null || item.getId() < oldestFurni.getId()) {
            oldestFurni.setId(item.getId());
            oldestFurni.setClassname(furnitype.getClassname());
            oldestFurni.setName(Optional.ofNullable(furnitype.getName())
                    .orElse(oldestFurni.getClassname().equals("poster") ? "Poster" : ""));
        }

        Object[] rawExtradata = item.getStuff();
        String extradata = Arrays.stream(rawExtradata)
                .map(Object::toString)
                .collect(Collectors.joining(", "));
        extradata = UTF8Utils.convertToUTF8(extradata);

        processItem(item, type, roomId, extradata);
    }

    public void processWallItem(HWallItem item, FurnitypeEnum type, int roomId) {
        String extradata = UTF8Utils.convertToUTF8(item.getState());

        processItem(item, type, roomId, extradata);
    }

    public void processFurniAddition(int id, int typeId, int ownerId, String ownerName, String extradata) {
        IFurni furni = new IFurni() {
            @Override
            public int getId() {
                return id;
            }

            @Override
            public int getTypeId() {
                return typeId;
            }

            @Override
            public int getUsagePolicy() {
                return 1;
            }

            @Override
            public int getOwnerId() {
                return ownerId;
            }

            @Override
            public String getOwnerName() {
                return ownerName;
            }
        };

        HabboScannerConfigurator configurator = HabboScanner.getInstance().getConfigurator();

        int roomId = configurator.getRoomEntryHandlers().getRoomId();
        FurnitypeEnum lastFurniPlacedType = configurator.getItemAdditionHandlers().getLastFurniPlacedType();

        furniHandler.insertFurni(furni, lastFurniPlacedType, roomId, extradata);
    }

    public Date estimateDateForOldestFurni() {
        return Optional.ofNullable(oldestFurni.getId())
                .map(id -> {
                    Triple<Integer, ItemTimeline, ItemTimeline> closestEntries = ItemsTimelineDAO
                            .selectClosestEntries(id, FurnitypeEnum.FLOOR);

                    return DateUtils.getLinearInterpolatedDate(closestEntries);
                })
                .orElse(null);
    }

    private void processItem(IFurni item, FurnitypeEnum type, int roomId, String extradata) {
        if (item.getId() > 999999999) return;

        furniHandler.insertFurni(item, type, roomId, extradata);
    }
}
