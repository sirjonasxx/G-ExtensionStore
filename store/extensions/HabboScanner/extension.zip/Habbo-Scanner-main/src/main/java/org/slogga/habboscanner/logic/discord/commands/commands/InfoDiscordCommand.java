package org.slogga.habboscanner.logic.discord.commands.commands;

import org.slogga.habboscanner.logic.commands.CommandExecutorProperties;
import org.slogga.habboscanner.logic.commands.common.InfoCommand;

public class InfoDiscordCommand extends InfoCommand {
    @Override
    public void execute(CommandExecutorProperties properties) {
        super.execute(properties);
    }
}
