package org.slogga.habboscanner.utils;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import org.slogga.habboscanner.HabboScanner;

import org.slogga.habboscanner.logic.game.HabboActions;

public class ActionMapGenerator {
    public static Map<Character, Runnable> generateActionMapFromValue(String value) {
        Map<Character, Runnable> actions = new HashMap<>();

        if (value.length() <= 2)
            return actions;

        String message = value.substring(2, value.length() - 1);

        populateActions(actions, message);

        return actions;
    }

    private static void populateActions(Map<Character, Runnable> actions, String message) {
        int consoleUserId = HabboScanner.getInstance()
                .getConfigurator()
                .getConsoleHandlers()
                .getUserId();

        actions.put('s', () -> HabboActions.sendAvatarExpression(1));
        actions.put('m', () -> HabboActions.sendMessage(consoleUserId, message));
        actions.put('b', () -> HabboActions.dance(1));

        Optional<Integer> signId = parseSignId(message);

        signId.ifPresent(id -> actions.put('c', () -> HabboActions.sign(id)));
    }

    private static Optional<Integer> parseSignId(String message) {
        try {
            return Optional.of(Integer.parseInt(message));
        } catch (NumberFormatException ignored) {
            return Optional.empty();
        }
    }
}
