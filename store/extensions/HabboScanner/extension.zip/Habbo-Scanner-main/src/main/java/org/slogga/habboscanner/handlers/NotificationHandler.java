package org.slogga.habboscanner.handlers;

import java.util.Arrays;
import java.util.List;

import gearth.protocol.HMessage;

import org.slogga.habboscanner.logic.commands.CommandFactory;
import org.slogga.habboscanner.logic.game.console.commands.LiveConsoleCommand;

import org.slogga.habboscanner.models.enums.CommandKeys;

public class NotificationHandler {
    public void onNotificationDialog(HMessage message) {
        LiveConsoleCommand liveConsoleCommand = (LiveConsoleCommand) CommandFactory.getCommandExecutor()
                .getCommands().get(CommandKeys.LIVE.getKey());
        if (!liveConsoleCommand.isLiveMode()) return;

        List<String> blockedErrors = Arrays.asList("builders_club.visit_denied_for_visitor",
                "room_entry.frozen_mode", "room.kick.cannonball");
        String errorMessage = message.getPacket().readString();

        if (!blockedErrors.contains(errorMessage)) return;

        message.setBlocked(true);
    }
}
