package org.slogga.habboscanner.logic.commands.common.start.modes.bot_per_groups_id;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.slogga.habboscanner.logic.commands.common.start.modes.bot_per_groups_id.order_actions.*;

import org.slogga.habboscanner.models.enums.IdOrder;

public class GroupActionOrderFactory {
    private static final Logger logger = LoggerFactory.getLogger(GroupActionOrderFactory.class);

    public static IGroupActionOrder getOrderAction(IdOrder order, int groupId) {
        switch (order) {
            case ASC:
                return new AscActionOrder(groupId);
            case DESC:
                return new DescActionOrder(groupId);
            default:
                logger.error("Invalid order: {}", order);
        }

        return null;
    }
}

