package org.slogga.habboscanner.handlers.room;

import java.util.Map;

import gearth.protocol.HMessage;
import gearth.protocol.HPacket;

import lombok.Getter;

import org.slogga.habboscanner.HabboScanner;
import org.slogga.habboscanner.dao.mysql.rooms.RoomsDAO;

import org.slogga.habboscanner.logic.commands.Command;
import org.slogga.habboscanner.logic.commands.common.follow.FollowCommand;

import org.slogga.habboscanner.logic.game.HabboActions;

import org.slogga.habboscanner.logic.commands.CommandFactory;
import org.slogga.habboscanner.logic.commands.common.start.StartCommand;

import org.slogga.habboscanner.logic.game.console.commands.FollowConsoleCommand;
import org.slogga.habboscanner.models.room.RoomDetails;

import org.slogga.habboscanner.models.enums.CommandKeys;
import org.slogga.habboscanner.models.enums.RoomAccessMode;

import org.slogga.habboscanner.utils.UTF8Utils;

@Getter
public class RoomDetailsHandlers {
    private RoomDetails roomDetails;

    public void onGetGuestRoomResult(HMessage message) {
        processDetails(message.getPacket());

        handleRoomAccessMode(message);
    }

    public void onRoomVisualizationSettings() {
        Map<String, Command> commands = CommandFactory.getCommandExecutor().getCommands();
        StartCommand startCommand = (StartCommand) commands.get(CommandKeys.START.getKey());
        FollowCommand followCommand = (FollowCommand) commands.get(CommandKeys.FOLLOW.getKey());

        boolean isBotInActiveRooms = Boolean.parseBoolean(HabboScanner.getInstance()
                .getConfigurator()
                .getProperties()
                .get("bot")
                .getProperty("bot.in.active.rooms"));

        if (!startCommand.isBotRunning() || followCommand.isFollowing() || !isBotInActiveRooms) return;

        HabboActions.goToHotelView();
    }

    private void processDetails(HPacket packet) {
        boolean unknownMessage1 = packet.readBoolean();
        int guestRoomId = packet.readInteger();
        String roomName = UTF8Utils.convertToUTF8(packet.readString());
        int ownerId = packet.readInteger();
        String currentOwnerName = UTF8Utils.convertToUTF8(packet.readString());

        RoomsDAO.insertRoom(guestRoomId, roomName, ownerId, currentOwnerName);
        RoomAccessMode roomAccessMode = RoomAccessMode.fromValue(packet.readInteger());

        roomDetails = new RoomDetails(guestRoomId, roomName, ownerId, currentOwnerName, roomAccessMode);
    }

    private void handleRoomAccessMode(HMessage message) {
        FollowConsoleCommand followConsoleCommand = (FollowConsoleCommand) CommandFactory.getCommandExecutor()
                .getCommands().get(CommandKeys.FOLLOW.getKey());

        if (!followConsoleCommand.isFollowing() || roomDetails.getRoomAccessMode() != RoomAccessMode.LOCKED) return;

        followConsoleCommand.notifyUserOnRoomStatus(message, "closed.room.access.message");
    }
}
