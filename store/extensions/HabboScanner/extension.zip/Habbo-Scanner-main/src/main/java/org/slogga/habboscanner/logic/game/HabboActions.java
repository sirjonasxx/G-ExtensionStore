package org.slogga.habboscanner.logic.game;

import gearth.protocol.HMessage;
import gearth.protocol.HPacket;

import org.slogga.habboscanner.HabboScanner;

import org.slogga.habboscanner.logic.commands.CommandFactory;
import org.slogga.habboscanner.logic.game.console.commands.channel.ChannelConsoleCommand;

import org.slogga.habboscanner.models.enums.CommandKeys;
import org.slogga.habboscanner.models.enums.MessageChannel;

public class HabboActions {
    public static void moveToRoom(int roomId) {
        HPacket packet = new HPacket("GetGuestRoom", HMessage.Direction.TOSERVER,
                roomId, 0, 1);

        HabboScanner.getInstance().sendToServer(packet);
    }

    public static void sendMessage(int userId, String message) {
        ChannelConsoleCommand channelConsoleCommand = (ChannelConsoleCommand) CommandFactory.getCommandExecutor()
                .getCommands().get(CommandKeys.CHANNEL.getKey());
        MessageChannel channel = channelConsoleCommand.getChannel();

        switch (channel) {
            case CHAT: {
                shoutMessage(message);

                break;
            }

            case CONSOLE: {
                sendPrivateMessage(userId, message);

                break;
            }
        }
    }

    public static void whisperMessage(String text) {
        HPacket packet = new HPacket("Whisper", HMessage.Direction.TOCLIENT,
                -1, text, 0, 30, 0, -1);

        HabboScanner.getInstance().sendToClient(packet);
    }

    public static void sendNavigatorSearch(String searchType, String searchValue) {
        HPacket packet = new HPacket("NewNavigatorSearch",
                HMessage.Direction.TOSERVER, searchType, searchValue);

        HabboScanner.getInstance().sendToServer(packet);
    }

    public static void followFriend(int friendId) {
        HPacket packet = new HPacket("FollowFriend",
                HMessage.Direction.TOSERVER, friendId);

        HabboScanner.getInstance().sendToServer(packet);
    }

    public static void sendAvatarExpression(int expressionId) {
        HPacket packet = new HPacket("AvatarExpression",
                HMessage.Direction.TOSERVER, expressionId);

        HabboScanner.getInstance().sendToServer(packet);
    }

    public static void goToHotelView() {
        HPacket packet = new HPacket("Quit", HMessage.Direction.TOSERVER,
                1);

        HabboScanner.getInstance().sendToServer(packet);
    }

    public static void dance(int danceId) {
        HPacket packet = new HPacket("Dance", HMessage.Direction.TOSERVER, danceId);

        HabboScanner.getInstance().sendToServer(packet);
    }

    public static void sign(int signId) {
        HPacket packet = new HPacket("Sign", HMessage.Direction.TOSERVER, signId);

        HabboScanner.getInstance().sendToServer(packet);
    }

    public static void sendPrivateMessage(int userId, String message) {
        HPacket packet = new HPacket("SendMsg", HMessage.Direction.TOSERVER,
                userId, message);

        HabboScanner.getInstance().sendToServer(packet);
    }


    public static void joinGroup(int groupId) {
        HPacket packet = new HPacket("JoinHabboGroup", HMessage.Direction.TOSERVER, groupId);

        HabboScanner.getInstance().sendToServer(packet);
    }

    public static void leaveGroup(int groupId, int userId) {
        HPacket packet = new HPacket("KickMember", HMessage.Direction.TOSERVER, groupId, userId, false);

        HabboScanner.getInstance().sendToServer(packet);
    }

    public static void requestHabboGroupDetails(int groupId) {
        HPacket packet = new HPacket("GetHabboGroupDetails", HMessage.Direction.TOSERVER,
                groupId, true);

        HabboScanner.getInstance().sendToServer(packet);
    }

    private static void shoutMessage(String message) {
        HPacket packet = new HPacket("Shout", HMessage.Direction.TOSERVER,
                message, 0);

        HabboScanner.getInstance().sendToServer(packet);
    }
}
