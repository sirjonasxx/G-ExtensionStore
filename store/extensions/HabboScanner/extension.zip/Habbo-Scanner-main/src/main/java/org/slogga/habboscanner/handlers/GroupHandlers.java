package org.slogga.habboscanner.handlers;

import java.util.Map;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import gearth.protocol.HMessage;
import gearth.protocol.HPacket;

import lombok.Getter;
import lombok.Setter;

import org.slogga.habboscanner.HabboScanner;

import org.slogga.habboscanner.logic.commands.Command;
import org.slogga.habboscanner.logic.commands.CommandFactory;
import org.slogga.habboscanner.logic.commands.common.EnergySavingCommand;
import org.slogga.habboscanner.logic.commands.common.start.StartCommand;

import org.slogga.habboscanner.logic.configurators.HabboScannerConfigurator;

import org.slogga.habboscanner.logic.game.HabboActions;
import org.slogga.habboscanner.logic.game.console.commands.LiveConsoleCommand;

import org.slogga.habboscanner.models.enums.CommandKeys;
import org.slogga.habboscanner.models.enums.GroupStatus;

@Getter
@Setter
public class GroupHandlers {
    private int groupId;
    private boolean isProcessingGroup = false;

    public void onHabboGroupDetails(HMessage message) {
        if (!shouldProcessMessage()) return;

        blockMessageIfEnergySavingMode(message);

        HPacket packet = message.getPacket();
        groupId = packet.readInteger();

        boolean isNew = packet.readBoolean();
        GroupStatus status = GroupStatus.fromValue(packet.readInteger());
        String unknownVariable1 = packet.readString();
        String unknownVariable2 = packet.readString();
        String unknownVariable3 = packet.readString();
        int roomId = packet.readInteger();

        if (shouldReturnEarly(roomId, isNew, status)) {
            isProcessingGroup = false;

            return;
        }

        isProcessingGroup = true;

        HabboActions.joinGroup(groupId);

        ScheduledExecutorService executorService = Executors.newSingleThreadScheduledExecutor();
        executorService.schedule(() -> HabboActions.moveToRoom(roomId), 4, TimeUnit.SECONDS);
    }

    public void onHabboGroupJoinFailed(HMessage message) {
        LiveConsoleCommand liveConsoleCommand = (LiveConsoleCommand) CommandFactory.getCommandExecutor()
                .getCommands().get(CommandKeys.LIVE.getKey());
        if (!liveConsoleCommand.isLiveMode()) return;

        message.setBlocked(true);
    }

    private boolean shouldProcessMessage() {
        Map<String, Command> commands = CommandFactory.getCommandExecutor().getCommands();
        StartCommand startCommand = (StartCommand) commands.get(CommandKeys.START.getKey());

        HabboScannerConfigurator configurator = HabboScanner.getInstance().getConfigurator();

        boolean isBotRunning = startCommand.isBotRunning();
        boolean botPerGroupsId = Boolean.parseBoolean(configurator.getProperties().get("bot")
                .getProperty("bot.per.groups.id"));

        return isBotRunning && botPerGroupsId;
    }

    private void blockMessageIfEnergySavingMode(HMessage message) {
        EnergySavingCommand energySavingCommand = (EnergySavingCommand) CommandFactory.getCommandExecutor().getCommands()
                .get(CommandKeys.ENERGY_SAVING.getKey());
        if (!energySavingCommand.isEnergySavingMode()) return;

        message.setBlocked(true);
    }

    private boolean shouldReturnEarly(int roomId, boolean isNew, GroupStatus status) {
        int currentRoomId = HabboScanner.getInstance().getConfigurator().getRoomEntryHandlers().getRoomId();

        return roomId == currentRoomId || !isNew || status != GroupStatus.OPEN;
    }
}
