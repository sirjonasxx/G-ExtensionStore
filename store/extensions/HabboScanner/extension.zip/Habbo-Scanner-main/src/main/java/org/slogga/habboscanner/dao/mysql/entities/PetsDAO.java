package org.slogga.habboscanner.dao.mysql.entities;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slogga.habboscanner.dao.Database;

import org.slogga.habboscanner.models.habbo_entities.HabboPet;

public class PetsDAO {
    private static final Logger logger = LoggerFactory.getLogger(PetsDAO.class);

    public static void insertPet(HabboPet pet, int roomId, String extradata) {
        String query = "INSERT IGNORE INTO `pets` (`id`, `name`, `room_id`, `extra_data`) VALUES (?, ?, ?, ?)";

        try (Connection connection = Database.getInstance().getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, pet.getId());
            statement.setString(2, pet.getName());
            statement.setInt(3, roomId);
            statement.setString(4, extradata);

            statement.execute();
        } catch (SQLException exception) {
            logger.error(exception.getMessage());
        }
    }
}
