package org.slogga.habboscanner.logic.commands.common.follow.actions;

import java.time.Instant;
import java.time.temporal.ChronoUnit;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

import org.slogga.habboscanner.logic.commands.CommandFactory;
import org.slogga.habboscanner.logic.commands.common.follow.FollowCommand;
import org.slogga.habboscanner.logic.commands.common.follow.IFollower;
import org.slogga.habboscanner.logic.game.HabboActions;

import org.slogga.habboscanner.HabboScanner;
import org.slogga.habboscanner.models.enums.CommandKeys;
import org.slogga.habboscanner.models.enums.FollowingAction;

public class AuctionFollowing implements IFollower {
    @Override
    public void execute() {
        int consoleUserId = HabboScanner.getInstance().getConfigurator().getConsoleHandlers().getUserId();
        String followingAuctionMessage = HabboScanner.getInstance().getConfigurator()
                .getProperties().get("message").getProperty("following.auction.message");

        HabboActions.sendMessage(consoleUserId, followingAuctionMessage);

        ScheduledExecutorService executorService = Executors.newSingleThreadScheduledExecutor();
        AtomicReference<Instant> lastMessageTime = new AtomicReference<>(Instant.now());

        executorService.scheduleAtFixedRate(() -> {
            long differenceInMinutes = ChronoUnit.MINUTES.between(lastMessageTime.get(), Instant.now());

            FollowCommand followCommand = (FollowCommand) CommandFactory.getCommandExecutor()
                    .getCommands().get(CommandKeys.FOLLOW.getKey());
            boolean isAuctionFollowing = followCommand.getFollowingAction() == FollowingAction.AUCTION;

            if (differenceInMinutes <= 13 || !isAuctionFollowing) return;

            // Wave for anti AFK.
            HabboActions.sendAvatarExpression(1);

            lastMessageTime.set(Instant.now());
        }, 0, 1, TimeUnit.SECONDS);
    }
}
