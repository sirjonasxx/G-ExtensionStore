package org.slogga.habboscanner.logic.commands.common.follow;

import lombok.Data;

import org.slogga.habboscanner.HabboScanner;

import org.slogga.habboscanner.logic.commands.Command;
import org.slogga.habboscanner.logic.commands.CommandExecutorProperties;
import org.slogga.habboscanner.logic.commands.CommandFactory;

import org.slogga.habboscanner.logic.commands.common.start.StartCommand;
import org.slogga.habboscanner.logic.configurators.HabboScannerConfigurator;
import org.slogga.habboscanner.logic.game.HabboActions;

import org.slogga.habboscanner.models.enums.CommandKeys;
import org.slogga.habboscanner.models.enums.FollowingAction;
import org.slogga.habboscanner.models.enums.SourceType;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

@Data
public abstract class FollowCommand implements Command {
    protected FollowingAction followingAction;

    protected boolean isFollowing;
    protected SourceType sourceType;

    public FollowCommand() {
        this.isFollowing = false;
    }

    @Override
    public void execute(CommandExecutorProperties properties) {
        HabboScannerConfigurator configurator = HabboScanner.getInstance().getConfigurator();

        if (isFollowing) {
            String tooManyCallsMessage = configurator.getProperties()
                    .get("message").getProperty("follow.too.many.calls");
            CommandFactory.getCommandExecutor().sendMessage(tooManyCallsMessage, properties);

            return;
        }

        StartCommand startCommand = (StartCommand) CommandFactory.getCommandExecutor().
                getCommands().get(CommandKeys.START.getKey());
        if (!startCommand.isBotRunning()) return;

        startCommand.setBotRunning(false);

        int userId = properties.getUserId();
        String followCallMessage = configurator.getProperties()
                .get("message").getProperty("follow.call.message");

        HabboActions.sendPrivateMessage(userId, followCallMessage);

        ScheduledExecutorService executorService = Executors.newSingleThreadScheduledExecutor();
        executorService.schedule(() -> {
            isFollowing = true;
            HabboActions.followFriend(userId);

            configurator.getRoomEntryHandlers().refreshLastRoomAccess();
        }, 2, TimeUnit.SECONDS);
    }

    public void initiateBotAndRefreshRoomAccess() {
        StartCommand startCommand = (StartCommand) CommandFactory.getCommandExecutor()
                .getCommands().get(CommandKeys.START.getKey());

        startCommand.setBotRunning(true);
        isFollowing = false;

        HabboScanner.getInstance()
                .getConfigurator()
                .getRoomEntryHandlers().refreshLastRoomAccess();
    }

    @Override
    public String getDescription() {
        return HabboScanner.getInstance().getConfigurator()
                .getProperties().get("command_description")
                .getProperty("follow.command.description");
    }
}

