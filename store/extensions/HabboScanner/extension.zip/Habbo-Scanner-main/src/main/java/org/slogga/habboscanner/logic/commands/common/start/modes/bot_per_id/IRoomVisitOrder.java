package org.slogga.habboscanner.logic.commands.common.start.modes.bot_per_id;

public interface IRoomVisitOrder {
    int getNextRoomId();
}
