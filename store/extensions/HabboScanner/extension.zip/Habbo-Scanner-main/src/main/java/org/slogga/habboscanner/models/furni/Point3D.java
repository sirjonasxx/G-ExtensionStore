package org.slogga.habboscanner.models.furni;

import lombok.Getter;

@Getter
public final class Point3D {
    private final int x;
    private final int y;
    private final double z;

    public Point3D(int x, int y, double z) {
        this.x = x;
        this.y = y;
        this.z = z;
    }

    @Override
    public String toString() {
        return "Point3D[" +
                "x=" + x + ", " +
                "y=" + y + ", " +
                "z=" + z + ']';
    }

}

