package org.slogga.habboscanner.logic.commands.common.start.modes.bot_per_groups_id.order_actions;

import org.slogga.habboscanner.logic.commands.common.start.modes.bot_per_groups_id.IGroupActionOrder;

import java.util.concurrent.atomic.AtomicInteger;

public class DescActionOrder implements IGroupActionOrder {
    private final AtomicInteger groupId;

    public DescActionOrder(int initialGroupId) {
        this.groupId = new AtomicInteger(initialGroupId);
    }

    @Override
    public int getNextGroupId() {
        return groupId.getAndDecrement();
    }
}
