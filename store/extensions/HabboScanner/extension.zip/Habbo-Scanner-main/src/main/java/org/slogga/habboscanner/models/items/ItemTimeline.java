package org.slogga.habboscanner.models.items;

import java.sql.Date;

import lombok.Getter;

@Getter
public final class ItemTimeline {
    private final int id;
    private final Date date;
    private final String type;

    public ItemTimeline(int id, Date date, String type) {
        this.id = id;
        this.date = date;
        this.type = type;
    }

    @Override
    public String toString() {
        return "ItemTimeline[" +
                "id=" + id + ", " +
                "date=" + date + ", " +
                "type=" + type + ']';
    }

}