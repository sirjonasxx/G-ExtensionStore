package org.slogga.habboscanner.logic.commands.common.start.modes.bot_per_groups_id;

import java.util.Map;

import java.util.Properties;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.slogga.habboscanner.HabboScanner;

import org.slogga.habboscanner.logic.commands.CommandExecutorProperties;
import org.slogga.habboscanner.logic.commands.common.start.IStarter;

import org.slogga.habboscanner.logic.game.HabboActions;

import org.slogga.habboscanner.models.enums.IdOrder;

public class StartBotPerGroupsId implements IStarter {
    private final Logger logger = LoggerFactory.getLogger(StartBotPerGroupsId.class);

    @Override
    public void execute(CommandExecutorProperties properties) {
        Map<String, Properties> propertiesMap =  HabboScanner.getInstance().getConfigurator().getProperties();
        String groupStartModeMessage = propertiesMap.get("message").getProperty("group.start.mode.message");
        HabboActions.sendPrivateMessage(properties.getUserId(), groupStartModeMessage);

        String botPerIdOrder = propertiesMap.get("bot").getProperty("bot.per.id.order");
        IdOrder order = IdOrder.fromValue(botPerIdOrder);
        int groupId = Integer.parseInt(propertiesMap.get("bot").getProperty("bot.starter.group.id"));

        ScheduledExecutorService executorService = Executors.newSingleThreadScheduledExecutor();
        IGroupActionOrder actionOrder = GroupActionOrderFactory.getOrderAction(order, groupId);

        executorService.scheduleAtFixedRate(createBotTask(actionOrder), 0, 1, TimeUnit.SECONDS);
    }

    private Runnable createBotTask(IGroupActionOrder strategy) {
        return () -> {
            boolean isProcessingGroup = HabboScanner.getInstance().getConfigurator()
                    .getGroupHandlers().isProcessingGroup();
            if (isProcessingGroup) return;

            int nextGroupId = strategy.getNextGroupId();
            logger.info("I am requesting group id: {}", nextGroupId);
            HabboActions.requestHabboGroupDetails(nextGroupId);
        };
    }
}
