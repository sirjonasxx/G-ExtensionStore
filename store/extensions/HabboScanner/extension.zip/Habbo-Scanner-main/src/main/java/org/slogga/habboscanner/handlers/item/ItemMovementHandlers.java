package org.slogga.habboscanner.handlers.item;

import java.sql.Date;
import java.sql.Timestamp;

import org.apache.commons.lang3.tuple.Triple;

import lombok.Getter;

import gearth.protocol.HMessage;

import org.slogga.habboscanner.dao.mysql.items.ItemsTimelineDAO;

import org.slogga.habboscanner.logic.commands.CommandFactory;
import org.slogga.habboscanner.logic.commands.common.follow.FollowCommand;

import org.slogga.habboscanner.logic.game.HabboActions;

import org.slogga.habboscanner.logic.game.furni.FurniHistoricalInfoBroadcaster;

import org.slogga.habboscanner.models.enums.CommandKeys;
import org.slogga.habboscanner.models.enums.FollowingAction;
import org.slogga.habboscanner.models.enums.FurnitypeEnum;

import org.slogga.habboscanner.HabboScanner;

import org.slogga.habboscanner.models.items.ItemTimeline;

import org.slogga.habboscanner.utils.DateUtils;

public class ItemMovementHandlers {
    @Getter
    private final FurniHistoricalInfoBroadcaster furniHistoricalInfoBroadcaster = new FurniHistoricalInfoBroadcaster();

    private long lastMovedTime = 0;

    private static final int MOVE_DELAY_IN_MILLISECONDS = 15 * 1000; // 15 seconds.

    public void onMoveWallItem(HMessage message) {
        handleMoveItem(message, FurnitypeEnum.WALL);
    }

    public void onMoveFurni(HMessage message) {
        handleMoveItem(message, FurnitypeEnum.FLOOR);
    }

    private void handleMoveItem(HMessage message, FurnitypeEnum type) {
        if (!shouldHandleMoveItem()) return;

        int id = getItemId(message, type);
        if (id > 999999999) return;

        if (!isMoveDelayElapsed()) return;

        Date estimatedDate = getEstimatedDate(type, id);
        if (isDefaultDate(estimatedDate)) return;

        broadcastFurniHistoryDetails(id, type, estimatedDate);
    }

    private boolean shouldHandleMoveItem() {
        FollowCommand followCommand = (FollowCommand) CommandFactory.getCommandExecutor()
                .getCommands()
                .get(CommandKeys.FOLLOW.getKey());

        return followCommand.isFollowing() && followCommand.getFollowingAction() == FollowingAction.INFO;
    }

    private int getItemId(HMessage message, FurnitypeEnum type) {
        switch (type) {
            case WALL:
                return Integer.parseInt(message.getPacket().readString());
            case FLOOR:
                return message.getPacket().readInteger();
            default:
                throw new IllegalArgumentException();
        }
    }

    private boolean isMoveDelayElapsed() {
        long currentTime = System.currentTimeMillis();
        boolean elapsed = currentTime - lastMovedTime >= MOVE_DELAY_IN_MILLISECONDS;

        if (elapsed)
            lastMovedTime = currentTime;

        return elapsed;
    }

    private Date getEstimatedDate(FurnitypeEnum type, int id) {
        Triple<Integer, ItemTimeline, ItemTimeline> closestEntries = ItemsTimelineDAO.selectClosestEntries(id, type);

        return DateUtils.getLinearInterpolatedDate(closestEntries);
    }

    private boolean isDefaultDate(Date date) {
        if (String.valueOf(date).equals("1970-01-01")) {
            int consoleUserId = HabboScanner.getInstance().getConfigurator().getConsoleHandlers().getUserId();
            String furniDateCalculationErrorMessage = HabboScanner.getInstance()
                    .getConfigurator()
                    .getProperties()
                    .get("message")
                    .getProperty("furni.date.calculation.error.message");

            HabboActions.sendMessage(consoleUserId, furniDateCalculationErrorMessage);

            return true;
        }

        return false;
    }

    private void broadcastFurniHistoryDetails(int id, FurnitypeEnum type, Date estimatedDate) {
        Timestamp timestamp = new Timestamp(estimatedDate.getTime());
        String formattedDate = DateUtils.formatTimestampToDate(timestamp);
        int consoleUserId = HabboScanner.getInstance().getConfigurator().getConsoleHandlers().getUserId();

        furniHistoricalInfoBroadcaster.broadcastFurniHistoryDetails(id, type, formattedDate, consoleUserId);
    }
}

