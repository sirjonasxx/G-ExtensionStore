package org.slogga.habboscanner.utils;

import java.sql.Date;
import java.sql.Timestamp;

import java.text.SimpleDateFormat;

import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;

import org.apache.commons.lang3.tuple.Triple;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.slogga.habboscanner.models.items.ItemTimeline;

public class DateUtils {
    private static final Logger logger = LoggerFactory.getLogger(DateUtils.class);

    public static Date getLinearInterpolatedDate(Triple<Integer, ItemTimeline, ItemTimeline> closestEntries) {
        int id = closestEntries.getLeft();

        int lowestId = closestEntries.getMiddle().getId();
        Date lowestDate = closestEntries.getMiddle().getDate();

        int highestId = closestEntries.getRight().getId();
        Date highestDate = closestEntries.getRight().getDate();

        long rise = highestDate.getTime() - lowestDate.getTime();
        int run = highestId - lowestId;

        if (run == 0) {
            logger.error("An error has occurred due to a division by zero. " +
                    "This typically happens when the items timeline is not properly configured. " +
                    "To resolve this issue, please ensure that your MySQL server has the necessary data populated.");

            return null;
        }

        long milliseconds = lowestDate.getTime() + (rise / run) * (id - lowestId);

        return new Date(milliseconds);
    }

    public static String formatTimestampToDate(Timestamp timestamp) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("d MMMM yyyy");

        return dateFormat.format(timestamp);
    }

    public static String getCurrentDateTime() {
        ZonedDateTime now = ZonedDateTime.now(ZoneId.systemDefault());
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

        return now.format(formatter);
    }
}
