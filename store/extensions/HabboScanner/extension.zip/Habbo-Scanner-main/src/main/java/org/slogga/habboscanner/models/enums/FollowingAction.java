package org.slogga.habboscanner.models.enums;

import java.util.Arrays;
import java.util.Objects;

import lombok.Getter;

@Getter
public enum FollowingAction {
    DEFAULT(""),
    INFO("info"),
    AUCTION("auction");

    public static FollowingAction fromValue(String value) {
        return Arrays.stream(FollowingAction.values())
                .filter(mode -> Objects.equals(mode.getAction(), value))
                .findFirst()
                .orElse(null);
    }

    private final String action;

    FollowingAction(String action) {
        this.action = action;
    }
}
