package org.slogga.habboscanner.dao.mysql.items;

import org.apache.commons.lang3.tuple.Triple;

import java.sql.*;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slogga.habboscanner.dao.Database;

import org.slogga.habboscanner.models.enums.FurnitypeEnum;
import org.slogga.habboscanner.models.items.ItemTimeline;

public class ItemsTimelineDAO {
    private static final Logger logger = LoggerFactory.getLogger(ItemsTimelineDAO.class);

    public static Triple<Integer, ItemTimeline, ItemTimeline> selectClosestEntries(Integer searchableId, FurnitypeEnum type) {
        String query = "SELECT * from items_timeline WHERE id IN "
                + "((SELECT MAX(id) FROM items_timeline WHERE type = ? AND id < ?), "
                + "(SELECT MIN(id) FROM items_timeline WHERE type = ? AND id >= ?)) AND type = ?";

        try (Connection connection = Database.getInstance().getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, type.getTypeName());
            statement.setInt(2, searchableId);
            statement.setString(3, type.getTypeName());
            statement.setInt(4, searchableId);
            statement.setString(5, type.getTypeName());

            try (ResultSet resultSet = statement.executeQuery()) {
                ItemTimeline minimumEntry = null;
                ItemTimeline maximumEntry = null;

                while (resultSet.next()) {
                    int id = resultSet.getInt("id");
                    Date date = resultSet.getDate("date");

                    ItemTimeline itemTimeline = new ItemTimeline(id, date, type.getTypeName());

                    minimumEntry = (minimumEntry == null) ? itemTimeline : minimumEntry;
                    maximumEntry = itemTimeline;
                }

                return Triple.of(searchableId, minimumEntry, maximumEntry);
            }
        } catch (SQLException exception) {
            logger.error(exception.getMessage());
        }

        return null;
    }
}