package org.slogga.habboscanner.logic.game.entities;

import java.util.Arrays;
import java.util.stream.Collectors;

import gearth.extensions.parsers.HEntity;
import gearth.extensions.parsers.HEntityType;

import org.slogga.habboscanner.dao.mysql.entities.BotsDAO;

import org.slogga.habboscanner.models.habbo_entities.HabboBot;

import org.slogga.habboscanner.utils.UTF8Utils;

public class BotEntity extends BaseEntity {
    public BotEntity(HEntity entity, int roomId) {
        super(entity, roomId);
    }

    @Override
    public void processEntity() {
        Object[] rawExtradata = entity.getStuff();
        String extradata = Arrays.stream(rawExtradata)
                .map(Object::toString)
                .collect(Collectors.joining(", "));

        extradata = UTF8Utils.convertToUTF8(extradata);

        HabboBot bot = new HabboBot(entity.getId(), entity.getName(), entity.getMotto(),
                entity.getFigureId(), entity.getFigureId(), entity.getEntityType() == HEntityType.OLD_BOT);
        BotsDAO.insertBot(bot, roomId, extradata);
    }
}