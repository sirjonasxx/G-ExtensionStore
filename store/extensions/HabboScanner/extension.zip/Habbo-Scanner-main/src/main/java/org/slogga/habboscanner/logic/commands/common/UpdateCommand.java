package org.slogga.habboscanner.logic.commands.common;

import org.slogga.habboscanner.HabboScanner;

import org.slogga.habboscanner.dao.mysql.items.ItemsDAO;

import org.slogga.habboscanner.logic.commands.Command;
import org.slogga.habboscanner.logic.commands.CommandExecutorProperties;
import org.slogga.habboscanner.logic.commands.CommandFactory;

public class UpdateCommand implements Command {
    @Override
    public void execute(CommandExecutorProperties properties) {
        HabboScanner.getInstance().getConfigurator().loadProperty("bot");
        HabboScanner.getInstance().getFurnidataConfigurator().setItems(ItemsDAO.fetchItems());

        String updateInformationMessage = HabboScanner.getInstance()
                .getConfigurator()
                .getProperties()
                .get("message")
                .getProperty("update.completed.message");

        CommandFactory.getCommandExecutor().sendMessage(updateInformationMessage, properties);
    }

    @Override
    public String getDescription() {
        return HabboScanner.getInstance().getConfigurator().getProperties().get("command_description")
                .getProperty("update.command.description");
    }
}
