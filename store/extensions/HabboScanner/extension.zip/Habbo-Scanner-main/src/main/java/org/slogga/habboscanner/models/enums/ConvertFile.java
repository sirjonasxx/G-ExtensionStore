package org.slogga.habboscanner.models.enums;

import java.util.Arrays;
import java.util.Objects;

import lombok.Getter;

@Getter
public enum ConvertFile {
    ITEMS("items"),
    ITEMS_TIMELINE("items_timeline");

    public static ConvertFile fromValue(String value) {
        return Arrays.stream(ConvertFile.values())
                .filter(mode -> Objects.equals(mode.getFileName(), value))
                .findFirst()
                .orElse(null);
    }

    private final String fileName;

    ConvertFile(String fileName) {
        this.fileName = fileName;
    }
}
