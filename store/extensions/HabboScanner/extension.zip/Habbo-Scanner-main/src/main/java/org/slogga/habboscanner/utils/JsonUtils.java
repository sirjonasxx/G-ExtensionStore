package org.slogga.habboscanner.utils;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;

import java.util.Optional;

public class JsonUtils {
    private static final Logger logger = LoggerFactory.getLogger(JsonUtils.class);

    public static String fetchJson(String url) {
        OkHttpClient client = new OkHttpClient();
        Request request = new Request.Builder()
                .url(url)
                .build();

        try (Response response = client.newCall(request).execute()) {
            return Optional.ofNullable(response.body())
                    .map(body -> {
                        try {
                            return body.string();
                        } catch (IOException exception) {
                            logger.error(exception.getMessage());
                        }

                        return "";
                    })
                    .orElse("");
        } catch (IOException exception) {
            logger.error(exception.getMessage());
        }

        return url;
    }
}

