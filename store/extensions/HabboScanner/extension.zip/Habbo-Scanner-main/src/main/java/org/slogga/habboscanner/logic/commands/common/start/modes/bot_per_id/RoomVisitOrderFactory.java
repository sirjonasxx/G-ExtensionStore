package org.slogga.habboscanner.logic.commands.common.start.modes.bot_per_id;

import org.slogga.habboscanner.models.enums.IdOrder;

import org.slogga.habboscanner.logic.commands.common.start.modes.bot_per_id.orders.*;

public class RoomVisitOrderFactory {
    public static IRoomVisitOrder getOrderStrategy(IdOrder order, int initialRoomId) {
        switch (order) {
            case ASC:
                return new AscVisitOrder(initialRoomId);
            case DESC:
                return new DescVisitOrder(initialRoomId);
            case RANDOM:
                return new RandomVisitOrder();
            default:
                throw new IllegalArgumentException();
        }
    }
}
