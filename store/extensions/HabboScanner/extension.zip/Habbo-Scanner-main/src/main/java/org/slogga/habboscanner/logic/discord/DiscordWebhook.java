package org.slogga.habboscanner.logic.discord;

import java.io.IOException;
import java.util.Optional;

import okhttp3.*;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.slogga.habboscanner.HabboScanner;

public class DiscordWebhook {
    private static final MediaType JSON = MediaType.get("application/json; charset=utf-8");
    private static final OkHttpClient client = new OkHttpClient();

    private static final Logger logger = LoggerFactory.getLogger(DiscordWebhook.class);

    public static void sendDiscordEmbedMessage(String title, String description, int hex,
                                               String thumbnailUrl, String iconUrl, String footerText, String imageUrl) {
        boolean isDiscordWebhookEnabled = Boolean.parseBoolean(HabboScanner.getInstance()
                .getConfigurator()
                .getProperties()
                .get("discord").getProperty("discord.webhook.enabled"));

        if (!isDiscordWebhookEnabled) return;

        String url = HabboScanner.getInstance()
                .getConfigurator()
                .getProperties()
                .get("discord").getProperty("discord.webhook.url");

        String json = "{"
                + "\"embeds\": ["
                + "{"
                + "\"title\": \"" + title + "\","
                + "\"description\": \"" + description + "\","
                + "\"color\": " + hex + ","
                + "\"thumbnail\": {\"url\": \"" + thumbnailUrl + "\"},"
                + "\"footer\": {\"text\": \"" + footerText + "\", " +
                "\"icon_url\": \"" + iconUrl + "\"}";

        if (imageUrl != null)
            json += ",\"image\": {\"url\": \"" + imageUrl + "\"}";

        json += "}"
                + "]"
                + "}";

        RequestBody body = RequestBody.create(json, JSON);
        Request request = new Request.Builder()
                .url(url)
                .post(body)
                .build();

        try {
            Response response = client.newCall(request).execute();
            Optional<Response> optionalResponse = Optional.of(response);

            optionalResponse.filter(Response::isSuccessful).orElseThrow(() ->
                    new IOException("Unexpected code " + response));
        } catch (IOException exception) {
            logger.error(exception.getMessage());
        }
    }
}
