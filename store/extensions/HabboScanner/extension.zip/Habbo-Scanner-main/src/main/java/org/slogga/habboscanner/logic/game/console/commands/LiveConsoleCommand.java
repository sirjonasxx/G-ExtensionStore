package org.slogga.habboscanner.logic.game.console.commands;

import lombok.Getter;

import org.slogga.habboscanner.HabboScanner;

import org.slogga.habboscanner.logic.commands.Command;
import org.slogga.habboscanner.logic.commands.CommandExecutorProperties;

import org.slogga.habboscanner.logic.game.HabboActions;

@Getter
public class LiveConsoleCommand implements Command {
    private boolean liveMode = false;

    @Override
    public void execute(CommandExecutorProperties properties) {
        properties.getMessage().setBlocked(true);

        liveMode = !liveMode;

        String statusKey = liveMode ? "live.mode.enabled" : "live.mode.disabled";
        String message = HabboScanner.getInstance().getConfigurator()
                .getProperties().get("message").getProperty(statusKey);

        HabboActions.sendMessage(properties.getUserId(), message);
    }

    @Override
    public String getDescription() {
        return HabboScanner.getInstance().getConfigurator().getProperties().get("command_description")
                .getProperty("live.command.description");
    }
}
