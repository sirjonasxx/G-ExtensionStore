package org.slogga.habboscanner.logic.commands.common.follow;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Supplier;

import org.slogga.habboscanner.logic.commands.common.follow.actions.*;

import org.slogga.habboscanner.models.enums.FollowingAction;

public class FollowingActionFactory {
    private static final Map<FollowingAction, Supplier<IFollower>> actionMap = new HashMap<>();

    static {
        actionMap.put(FollowingAction.DEFAULT, DefaultFollowing::new);
        actionMap.put(FollowingAction.INFO, FurniInfoFollowing::new);
        actionMap.put(FollowingAction.AUCTION, AuctionFollowing::new);
    }

    public static IFollower getFollowingActionStrategy(FollowingAction action) {
        Supplier<IFollower> modeSupplier = actionMap.getOrDefault(action, actionMap.get(FollowingAction.DEFAULT));

        return modeSupplier.get();
    }
}
