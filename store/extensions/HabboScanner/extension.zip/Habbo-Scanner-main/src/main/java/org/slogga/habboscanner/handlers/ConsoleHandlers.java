package org.slogga.habboscanner.handlers;

import java.util.*;

import gearth.protocol.HMessage;

import lombok.Data;

import org.slogga.habboscanner.HabboScanner;

import org.slogga.habboscanner.logic.commands.*;

import org.slogga.habboscanner.logic.commands.common.follow.FollowCommand;

import org.slogga.habboscanner.logic.commands.common.follow.FollowingActionFactory;
import org.slogga.habboscanner.logic.commands.common.follow.IFollower;

import org.slogga.habboscanner.models.enums.CommandKeys;
import org.slogga.habboscanner.models.enums.FollowingAction;

@Data
public class ConsoleHandlers {
    private int userId;

    public void onNewConsole(HMessage message) {
        boolean isBotEnabled = Boolean.parseBoolean(HabboScanner.getInstance().getConfigurator()
                .getProperties().get("bot").getProperty("bot.enabled"));

        if (!isBotEnabled) return;

        userId = message.getPacket().readInteger();
        String messageText = message.getPacket().readString();

        setCommandExecutorProperties(message, messageText);

        Optional.of(messageText)
                .filter(text -> text.equals("go away"))
                .ifPresent(textEquals -> executeFollowCommand());

        CommandExecutor commandExecutor = CommandFactory.getCommandExecutor();

        commandExecutor.getCommands().entrySet().stream()
                .filter(entry -> entry.getValue() != null && messageText.startsWith(entry.getKey()))
                .forEach(entry -> entry.getValue().execute(commandExecutor.getProperties()));
    }

    private void setCommandExecutorProperties(HMessage message, String messageText){
        CommandExecutorProperties commandExecutorProperties = new CommandExecutorProperties();

        commandExecutorProperties.setMessage(message);
        commandExecutorProperties.setMessageText(messageText);
        commandExecutorProperties.setUserId(userId);

        CommandFactory.getCommandExecutor(CommandExecutorType.CONSOLE, commandExecutorProperties);
    }

    private void executeFollowCommand() {
        FollowCommand followCommand = (FollowCommand) CommandFactory.getCommandExecutor()
                .getCommands().get(CommandKeys.FOLLOW.getKey());
        FollowingAction followingAction = followCommand.getFollowingAction();
        IFollower follower = FollowingActionFactory.getFollowingActionStrategy(followingAction);

        Optional.ofNullable(follower).ifPresent(followerExists -> followCommand.initiateBotAndRefreshRoomAccess());
    }
}