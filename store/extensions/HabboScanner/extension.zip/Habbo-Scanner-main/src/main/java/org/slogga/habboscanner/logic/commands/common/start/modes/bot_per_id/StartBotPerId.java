package org.slogga.habboscanner.logic.commands.common.start.modes.bot_per_id;

import java.util.Properties;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import org.slogga.habboscanner.HabboScanner;

import org.slogga.habboscanner.logic.commands.CommandExecutorProperties;
import org.slogga.habboscanner.logic.commands.CommandFactory;
import org.slogga.habboscanner.logic.commands.common.start.IStarter;
import org.slogga.habboscanner.logic.commands.common.start.StartCommand;

import org.slogga.habboscanner.logic.game.HabboActions;

import org.slogga.habboscanner.models.enums.CommandKeys;
import org.slogga.habboscanner.models.enums.IdOrder;

public class StartBotPerId implements IStarter {
    @Override
    public void execute(CommandExecutorProperties properties) {
        Properties botProperties = HabboScanner.getInstance().getConfigurator().getProperties().get("bot");
        String botPerIdOrder = botProperties.getProperty("bot.per.id.order");
        IdOrder order = IdOrder.fromValue(botPerIdOrder);

        if (order == null) {
            String message = HabboScanner.getInstance().getConfigurator().getProperties()
                    .get("message").getProperty("incorrect.order.message");
            HabboActions.sendPrivateMessage(properties.getUserId(), message);

            return;
        }

        int initialRoomId = Integer.parseInt(botProperties.getProperty("bot.initial.room.id"));
        IRoomVisitOrder visitOrder = RoomVisitOrderFactory.getOrderStrategy(order, initialRoomId);

        ScheduledExecutorService executorService = Executors.newSingleThreadScheduledExecutor();
        executorService.scheduleAtFixedRate(createBotTask(visitOrder), 0, 2, TimeUnit.SECONDS);
    }

    private Runnable createBotTask(IRoomVisitOrder strategy) {
        return () -> {
            StartCommand startCommand = (StartCommand) CommandFactory.getCommandExecutor()
                    .getCommands().get(CommandKeys.START.getKey());
            if (!startCommand.isBotRunning()) return;

            int nextRoomId = strategy.getNextRoomId();
            HabboActions.moveToRoom(nextRoomId);
        };
    }
}