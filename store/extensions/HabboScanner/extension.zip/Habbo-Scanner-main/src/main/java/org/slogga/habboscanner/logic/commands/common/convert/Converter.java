package org.slogga.habboscanner.logic.commands.common.convert;

import java.io.*;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import java.util.Optional;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slogga.habboscanner.HabboScanner;

import org.slogga.habboscanner.logic.commands.CommandExecutorProperties;
import org.slogga.habboscanner.logic.commands.CommandFactory;

import org.slogga.habboscanner.models.enums.ConvertFile;

public abstract class Converter {
    private final Logger logger = LoggerFactory.getLogger(Converter.class);

    protected void execute(CommandExecutorProperties properties, ConvertFile convertFile) {
        Properties messageProperties = HabboScanner.getInstance()
                .getConfigurator().getProperties().get("message");

        try {
            convertCSVToSQL(convertFile);

            String actionCompletedMessage = messageProperties.getProperty("action.completed.message");

            CommandFactory.getCommandExecutor().sendMessage(actionCompletedMessage, properties);
        } catch (IOException exception) {
            logger.error(exception.getMessage());

            CommandFactory.getCommandExecutor().sendMessage(exception.getMessage(), properties);
        }
    }

    protected void convertCSVToSQL(ConvertFile convertFile) throws IOException {
        String filePath = getFilePath(convertFile);

        validateFile(filePath, convertFile);

        File directory = getDatabaseDumpDirectory();
        FileWriter fileWriter = new FileWriter(directory + "/" +
                convertFile.getFileName() + ".sql", false);

        try (BufferedReader bufferedReader = new BufferedReader(new FileReader(filePath));
             PrintWriter printWriter = new PrintWriter(fileWriter)) {
            processFile(bufferedReader, printWriter, convertFile);
        }
    }

    private String getFilePath(ConvertFile file) {
        return file.getFileName() + ".csv";
    }

    private void validateFile(String filePath, ConvertFile file) throws IOException {
        Path path = Paths.get(filePath);

        checkFileExists(path, file);
        checkFileReadable(path, file);
    }

    private void checkFileExists(Path path, ConvertFile file) throws FileNotFoundException {
        Optional.of(path)
                .filter(Files::exists)
                .orElseThrow(() -> new FileNotFoundException(String.format("File not found: %s (%s)",
                        file.getFileName(), path.toAbsolutePath())));
    }

    private void checkFileReadable(Path path, ConvertFile file) throws IOException {
        Optional.of(path)
                .filter(Files::isReadable)
                .orElseThrow(() -> new IOException(String.format("File is not readable: %s (%s)",
                        file.getFileName(), path.toAbsolutePath())));
    }

    private File getDatabaseDumpDirectory() {
        return Optional.of(new File("database_dump"))
                .filter(File::exists)
                .orElseGet(this::createDatabaseDumpDirectory);
    }

    private File createDatabaseDumpDirectory() {
        return Optional.of(new File("database_dump"))
                .filter(File::mkdir)
                .orElseThrow(() -> new RuntimeException("Failed to create directory: database_dump"));
    }

    private void processFile(BufferedReader bufferedReader, PrintWriter printWriter, ConvertFile file) {
        String cvsSplitBy = ",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)";

        printWriter.println("DELETE FROM " + file.getFileName());

        int skipLines = file.equals(ConvertFile.ITEMS) ? 2 : 1;

        bufferedReader.lines().skip(skipLines).
                forEach(line -> processLine(line, cvsSplitBy, printWriter, file));
    }

    protected String processField(String[] field, int index) {
        return Optional.ofNullable(field)
                .filter(filteredField -> filteredField.length > index)
                .map(mappedField -> mappedField[index])
                .filter(filteredField -> !filteredField.isEmpty())
                .map(this::sanitizeField)
                .orElse("NULL");
    }

    private String sanitizeField(String field) {
        return "'" + field.replace("\"", "")
                .replace("'", "\\'") + "'";
    }

    protected abstract void processLine(String line, String cvsSplitBy,
                                        PrintWriter printWriter, ConvertFile file);
}

