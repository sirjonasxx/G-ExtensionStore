package org.slogga.habboscanner.logic.configurators;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import java.nio.charset.StandardCharsets;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import gearth.extensions.Extension;
import gearth.protocol.HMessage;

import lombok.Data;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.slogga.habboscanner.HabboScanner;

import org.slogga.habboscanner.handlers.*;
import org.slogga.habboscanner.handlers.item.*;
import org.slogga.habboscanner.handlers.room.*;

import org.slogga.habboscanner.logic.DefaultValues;

@Data
public class HabboScannerConfigurator implements IConfigurator {
    private static final Logger logger = LoggerFactory.getLogger(HabboScannerConfigurator.class);

    private Map<String, Properties> properties = new HashMap<>();

    private RoomEntryHandlers roomEntryHandlers;
    private RoomDetailsHandlers roomDetailsHandlers;
    private ItemProcessingHandlers itemProcessingHandlers;
    private ItemAdditionHandlers itemAdditionHandlers;
    private ItemMovementHandlers itemMovementHandlers;
    private NavigatorHandlers navigatorHandlers;
    private ConsoleHandlers consoleHandlers;
    private UserHandlers userHandlers;
    private GroupHandlers groupHandlers;
    private NotificationHandler notificationHandler;
    private ErrorHandlers errorHandlers;
    private ClientOptimizationHandler clientOptimizationHandler;

    @Override
    public void setupConfig() {
        setupProperties();
        setupHandlers();
        registerHandlers();
    }

    public void loadProperty(String name) {
        String configPath = String.format("configuration/%s.properties", name);
        Properties value = new Properties();

        try (InputStream stream = Files.newInputStream(Paths.get(configPath));
             InputStreamReader streamReader = new InputStreamReader(stream, StandardCharsets.UTF_8)) {
            value.load(streamReader);
            properties.put(name, value);
        } catch (IOException exception) {
            logger.error("Unable to read properties from {}.properties. To resolve this issue, please follow these steps:\n" +
                    "1. Create a new folder named 'configuration' within the G-Earth directory.\n" +
                    "2. Add the missing properties to this 'configuration' folder.\n" +
                    "If the problem persists, please refer to the documentation or contact support.", name);

        }
    }

    private void setupProperties() {
        properties = new HashMap<>();

        DefaultValues.getInstance().getPropertyNames().forEach(this::loadProperty);
    }

    private void setupHandlers() {
        roomEntryHandlers = new RoomEntryHandlers();
        roomDetailsHandlers = new RoomDetailsHandlers();
        itemAdditionHandlers = new ItemAdditionHandlers();
        itemProcessingHandlers = new ItemProcessingHandlers();
        itemMovementHandlers = new ItemMovementHandlers();
        navigatorHandlers = new NavigatorHandlers();
        consoleHandlers = new ConsoleHandlers();
        userHandlers = new UserHandlers();
        groupHandlers = new GroupHandlers();
        notificationHandler = new NotificationHandler();
        errorHandlers = new ErrorHandlers();
        clientOptimizationHandler = new ClientOptimizationHandler();
    }

    private void registerHandlers() {
        Extension extension = HabboScanner.getInstance();

        registerRoomHandlers(extension);
        registerItemHandlers(extension);
        registerNavigatorHandlers(extension);
        registerConsoleHandlers(extension);
        registerUserHandlers(extension);
        registerGroupHandlers(extension);
        registerNotificationHandler(extension);
        registerErrorHandlers(extension);
        registerClientOptimizationHandler(extension);
    }

    private void registerRoomHandlers(Extension extension) {
        extension.intercept(HMessage.Direction.TOCLIENT, "RoomReady", roomEntryHandlers::onRoomReady);
        extension.intercept(HMessage.Direction.TOCLIENT, "GetGuestRoomResult", roomDetailsHandlers::onGetGuestRoomResult);
        extension.intercept(HMessage.Direction.TOCLIENT, "RoomVisualizationSettings", visualizationSettings -> roomDetailsHandlers.onRoomVisualizationSettings());
    }

    private void registerItemHandlers(Extension extension) {
        extension.intercept(HMessage.Direction.TOCLIENT, "Objects", itemProcessingHandlers::onFloorItems);
        extension.intercept(HMessage.Direction.TOCLIENT, "Items", itemProcessingHandlers::onWallItems);
        extension.intercept(HMessage.Direction.TOCLIENT, "ObjectAdd", itemAdditionHandlers::onObjectAdd);
        extension.intercept(HMessage.Direction.TOCLIENT, "ItemAdd", itemAdditionHandlers::onItemAdd);
        extension.intercept(HMessage.Direction.TOSERVER, "MoveObject", itemMovementHandlers::onMoveFurni);
        extension.intercept(HMessage.Direction.TOCLIENT, "ObjectUpdate", itemMovementHandlers::onMoveFurni);
        extension.intercept(HMessage.Direction.TOSERVER, "MoveWallItem", itemMovementHandlers::onMoveWallItem);
        extension.intercept(HMessage.Direction.TOCLIENT, "ItemUpdate", itemMovementHandlers::onMoveWallItem);
    }

    private void registerNavigatorHandlers(Extension extension) {
        extension.intercept(HMessage.Direction.TOCLIENT, "NavigatorSearchResultBlocks", navigatorHandlers::onNavigatorSearchResultBlocks);
    }

    private void registerConsoleHandlers(Extension extension) {
        extension.intercept(HMessage.Direction.TOCLIENT, "NewConsole", consoleHandlers::onNewConsole);
        extension.intercept(HMessage.Direction.TOSERVER, "SendMsg", consoleHandlers::onNewConsole);
    }

    private void registerUserHandlers(Extension extension) {
        extension.intercept(HMessage.Direction.TOCLIENT, "Users", userHandlers::onUsers);
        extension.intercept(HMessage.Direction.TOCLIENT, "Chat", userHandlers::onChat);
        extension.intercept(HMessage.Direction.TOCLIENT, "FollowFriendFailed", userHandlers::onFollowFriendFailed);
    }

    private void registerGroupHandlers(Extension extension) {
        extension.intercept(HMessage.Direction.TOCLIENT, "HabboGroupDetails", groupHandlers::onHabboGroupDetails);
        extension.intercept(HMessage.Direction.TOCLIENT, "HabboGroupJoinFailed", groupHandlers::onHabboGroupJoinFailed);
    }

    private void registerNotificationHandler(Extension extension) {
        extension.intercept(HMessage.Direction.TOCLIENT, "NotificationDialog", notificationHandler::onNotificationDialog);
    }

    private void registerErrorHandlers(Extension extension) {
        extension.intercept(HMessage.Direction.TOCLIENT, "CantConnect", errorHandlers::onCantConnect);
        extension.intercept(HMessage.Direction.TOCLIENT, "ErrorReport", errorHandlers::onErrorReport);
        extension.intercept(HMessage.Direction.TOCLIENT, "GenericError", errorHandlers::onGenericError);
    }

    private void registerClientOptimizationHandler(Extension extension) {
        extension.intercept(HMessage.Direction.TOCLIENT, "Users", clientOptimizationHandler::onClientOptimization);
        extension.intercept(HMessage.Direction.TOCLIENT, "RoomProperty", clientOptimizationHandler::onClientOptimization);
        extension.intercept(HMessage.Direction.TOCLIENT, "HeightMap", clientOptimizationHandler::onClientOptimization);
    }
}
