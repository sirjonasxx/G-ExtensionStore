package org.slogga.habboscanner.logic.game.console.commands.channel.modes;

import org.slogga.habboscanner.logic.commands.CommandFactory;

import org.slogga.habboscanner.logic.game.console.commands.channel.ChannelConsoleCommand;
import org.slogga.habboscanner.logic.game.console.commands.channel.IChannelMode;

import org.slogga.habboscanner.models.enums.CommandKeys;
import org.slogga.habboscanner.models.enums.MessageChannel;

public class ConsoleChannelMode implements IChannelMode {
    @Override
    public void execute() {
        ChannelConsoleCommand channelConsoleCommand = (ChannelConsoleCommand) CommandFactory.getCommandExecutor()
                .getCommands().get(CommandKeys.CHANNEL.getKey());

        channelConsoleCommand.setChannel(MessageChannel.CONSOLE);
    }
}
