package org.slogga.habboscanner.models.habbo_entities;

import lombok.Getter;

@Getter
public final class HabboBot {
    private final int id;
    private final String name;
    private final String motto;
    private final String gender;
    private final String look;
    private final boolean isOldBot;

    public HabboBot(int id, String name, String motto, String gender, String look, boolean isOldBot) {
        this.id = id;
        this.name = name;
        this.motto = motto;
        this.gender = gender;
        this.look = look;
        this.isOldBot = isOldBot;
    }

    @Override
    public String toString() {
        return "HabboBot[" +
                "id=" + id + ", " +
                "name=" + name + ", " +
                "motto=" + motto + ", " +
                "gender=" + gender + ", " +
                "look=" + look + ", " +
                "isOldBot=" + isOldBot + ']';
    }

}
