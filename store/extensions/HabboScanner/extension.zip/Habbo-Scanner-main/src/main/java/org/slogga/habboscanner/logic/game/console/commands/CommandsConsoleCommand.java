package org.slogga.habboscanner.logic.game.console.commands;

import java.util.Map;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import org.slogga.habboscanner.HabboScanner;

import org.slogga.habboscanner.logic.game.HabboActions;

import org.slogga.habboscanner.logic.commands.Command;
import org.slogga.habboscanner.logic.commands.CommandExecutorProperties;
import org.slogga.habboscanner.logic.commands.CommandFactory;

public class CommandsConsoleCommand implements Command {
    @Override
    public void execute(CommandExecutorProperties properties) {
        Map<String, Command> commands = CommandFactory.getCommandExecutor().getCommands();

        ScheduledExecutorService executor = Executors.newSingleThreadScheduledExecutor();

        int delay = 0;

        for (Map.Entry<String, Command> entry : commands.entrySet()) {
            String name = entry.getKey();
            Command command = entry.getValue();

            if (command == null) continue;

            String description = command.getDescription();
            String commandMessageText = name + " - " + description;

            executor.schedule(() -> HabboActions.sendPrivateMessage(properties.getUserId(), commandMessageText),
                    delay, TimeUnit.SECONDS);

            delay++;
        }

        executor.schedule(() -> HabboActions.sendPrivateMessage(properties.getUserId(),
                "----------------------"), delay, TimeUnit.SECONDS);
    }

    @Override
    public String getDescription() {
        return HabboScanner.getInstance()
                .getConfigurator().getProperties()
                .get("command_description").getProperty("commands.command.description");
    }
}
