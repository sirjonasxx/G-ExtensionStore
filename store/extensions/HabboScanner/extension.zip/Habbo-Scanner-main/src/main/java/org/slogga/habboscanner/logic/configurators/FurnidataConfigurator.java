package org.slogga.habboscanner.logic.configurators;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import lombok.Data;

import org.slogga.habboscanner.HabboScanner;

import org.slogga.habboscanner.dao.mysql.items.ItemsDAO;

import org.slogga.habboscanner.logic.DefaultValues;

import org.slogga.habboscanner.models.furni.Furnidata;

import org.slogga.habboscanner.utils.HotelUtils;
import org.slogga.habboscanner.utils.JsonUtils;

@Data
public class FurnidataConfigurator implements IConfigurator {
    private final Logger logger = LoggerFactory.getLogger(FurnidataConfigurator.class);

    private Map<String, Map<String, String>> items;

    @Override
    public void setupConfig() {
        setupFurnidata();
        setupItems();
    }

    private void setupFurnidata() throws RuntimeException{
        String hotelDomain = HabboScanner.getInstance()
                .getConfigurator().getProperties().get("bot").getProperty("hotel.domain");

        if (!DefaultValues.getInstance().getValidDomains().contains(hotelDomain)) {
            logger.error("The hotel domain is incorrect.");

            System.exit(0);
        }

        String furnidataURL = HotelUtils.getFurnidataURL(hotelDomain);
        String furnidataJSON = JsonUtils.fetchJson(furnidataURL);

        Furnidata.setInstance(furnidataJSON);
    }

    private void setupItems() {
        items = ItemsDAO.fetchItems();
    }
}
