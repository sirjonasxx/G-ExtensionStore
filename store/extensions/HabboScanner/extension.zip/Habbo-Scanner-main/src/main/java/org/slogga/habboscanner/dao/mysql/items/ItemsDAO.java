package org.slogga.habboscanner.dao.mysql.items;

import java.sql.*;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slogga.habboscanner.dao.Database;

public class ItemsDAO {
    private static final Logger logger = LoggerFactory.getLogger(ItemsDAO.class);

    public static Map<String, Map<String, String>> fetchItems() {
        Map<String, Map<String, String>> items = new HashMap<>();
        String query = "SELECT * FROM items";

        try (Connection connection = Database.getInstance().getConnection();
             PreparedStatement statement = connection.prepareStatement(query);
             ResultSet resultSet = statement.executeQuery()) {

            ResultSetMetaData metaData = resultSet.getMetaData();
            int columnCount = metaData.getColumnCount();

            while (resultSet.next()) {
                Map<String, String> row = new HashMap<>();

                for (int columnIndex = 1; columnIndex <= columnCount; columnIndex++) {
                    String columnName = metaData.getColumnName(columnIndex);
                    String columnValue = resultSet.getString(columnIndex);

                    row.put(columnName, columnValue);
                }

                String classname = resultSet.getString("classname");
                items.put(classname, row);
            }
        } catch (SQLException exception) {
            logger.error(exception.getMessage());
        }

        return items;
    }
}
