package org.slogga.habboscanner.logic.commands.common.start.modes.bot_per_groups_id;

public interface IGroupActionOrder {
    int getNextGroupId();
}
