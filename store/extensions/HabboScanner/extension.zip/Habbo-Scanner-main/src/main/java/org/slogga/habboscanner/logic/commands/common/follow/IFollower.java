package org.slogga.habboscanner.logic.commands.common.follow;

// It's a strategy
public interface IFollower {
    void execute();
}
