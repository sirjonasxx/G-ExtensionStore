package org.slogga.habboscanner.dao.mysql.rooms;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slogga.habboscanner.dao.Database;

public class RoomsDAO {
    private static final Logger logger = LoggerFactory.getLogger(RoomsDAO.class);

    public static void insertRoom(int id, String name, int ownerId, String ownerName) {
        String query = "INSERT IGNORE INTO `rooms` (`id`, `name`, `owner_id`, `owner_name`) VALUES (?, ?, ?, ?) " +
                "ON DUPLICATE KEY UPDATE `name` = VALUES(`name`), `owner_name` = VALUES(`owner_name`)";

        try (Connection connection = Database.getInstance().getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, id);
            statement.setString(2, name);
            statement.setInt(3, ownerId);
            statement.setString(4, ownerName);

            statement.execute();
        } catch (SQLException exception) {
            logger.error(exception.getMessage());
        }
    }

    public static boolean hasRoomBeenVisited(int roomId) {
        String query = "SELECT 1 FROM rooms WHERE id = ? UNION SELECT 1 FROM room_furni WHERE room_id = ?";

        try (Connection connection = Database.getInstance().getConnection()) {
            try (PreparedStatement statement = connection.prepareStatement(query)) {
                statement.setInt(1, roomId);
                statement.setInt(2, roomId);

                try (ResultSet resultSet = statement.executeQuery()) {
                    return resultSet.next();
                }
            }
        } catch (SQLException exception) {
            logger.error(exception.getMessage());
        }

        return false;
    }
}
