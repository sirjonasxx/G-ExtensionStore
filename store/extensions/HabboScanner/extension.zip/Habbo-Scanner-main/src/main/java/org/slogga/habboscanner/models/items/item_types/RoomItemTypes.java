package org.slogga.habboscanner.models.items.item_types;

import java.util.ArrayList;

import org.slogga.habboscanner.models.furni.Furnitype;

public class RoomItemTypes extends ItemTypes {
    public RoomItemTypes(ArrayList<Furnitype> furnitype) {
        super(furnitype);
    }
}
