package org.slogga.habboscanner.models.furni;

import java.sql.Timestamp;

import lombok.Getter;
import lombok.Setter;

import org.slogga.habboscanner.models.enums.FurnitypeEnum;

@Getter
public class Furni {
    @Setter
    private Integer id;

    @Setter
    private String classname;

    @Setter
    private String name;
    private String owner;
    private  FurnitypeEnum type;
    private int roomId;
    private Point3D coordinates;
    private String location;
    private String extradata;
    private Timestamp timestamp;

    public Furni(Integer id, String classname, String name, String owner,
                 FurnitypeEnum type, int roomId, Point3D coordinates, String location,
                 String extradata, Timestamp timestamp) {
        this.id = id;
        this.classname = classname;
        this.name = name;
        this.owner = owner;
        this.type = type;
        this.roomId = roomId;
        this.coordinates = coordinates;
        this.location = location;
        this.extradata = extradata;
        this.timestamp = timestamp;
    }

    public Furni() { }
}
