package org.slogga.habboscanner.logic.commands.common;

import java.util.Map;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import org.slogga.habboscanner.HabboScanner;

import org.slogga.habboscanner.logic.commands.Command;
import org.slogga.habboscanner.logic.commands.CommandExecutorProperties;
import org.slogga.habboscanner.logic.commands.CommandFactory;
import org.slogga.habboscanner.logic.commands.common.start.StartCommand;

import org.slogga.habboscanner.logic.game.console.commands.EnergySavingConsoleCommand;

import org.slogga.habboscanner.models.enums.CommandKeys;

public abstract class InfoCommand implements Command {
    @Override
    public void execute(CommandExecutorProperties properties) {
        ScheduledExecutorService executorService = Executors.newSingleThreadScheduledExecutor();

        boolean isRoomFurniActiveEnabled = Boolean.parseBoolean(HabboScanner.getInstance()
                .getConfigurator()
                .getProperties()
                .get("bot").getProperty("room_furni_active.enabled"));
        executorService.schedule(() -> printStatus(properties,
                "isRoomFurniActiveEnabled", isRoomFurniActiveEnabled), 1, TimeUnit.SECONDS);

        Map<String, Command> commands = CommandFactory.getCommandExecutor().getCommands();

        EnergySavingCommand energySavingCommand = (EnergySavingConsoleCommand) commands.get(CommandKeys.ENERGY_SAVING.getKey());
        boolean energySavingMode = energySavingCommand.isEnergySavingMode();
        executorService.schedule(() -> printStatus(properties,
                "energySavingMode", energySavingMode), 2, TimeUnit.SECONDS);

        StartCommand startCommand = (StartCommand) commands.get(CommandKeys.START.getKey());
        boolean isBotRunning = startCommand.isBotRunning();
        executorService.schedule(() -> printStatus(properties,
                "isBotRunning", isBotRunning), 3, TimeUnit.SECONDS);

        boolean isProcessingActiveRooms = Boolean.parseBoolean(HabboScanner.getInstance().getConfigurator()
                .getProperties().get("bot").getProperty("bot.in.active.rooms"));
        executorService.schedule(() -> printStatus(properties,
                "isProcessingActiveRooms", isProcessingActiveRooms), 4, TimeUnit.SECONDS);

        executorService.schedule(() ->
                CommandFactory.getCommandExecutor().sendMessage("------------", properties),
                5, TimeUnit.SECONDS);
    }

    @Override
    public String getDescription() {
        return HabboScanner.getInstance().getConfigurator().getProperties().get("command_description")
                .getProperty("info.command.description");
    }

    private void printStatus(CommandExecutorProperties properties, String variableName, boolean isActive) {
        String statusKey = isActive ? "variable.status.enabled.message" : "variable.status.disabled.message";
        String status = HabboScanner.getInstance().getConfigurator().getProperties().get("message").getProperty(statusKey);
        String message = variableName + " " + status;

        CommandFactory.getCommandExecutor().sendMessage(message, properties);
    }
}
