package org.slogga.habboscanner.logic.commands.common.start.modes.bot_per_groups_id.order_actions;

import org.slogga.habboscanner.logic.commands.common.start.modes.bot_per_groups_id.IGroupActionOrder;

import java.util.concurrent.atomic.AtomicInteger;

public class AscActionOrder implements IGroupActionOrder {
    private final AtomicInteger groupId;

    public AscActionOrder(int initialGroupId) {
        this.groupId = new AtomicInteger(initialGroupId);
    }

    @Override
    public int getNextGroupId() {
        return groupId.getAndIncrement();
    }
}
