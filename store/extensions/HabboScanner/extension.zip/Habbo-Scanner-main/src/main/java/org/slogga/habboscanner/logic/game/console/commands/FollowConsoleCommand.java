package org.slogga.habboscanner.logic.game.console.commands;

import gearth.protocol.HMessage;

import org.slogga.habboscanner.HabboScanner;

import org.slogga.habboscanner.logic.configurators.HabboScannerConfigurator;
import org.slogga.habboscanner.logic.game.HabboActions;

import org.slogga.habboscanner.logic.commands.CommandExecutorProperties;

import org.slogga.habboscanner.logic.commands.common.follow.FollowCommand;

import org.slogga.habboscanner.models.enums.FollowingAction;
import org.slogga.habboscanner.models.enums.SourceType;

import java.util.Arrays;
import java.util.Optional;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class FollowConsoleCommand extends FollowCommand {
    @Override
    public void execute(CommandExecutorProperties properties) {
        properties.getMessage().setBlocked(true);

        sourceType = SourceType.HABBO;

        String[] arguments = properties.getMessageText().split(" ", 2);

        Optional<String> followingActionString = Arrays.stream(arguments)
                .skip(1)
                .findFirst();
        followingAction = FollowingAction.fromValue(followingActionString
                .orElse(FollowingAction.DEFAULT.getAction()));

        super.execute(properties);
    }

    public void notifyUserOnRoomStatus(HMessage message, String messageKey) {
        message.setBlocked(true);

        int consoleUserId = HabboScanner.getInstance()
                .getConfigurator()
                .getConsoleHandlers()
                .getUserId();
        String roomMessage = HabboScanner.getInstance()
                .getConfigurator().getProperties().get("message")
                .getProperty(messageKey);

        HabboActions.sendPrivateMessage(consoleUserId, roomMessage);

        initiateBotAndRefreshRoomAccess();
    }

    public void handleEmptyRoom() {
        sendEmptyRoomMessage();

        ScheduledExecutorService executorService = Executors.newSingleThreadScheduledExecutor();
        executorService.schedule(this::initiateBotAndRefreshRoomAccess, 2, TimeUnit.SECONDS);
    }

    private void sendEmptyRoomMessage() {
        HabboScannerConfigurator configurator = HabboScanner.getInstance().getConfigurator();
        String botEmptyRoomMessage = configurator.getProperties().get("message").getProperty("bot.empty.room.message");
        String[] botMessageEmptyRoomArray = botEmptyRoomMessage.split("---");

        int consoleUserId = configurator.getConsoleHandlers().getUserId();
        int randomIndex = (int) (Math.random() * botMessageEmptyRoomArray.length);
        botEmptyRoomMessage = botMessageEmptyRoomArray[randomIndex];

        HabboActions.sendMessage(consoleUserId, botEmptyRoomMessage);
    }
}
