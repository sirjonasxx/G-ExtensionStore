package org.slogga.habboscanner.logic.commands.common.start.modes;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

import org.slogga.habboscanner.logic.commands.CommandExecutorProperties;
import org.slogga.habboscanner.logic.commands.CommandFactory;

import org.slogga.habboscanner.logic.commands.common.start.IStarter;
import org.slogga.habboscanner.logic.commands.common.start.StartCommand;

import org.slogga.habboscanner.logic.game.HabboActions;

import org.slogga.habboscanner.HabboScanner;

import org.slogga.habboscanner.models.enums.CommandKeys;

public class StartBotPerRoomIdList implements IStarter {
    @Override
    public void execute(CommandExecutorProperties properties) {
        String botRoomIdList = HabboScanner.getInstance().getConfigurator()
                .getProperties().get("bot").getProperty("bot.room.id.list");
        String[] roomIds = botRoomIdList.split(" ");

        ScheduledExecutorService executorService = Executors.newSingleThreadScheduledExecutor();
        AtomicInteger currentIndex = new AtomicInteger(0);

        executorService.scheduleAtFixedRate(() -> {
            StartCommand startCommand = (StartCommand) CommandFactory.getCommandExecutor()
                    .getCommands().get(CommandKeys.START.getKey());
            boolean isBotRunning = startCommand.isBotRunning();

            if (!isBotRunning || currentIndex.get() >= roomIds.length) return;

            int roomId = Integer.parseInt(roomIds[currentIndex.getAndIncrement()]);

            HabboActions.moveToRoom(roomId);
        }, 0, 2, TimeUnit.SECONDS);
    }
}
