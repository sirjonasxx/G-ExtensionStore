package org.slogga.habboscanner.logic.commands.common;

import org.slogga.habboscanner.HabboScanner;

import org.slogga.habboscanner.logic.commands.Command;
import org.slogga.habboscanner.logic.commands.CommandExecutorProperties;
import org.slogga.habboscanner.logic.commands.CommandFactory;

import org.slogga.habboscanner.logic.commands.common.follow.FollowCommand;

import org.slogga.habboscanner.models.enums.CommandKeys;

public class ResumeCommand implements Command {
    @Override
    public void execute(CommandExecutorProperties properties) {
        FollowCommand followCommand = (FollowCommand) CommandFactory
                .getCommandExecutor().getCommands().get(CommandKeys.FOLLOW.getKey());

        followCommand.initiateBotAndRefreshRoomAccess();
    }

    @Override
    public String getDescription() {
        return HabboScanner.getInstance().getConfigurator().getProperties().get("command_description")
                .getProperty("resume.command.description");
    }
}
