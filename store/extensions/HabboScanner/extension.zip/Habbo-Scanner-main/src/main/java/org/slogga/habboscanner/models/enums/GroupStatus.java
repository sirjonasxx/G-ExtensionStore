package org.slogga.habboscanner.models.enums;

import java.util.Arrays;
import java.util.Objects;

import lombok.Getter;

@Getter
public enum GroupStatus {
    OPEN(0),
    TO_REQUEST(1),
    CLOSED(2);

    public static GroupStatus fromValue(int value) {
        return Arrays.stream(GroupStatus.values())
                .filter(mode -> Objects.equals(mode.getStatusType(), value))
                .findFirst()
                .orElse(null);
    }

    private final int statusType;

    GroupStatus(int statusType) {
        this.statusType = statusType;
    }
}
