package org.slogga.habboscanner.logic.game.furni;

import java.sql.Timestamp;
import java.util.Optional;

import gearth.extensions.parsers.HFloorItem;
import gearth.extensions.parsers.HWallItem;
import gearth.extensions.parsers.IFurni;

import org.slogga.habboscanner.HabboScanner;

import org.slogga.habboscanner.dao.mysql.room_furni.RoomFurniActiveDAO;
import org.slogga.habboscanner.dao.mysql.room_furni.RoomFurniModificationDAO;

import org.slogga.habboscanner.models.enums.FurnitypeEnum;

import org.slogga.habboscanner.models.furni.Furni;
import org.slogga.habboscanner.models.furni.Furnidata;
import org.slogga.habboscanner.models.furni.Furnitype;
import org.slogga.habboscanner.models.furni.Point3D;

public class FurniHandler {
    public void insertFurni(IFurni furniMetadata, FurnitypeEnum type, int roomId, String extradata) {
        boolean isRoomFurniActiveEnabled = Boolean.parseBoolean(HabboScanner.getInstance()
                .getConfigurator()
                .getProperties()
                .get("bot").getProperty("room_furni_active.enabled"));

        Furni furni = createFurniFromMetadata(furniMetadata, type, roomId, extradata, isRoomFurniActiveEnabled);
        RoomFurniModificationDAO.insertRoomFurni(furni);

        if (!isRoomFurniActiveEnabled) return;

        RoomFurniActiveDAO.insertRoomFurniActive(furni);
    }

    private Furni createFurniFromMetadata(IFurni furniMetadata, FurnitypeEnum type,
                                          int roomId, String extradata, boolean isRoomFurniActiveEnabled) {
        int id = furniMetadata.getId();
        int typeId = furniMetadata.getTypeId();
        String owner = furniMetadata.getOwnerName();

        Furnitype furnitype = Furnidata.getInstance().getFurnitype(typeId, type);

        String classname = furnitype.getClassname();
        String name = Optional.ofNullable(furnitype.getName()).orElse(classname.equals("poster") ? "Poster" : "");

        Point3D coordinates = Optional.of(furniMetadata)
                .filter(furni -> isRoomFurniActiveEnabled && furni instanceof HFloorItem)
                .map(HFloorItem.class::cast)
                .map(furni -> new Point3D(furni.getTile().getX(), furni.getTile().getY(),
                        furni.getTile().getZ()))
                .orElse(new Point3D(-1, -1, -1));

        String location = Optional.of(furniMetadata)
                .filter(furni -> isRoomFurniActiveEnabled && furni instanceof HWallItem)
                .map(HWallItem.class::cast)
                .map(HWallItem::getLocation)
                .orElse("");

        Timestamp timestamp = new Timestamp(System.currentTimeMillis());

        return new Furni(id, classname, name, owner, type,
                roomId, coordinates, location, extradata, timestamp);
    }
}
