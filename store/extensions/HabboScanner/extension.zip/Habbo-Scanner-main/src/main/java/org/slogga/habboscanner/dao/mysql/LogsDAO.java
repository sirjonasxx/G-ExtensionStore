package org.slogga.habboscanner.dao.mysql;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.slogga.habboscanner.dao.Database;

public class LogsDAO {
    private static final Logger logger = LoggerFactory.getLogger(LogsDAO.class);

    public static void insertLog(String message) {
        String query = "INSERT INTO `logs` (`message`) VALUES (?)";

        try (Connection connection = Database.getInstance().getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, message);
            statement.execute();
        } catch (SQLException exception) {
            logger.error(exception.getMessage());
        }
    }
}
