# G-Hypertranslate

> Play translation telephone using Google Translate - https://www.ravbug.com/hypertranslate/

This is completely a port from [@Ravbug](https://github.com/Ravbug)'s [website](https://www.ravbug.com/hypertranslate/) to Habbo. All the credits goes to him.
