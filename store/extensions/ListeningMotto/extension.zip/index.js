import {
  Extension,
  HPacket,
  HDirection,
  HMessage,
  HUserProfile,
} from "gnode-api";
import processlist from "node-processlist";
import { default as config } from "./config.json";
let spotifyPID, oldMusic, oldMotto, announce;
let state = false;

const extensionInfo = {
  name: "Listening Motto",
  description: "Display current spotify music you listening in your motto.",
  version: "1.0",
  author: "Lxx",
};

const ext = new Extension(extensionInfo);

process
  .on("unhandledRejection", (reason, p) => {
    ext.writeToConsole(
      `${reason.toString()} Unhandled Rejection at Promise ${p.toString()}`
    );
  })
  .on("uncaughtException", (err) => {
    ext.writeToConsole(`${err.toString()} Uncaught Exception thrown`);
  });

ext.run();

ext.interceptByNameOrHash(HDirection.TOCLIENT, "UserObject", (hMessage) => {
  let hPacket = hMessage.getPacket();
  oldMotto = hPacket.read("iSSSS")[4];
});

ext.interceptByNameOrHash(HDirection.TOSERVER, "Chat", (hMessage) => {
  let hPacket = hMessage.getPacket();
  let message = hPacket.readString();

  if (message.startsWith("!")) {
    hMessage.setBlocked(true);

    if (message.startsWith("!announce")) {
      if (!announce) {
        announce = true;
        createMessage("You turned on the announce chat message");
      } else {
        announce = false;
        createMessage("You turned off the announce chat message");
      }
    }
  }
});

ext.on("click", async () => {
  if (state === false) {
    state = true;
    getMotto();
    setInterval(() => ListeningMotto(), 1000);
    createMessage("Started ListeningMotto successfully!");
  } else {
    state = false;
    clearInterval(ListeningMotto());
    setOldMotto();
    createMessage("Stopped ListeningMotto successfully!");
  }
});

async function getSpotify() {
  const spotifyProcesses = await processlist.getProcessesByName("Spotify.exe", {
    verbose: true,
  });
  const spotifyWindow = spotifyProcesses.find(
    (process) =>
      process.windowTitle !== "N/A" &&
      process.windowTitle !== "AngleHiddenWindow"
  );
  spotifyPID = spotifyWindow.pid;
  return spotifyWindow;
}

async function getMusic() {
  let music;
  const spotifyProcess = await processlist.getProcessById(spotifyPID, {
    verbose: true,
  });
  if (spotifyProcess.windowTitle.startsWith("Spotify")) music = "Nothing";
  else if (spotifyProcess.windowTitle === "Advertisement") music = "AD";
  else music = spotifyProcess.windowTitle;

  return music;
}

async function ListeningMotto() {
  const spotify = await getSpotify();
  if (!spotify) return;

  const music = await getMusic();
  if (oldMusic && oldMusic === music) return;
  oldMusic = music;

  let mottoPacket = new HPacket('ChangeMotto', HDirection.TOSERVER)
    .appendString(`${config.listening}: ${music}`, 'utf-8')
  ext.sendToServer(mottoPacket);

  let announcePacket = new HPacket('Chat', HDirection.TOSERVER)
    .appendString(`${config.listening}: ${music}`)
    .appendInt(0)
    .appendInt(0)

  if (announce) ext.sendToServer(announcePacket);

  createMessage(`${config.listening}: ${music}`);
}

async function createMessage(text) {
  let messagePacket = new HPacket('NotificationDialog', HDirection.TOCLIENT)
    .appendString("")
    .appendInt(3)
    .appendString("display")
    .appendString("BUBBLE")
    .appendString("message")
    .appendString(text, 'utf-8')
    .appendString("image")
    .appendString("https://raw.githubusercontent.com/sirjonasxx/G-ExtensionStore/repo/1.5.1/store/extensions/ListeningMotto/icon.png")

  ext.sendToClient(messagePacket);
}

async function getMotto() {
  let infoPacket = new HPacket("{out:InfoRetrieve}");
  ext.sendToServer(infoPacket);
}

async function setOldMotto() {
  let setMottoPacket = new HPacket('ChangeMotto', HDirection.TOSERVER)
    .appendString(oldMotto, 'utf-8')
  ext.sendToServer(setMottoPacket);
}
