### Features

- Supports Spotify **Free** and **Premium**
- Instant change your Motto with your **music name /  listening state**
- everyone will know what youre listening **(very cool by the way 😎)**

# Listening Motto


Platform  | Works on?
------------- | -------------
Spotify | <span style="color:green;">Yes ✔</span>
Youtube  | <span style="color:red;">No ✖</span>
Soundcloud | <span style="color:red;">No ✖</span>


### Demo

![](https://cdn.discordapp.com/attachments/891111404529156136/891994802651025428/spotify.gif)
> Gif by @Alynva

### Special Thanks
@Alynva and @WiredSpast that helped me understand various things about g-earth and fix my extension
